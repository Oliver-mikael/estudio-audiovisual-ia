# P1-S — Resultados de Pruebas de Seguridad (AL-04)

## 1. Entorno de ejecución

- Rama: `audit/integral-7a-7f`
- Commit base de la intervención: `8c82c1e`
- Node: `v26.13.0` · npm: `11.20.0`
- Dependencias: instaladas previamente desde el lockfile (`npm ci` en la fase P0); no se añadieron dependencias en esta fase.
- Red: **ninguna** petición externa real. Todas las pruebas de proveedores usan `fetch` simulado con `vi.stubGlobal` y claves ficticias (`test-…-do-not-use-…`).

## 2. TypeScript

Comando: `npx tsc --noEmit`

```
TSC_EXIT=0
```

Resultado: **0 errores**.

## 3. Suite completa de pruebas

Comando: `npx vitest run`

```
✓ src/__tests__/eaiBinaryLifecycle.test.ts  (2 tests)
✓ src/__tests__/mediaLibrary.test.ts        (12 tests)
✓ src/__tests__/integrationEAI.test.ts      (6 tests)
✓ src/__tests__/timelineEngine.test.ts      (10 tests)
✓ src/__tests__/audioEngine.test.ts         (5 tests)
✓ src/__tests__/aiSecurity.test.ts          (7 tests)
✓ src/__tests__/aiRestoredFlow.test.ts      (1 test)
✓ src/__tests__/backup.test.ts              (9 tests)
✓ src/__tests__/aiEngine.test.ts            (9 tests)
✓ src/__tests__/transitionAndAnimation.test.ts (5 tests)
✓ src/__tests__/productionStudio.test.ts    (4 tests)
✓ src/__tests__/core.test.ts                (4 tests)
✓ src/__tests__/storage.test.ts             (2 tests)
✓ src/__tests__/exporter.test.ts            (2 tests)

Test Files  14 passed (14)
     Tests  78 passed (78)
EXIT=0
```

Comparación con la fase P0: **71 → 78 pruebas** (se añadieron 7 nuevas, ninguna eliminada ni modificada). Los 71 tests previos siguen aprobando.

## 4. Pruebas de seguridad añadidas

Archivo: `src/__tests__/aiSecurity.test.ts` (7 pruebas).

| # | Prueba | Qué demuestra |
|---|---|---|
| 1 | «envía la API key de Gemini en la cabecera `x-goog-api-key` y nunca en la URL» | La URL no contiene `?`, ni `?key=`, ni el valor de la clave; la cabecera contiene la clave; método `POST` |
| 2 | «redacta la API key cuando el proveedor la devuelve dentro del cuerpo de error» | Un `400` cuyo cuerpo refleja la clave se devuelve en `result.error` con `[REDACTED]` y sin la clave, conservando el código HTTP |
| 3 | «rechaza un endpoint compatible que incluya la clave en la query string sin realizar la petición» | `fetch` **no** se invoca; el error menciona la query string y no contiene la clave |
| 4 | «rechaza un endpoint con credenciales embebidas en la URL (userinfo)» | `fetch` **no** se invoca; el error no contiene la contraseña/clave |
| 5 | «usa `Authorization` Bearer … sin exponer la clave en la URL» | URL final `…/chat/completions` sin clave y cabecera `Authorization: Bearer <clave>` |
| 6 | «`resolveCompatibleEndpoint` acepta endpoints legítimos con parámetros no sensibles» | `?api-version=…` sigue permitido (sin regresión funcional) |
| 7 | «`redactSensitiveText` enmascara valores conocidos, query strings y cabeceras» | Se eliminan clave conocida, `?key=`, `Bearer`; se conserva el resto del texto (`model=x`) |

Ejecución focalizada:

```
✓ src/__tests__/aiSecurity.test.ts (7 tests) 10ms
Test Files  1 passed (1)
     Tests  7 passed (7)
EXIT=0
```

### 4.1 Demostración de que las pruebas detectan la vulnerabilidad original

Se sustituyó temporalmente `src/services/ai/aiEngine.ts` por la versión del commit `8c82c1e` (código previo a la corrección), se ejecutaron las mismas pruebas y se restauró el archivo corregido:

```
Test Files  1 failed (1)
     Tests  6 failed | 1 passed (7)
PRE_FIX_TEST_EXIT=1
RESTORED_DIFF_LINES=121  8  src/services/ai/aiEngine.ts
```

Las pruebas **fallan contra el código vulnerable** (la URL contenía `?key=`, y los helpers de redacción/validación no existían) y **aprueban con la corrección**. La restauración se verificó con `git diff --numstat` (121 líneas añadidas / 8 eliminadas respecto a `HEAD`, idéntico al cambio corregido).

## 5. Build de producción

Comando: `npm run build` (`tsc && vite build`)

```
vite v5.4.21 building for production...
✓ 1499 modules transformed.
dist/index.html                   0.58 kB │ gzip:  0.38 kB
dist/assets/index-OlMRqcfd.css   34.12 kB │ gzip:  6.42 kB
dist/assets/index-DQeaaxEG.js   358.52 kB │ gzip: 99.02 kB
✓ built in 3.66s
EXIT=0
```

### 5.1 Inspección del bundle

- `grep -c "x-goog-api-key" dist/assets/*.js` → `1` (la clave viaja por cabecera).
- `grep -c "generateContent?key=" dist/assets/*.js` → `0` / `NO_QUERY_KEY_IN_BUNDLE`.
- `.gitignore` excluye `dist/`, `.env`, `.env.local` y `.env.*.local`.

## 6. Búsquedas de exposición residual

| Búsqueda | Resultado |
|---|---|
| `git grep -E "[?&](key\|api_key\|apikey\|access_token\|token\|auth\|secret)=" -- src` | Solo el comentario explicativo del helper de redacción; ninguna URL con credenciales |
| `git grep -E "(AIza…\|sk-…\|gsk_…\|gAAAA…)"` (excluyendo `package-lock.json`) | Único acierto: un PNG base64 en un test (`data:image/png;base64,iVBORw0KGgo…`), falso positivo por coincidencia de patrón |
| `localStorage` / `sessionStorage` | Solo proveedor activo y sesión mock `jwt_mock_*`; ninguna API key |
| IndexedDB (`src/services/storage/db.ts`) | Proyectos y blobs; sin credenciales |
| `import.meta.env` / `VITE_*` / `process.env` / `.env` | No existen inyecciones de secretos ni archivos `.env` versionados |
| `console.*` | Errores locales de audio/export/sync; ninguno con credenciales ni URLs de proveedores de IA |

## 7. Verificación funcional

- `aiEngine.test.ts` (9 pruebas, incluidas cancelación por `AbortController` y aislamiento de credenciales por proveedor): **aprobadas**.
- `aiRestoredFlow.test.ts`, `integrationEAI.test.ts`, `backup.test.ts`, `storage.test.ts`: **aprobadas** (sin regresión en persistencia/restauración).
- `audioEngine.test.ts`, `exporter.test.ts`, `timelineEngine.test.ts`, `transitionAndAnimation.test.ts`, `productionStudio.test.ts`, `mediaLibrary.test.ts`, `core.test.ts`, `eaiBinaryLifecycle.test.ts`: **aprobadas**.

## 8. Qué NO se verificó

- **Llamada real a Gemini o Groq:** no se realizó ninguna petición externa (el encargo prohíbe tráfico que pueda generar gastos y no hay claves reales). La cabecera `x-goog-api-key` está respaldada por la documentación oficial de Google; las pruebas confirman la forma exacta de la petición, no la respuesta del servicio.
- **CORS real en navegador/WebView:** no se ejecutó la app en navegador. Los SDK oficiales de Google usan la misma cabecera en cliente, por lo que se espera preflight correcto; no se afirma verificado.
- **Exportación audiovisual real:** fuera de alcance de P1-S y no verificable en este entorno (ya documentado en P0).
- **APK:** no se generó ni se modificó.

## 9. Conclusión

Todas las validaciones solicitadas pasan: TypeScript 0 errores, 78/78 pruebas aprobadas (7 nuevas de seguridad), build de producción exitoso. La evidencia demuestra que las credenciales ya no se envían en query strings, que los errores no exponen secretos conocidos y que no se rompieron las integraciones existentes a nivel de pruebas.
