# Auditoría de Audio y Sincronización

## Evidencia
- `AudioEngine.loadBuffer` cachea por URL; `scheduleClip` consulta `bufferCache.has(clip.assetId)`.
- `AudioMixer` tiene duckingEnabled pero no aplica ducking.
- Exporter llama `audioEngine.play(project,0)` y stop al final.

## Hallazgos
- AL-01 (ALTO): audio de assets importados no suena (cache key mismatch).
- AL-02 (ALTO): ducking configurado pero no ejecutado (sin gain automation).
- ME-01 (MEDIO): `play` es async y await scheduleClip secuencial; puede desincronizar.
- ME-02 (MEDIO): oscilador sintético a 220/110 Hz no es audio real; solo fallback.
- ME-03 (MEDIO): AudioContext no se cierra en export; dispose manual.
- OB-01 (OBSERVACIÓN): no hay tests de export audio real.

## Recomendación
Cachear buffer por assetId o cargar antes de play; implementar ducking real; medir sync.
