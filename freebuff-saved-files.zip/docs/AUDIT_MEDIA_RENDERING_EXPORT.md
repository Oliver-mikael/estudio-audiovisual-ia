# Auditoría de Renderizado y Exportación

## Evidencia
- `renderEngine.ts` usa scenes para duración y V1 track para clips; V2 no renderizado.
- `exporter.ts` totalDuration = suma scene.durationSeconds; fps 30; MediaRecorder WebM/MP4; audio stream de AudioEngine.
- Transiciones solo si clipOffsetMs < transDurationMs y previous scene/clip.

## Hallazgos
- AL-01 (ALTO): export no refleja clips V2 ni audio de assets importados (cache mismatch).
- AL-02 (ALTO): totalDuration basado en scenes; si timeline editado no sincronizado, export inconsistente.
- ME-01 (MEDIO): bitrate fijo 2.5Mbps; sin perfiles reales de ExportProfile.
- ME-02 (MEDIO): preloadImages solo escenas; assets importados no precargados.
- ME-03 (MEDIO): render loop con setInterval (drift temporal) y 300ms buffer arbitrario.
- OB-01 (OBSERVACIÓN): exportación real no verificada en entorno (sin navegador/MediaRecorder).

## Recomendación
Sincronizar duración con timeline; precargar assets; usar requestVideoFrameCallback si disponible.
