# Auditoría de Rendimiento Android

## Riesgos identificados
- ME-01 (MEDIO): imageCache y bufferCache sin límite → OOM en gama baja.
- ME-02 (MEDIO): EAI base64 de blobs (hasta 250MB) → memoria pico alta.
- ME-03 (MEDIO): Canvas 2D a 720p/30fps con transiciones offscreen → CPU alto.
- ME-04 (MEDIO): IndexedDB sin cuota handling; navegador puede purgar.
- ME-05 (MEDIO): setInterval render loop en export puede congelar UI.
- OB-01 (OBSERVACIÓN): no hay pruebas en dispositivo físico (solo viewport).

## Recomendación
Limitar caches (LRU), revocar object URLs, reducir resolución en low-end, streaming export.
