# P0 Blockers Analysis — Estudio Audiovisual Inteligente

## Rama de trabajo
- Rama: `audit/integral-7a-7f`
- Commit base: `98d035d` (feat: implement phase 7F transition and keyframe engine)
- Commit de auditoría: `a8177d1` (docs(audit): add independent 7A-7F audit reports)
- Estado inicial del árbol de trabajo: limpio.

## Bloqueante 1 — TypeScript no compila (CR-01)

### Error A
- Archivo: `src/engine/renderEngine.ts`
- Línea: 144
- Código: `TS6133: 'transDurationSec' is declared but its value is never read.`
- Causa real: se calculó `const transDurationSec = transDurationMs / 1000;` pero la variable nunca se utiliza en ninguna expresión posterior. La duración de transición se usa en milisegundos (`transDurationMs`) en todo el bloque.
- Impacto: `npm run build` (que ejecuta `tsc && vite build`) falla; no se genera bundle de producción.
- Solución mínima: eliminar la declaración no usada.

### Error B
- Archivo: `src/modules/ProductionStudio.tsx`
- Línea: 730
- Código: `TS2322: Type '{ ... transition: { ..., easing: string } ... }' is not assignable to type 'TimelineTrack[]'` → `Type 'string' is not assignable to type 'EasingCurve | undefined'.`
- Causa real: al asignar una transición a un clip desde la UI, `easing` se define como el literal de cadena `'ease-in-out'`. TypeScript infiere el tipo `string`, que no es asignable a `EasingCurve` (`'linear' | 'ease-in' | 'ease-out' | 'ease-in-out'`).
- Impacto: mismo que Error A; bloquea compilación y build.
- Solución mínima: importar `EasingCurve` y aplicar un cast seguro del literal (`'ease-in-out' as EasingCurve`), consistente con el patrón ya usado en `src/__tests__/transitionAndAnimation.test.ts`.

## Bloqueante 2 — Pruebas de persistencia EAI (CR-02)

### Tests afectados
- Archivo: `src/__tests__/eaiBinaryLifecycle.test.ts`
- Test 1: "exports and restores a project with real binary media, folders, and timeline clips"
- Test 2: "restores legacy .eai packages created before Phase 7E without errors"

### Causa raíz
- Entorno de Vitest por defecto: `node` (sin `indexedDB` global).
- `src/services/storage/db.ts` usa `indexedDB.open(...)` directamente.
- Trazas:
  - Test 1: `ReferenceError: indexedDB is not defined` en `db.ts:12` → `getMediaAssetBlob` → `createEAIPackage` (línea 140 de `projectBackup.ts`).
  - Test 2: `ReferenceError: indexedDB is not defined` en `db.ts:12` → `saveProjectToStorage` → `restoreProjectFromEAI` (línea 342 de `projectBackup.ts`).

### Naturaleza del defecto
- No es un defecto de lógica de producción; es un defecto de configuración del entorno de pruebas (falta de implementación de IndexedDB en Node).
- La auditoría reportó "4 pruebas fallidas"; la ejecución real mostró 2 pruebas fallidas dentro de 1 archivo (71 tests totales, 69 aprobados inicialmente). No se ocultó ningún test.

### Solución aplicada
- Instalar `fake-indexeddb` como devDependency (implementación real de IndexedDB para Node, no un mock simplificado).
- Crear `src/test/setup.ts` que importa `fake-indexeddb/auto` y resetea la instancia de `indexedDB` antes de cada test para garantizar aislamiento.
- Configurar Vitest en `vite.config.ts` con `setupFiles` y `environment: 'node'`.

## Riesgos pendientes (fuera de alcance P0)
- AL-01: desajuste de claves de caché de audio (`assetId` vs URL) — no corregido en esta intervención.
- AL-02: auto-ducking declarado pero no aplicado — no corregido.
- AL-03: duración de exportación basada en escenas; V2 no renderizado — no corregido.
- AL-04: API key de Gemini en query string — no corregido.
- ME-01 a ME-04: migraciones, atomicidad, huérfanos, cuota — no corregidos.
- OB-01: sin lint configurado — no corregido.

## Verificación de protección del repositorio
- Rama actual confirmada: `audit/integral-7a-7f`.
- No se trabajó sobre `main`.
- No se realizaron push, PR, merges, rebase, cherry-pick, reset ni clean.
- No se modificaron APK, secretos ni archivos multimedia de prueba.