# Auditoría de Persistencia y Seguridad de Datos

## Evidencia
- `src/services/storage/db.ts`: IndexedDB DB_VERSION=1, dos stores (projects, assets). Sin migraciones.
- Tests `eaiBinaryLifecycle.test.ts` fallan por `indexedDB is not defined` en node.
- `projectBackup.ts`: base64 de blobs, checksum SHA-256, validación JSON.

## Hallazgos
- CR-02 (CRÍTICO): tests de persistencia no corren en entorno por defecto (falta jsdom).
- AL-04 (ALTO): `saveMediaAssetBlob` guarda asset completo (incluye fileBlob) pero `createEAIPackage` lee blob desde IndexedDB; OK si persistido.
- ME-01 (MEDIO): sin atomicidad multi-store; saveProject y saveAsset en transacciones separadas.
- ME-02 (MEDIO): `deleteAssetSafely` no elimina blob de IndexedDB (huérfanos).
- ME-03 (MEDIO): `getAssetUsageCount` solo cuenta clips y scenes; no cuenta otros proyectos salvo pasar allProjects.
- ME-04 (MEDIO): sin cuota/estimate handling; base64 EAI puede exceder límites móviles (warning 250MB).
- OB-01 (OBSERVACIÓN): DB_VERSION sin migración; cambios de schema rompen datos antiguos.

## Recomendación
Configurar vitest con jsdom para tests de IDB; agregar migración versionada y cleanup de blobs.
