# P1-S — Auditoría de Seguridad: Exposición de API Keys en URLs (AL-04)

## 1. Alcance y entorno

| Elemento | Valor |
|---|---|
| Rama de trabajo | `audit/integral-7a-7f` |
| Commit de partida | `8c82c1e` (fix(audit): stabilize TypeScript and IndexedDB tests) |
| Árbol inicial | Limpio (`git status --short` sin salida) |
| Informes leídos | `docs/AUDIT_INDEPENDENT_7A_7F.md`, `docs/AUDIT_FINDINGS_AND_FIX_PLAN.md`, `docs/P0_*.md`, `docs/SECURITY_MODEL.md` |
| Alcance | Hallazgo AL-04 y exposiciones de credenciales asociadas (URLs, logs, errores, persistencia) |
| Fuera de alcance | AL-01/AL-02/AL-03, ME-0x, OB-01; nuevas funcionalidades; nueva infraestructura |

No se realizaron push, PR, merge, rebase ni despliegues. No se generó APK. No se realizaron solicitudes reales a servicios externos: todas las pruebas usan `fetch` simulado. No se muestra ni registra ningún secreto real; los valores usados en pruebas son cadenas ficticias.

## 2. Metodología

Búsqueda exhaustiva en `src/` y configuración del proyecto sobre:

- Construcción de URLs y query strings (`?key=`, `&api_key=`, `token=`, etc.).
- Llamadas de red: `fetch`, `axios`, clientes propios, `endpointUrl` configurables.
- Cabeceras de autenticación (`Authorization`, `x-goog-api-key`).
- Persistencia de credenciales: `localStorage`, `sessionStorage`, IndexedDB, archivos del proyecto.
- Variables de entorno y mecanismos de configuración (`import.meta.env`, `VITE_*`, `process.env`, `.env`).
- Logs, telemetría y mensajes de error (`console.*`, propagación de cuerpos de error).
- Historial de git y archivos versionados (patrones tipo `AIza…`, `sk-…`, `gsk_…`).

### Inventario de superficie de red y persistencia

| Ubicación | Qué hace | Credenciales implicadas |
|---|---|---|
| `src/services/ai/aiEngine.ts` | 3 proveedores de IA: heurístico local, Gemini (Google AI Studio), OpenAI-compatible (Groq/Ollama/OpenAI) | API Key del usuario |
| `src/components/AIAssistantDrawer.tsx` | UI de configuración de proveedor y API Key | API Key del usuario |
| `src/services/cloud/api.ts` | Cliente cloud simulado; sesión mock en `localStorage` | Token simulado `jwt_mock_*` |
| `src/services/sync/syncEngine.ts`, `src/services/jobs/jobQueue.ts` | Cola de sincronización/jobs en `localStorage` | Ninguna |
| `src/services/audio/AudioEngine.ts` | `fetch(url)` de audio y mensajes de error con la URL | URLs de medios locales/blob |
| `src/services/storage/projectBackup.ts` | Object URLs para descarga/restauración `.eai` | Ninguna |
| `src/services/storage/db.ts` | IndexedDB (proyectos y blobs) | Ninguna credencial |
| `supabase/schema.sql` | Esquema SQL con RLS (no hay claves) | Ninguna |

No existen variables `VITE_*`/`import.meta.env` que inyecten secretos en el bundle, ni archivos `.env` versionados (`.gitignore` cubre `.env`, `.env.local`, `.env.*.local`).

## 3. Hallazgos

### F-01 — API key de Gemini enviada en la query string — **CONFIRMADO (Alto)**

- **Archivo/línea original:** `src/services/ai/aiEngine.ts:346` (método `executeGemini`).
- **Código original (clave enmascarada):**
  ```ts
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${creds.apiKey}`;
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, ... });
  ```
- **Cómo se produce:** la clave del usuario se concatena como parámetro `key` de la URL de la petición `fetch`.
- **Información expuesta:** la API Key completa de Google AI Studio del usuario (cuota gratuita y, si el proyecto de Google tiene facturación, consumo facturable).
- **Vectores concretos de fuga:**
  1. **Resource Timing API:** `performance.getEntriesByType('resource')` expone la URL completa de cada `fetch`, incluido `?key=…`, a cualquier script del mismo origen (incluido un XSS o una dependencia comprometida). La cabecera `Authorization`/`x-goog-api-key` no es legible por JavaScript.
  2. **Intermediate proxies, filtros corporativos, inspección TLS, antivirus y paneles de red de APK/WebView:** las URLs se registran por defecto en muchos de estos sistemas; las cabeceras de autenticación, no.
  3. **Capturas de red, HAR y herramientas de depuración remota** (Chrome DevTools, `chrome://net-export`, Charles, mitmproxy) muestran la URL completa.
  4. **Logs de error y diagnósticos**: si un error incluye la URL solicitada, la clave viaja con él.
  5. **Referencias externas:** Google documenta explícitamente que el parámetro `key` en la URL «expone tu clave al robo mediante escaneos de URL» y recomienda la cabecera `x-goog-api-key` (ver `docs.cloud.google.com/docs/authentication/api-keys-use`).
- **Impacto:** robo de la clave del usuario → consumo de su cuota, denegación de servicio por agotamiento de límites y, si hay facturación habilitada, cargos económicos. No permite leer datos de otros usuarios del Estudio (no hay backend propio que la use).
- **Prioridad:** Alta dentro de P1-S. Corrección de bajo riesgo y sin coste.
- **Solución recomendada:** mover la clave a la cabecera `x-goog-api-key` (mecanismo oficial de Gemini) y eliminar por completo el parámetro de la URL.

### F-02 — Cuerpos de error de proveedores propagados sin redacción — **CONFIRMADO (Medio)**

- **Archivo/línea original:** `src/services/ai/aiEngine.ts:367` (Gemini) y `:434` (OpenAI-compatible).
- **Código original:**
  ```ts
  throw new Error(`Error en API Gemini (${res.status}): ${errBody.slice(0, 150)}`);
  throw new Error(`Error en Proveedor Compatible (${res.status}): ${errBody.slice(0, 150)}`);
  ```
- **Cómo se produce:** el cuerpo de error del proveedor se recorta a 150 caracteres y se devuelve en `AIExecutionResult.error`; `AIAssistantDrawer` lo muestra en pantalla (`setStatusMessage(\`Error: ${res.error}\`)`) y puede acabar en capturas, soporte o logs del usuario.
- **Qué podría exponerse:** si el proveedor refleja la clave (algunas pasarelas la incluyen en `error.message`), o si el mensaje contiene la URL con `?key=`, la credencial se propaga a la UI y a cualquier registro del error.
- **Clasificación:** confirmado como **debilidad de manejo de errores**; la fuga efectiva depende del proveedor (no reproducible sin llamada real, que está prohibida en este encargo). Se corrige como defensa en profundidad.
- **Prioridad:** Media.
- **Solución recomendada:** función de redacción que enmascare valores conocidos, parámetros de credenciales en URLs, cabeceras `Bearer/Basic` y patrones de claves conocidos (`AIza…`, `sk-…`, `gsk_…`, `gAAAA…`), aplicada a todo mensaje de error antes de exponerlo.

### F-03 — Endpoint configurable capaz de transportar credenciales en la URL — **CONFIRMADO (Medio)**

- **Archivo/línea original:** `src/services/ai/aiEngine.ts:398` (método `executeOpenAICompatible`).
- **Código original:**
  ```ts
  const endpoint = creds?.endpointUrl || 'https://api.groq.com/openai/v1';
  ...
  const res = await fetch(`${endpoint.replace(/\/$/, '')}/chat/completions`, { ... });
  ```
- **Cómo se produce:** el usuario introduce libremente `endpointUrl` en la UI. Si pega una URL con credenciales (`https://user:pass@host/v1`, `https://host/v1?api_key=…`), se enviarían en la URL, reproduciendo el mismo patrón que F-01, y con `userinfo` la clave viajaría además en texto claro en la autoridad de la URL.
- **Información expuesta:** la credencial del endpoint del usuario (Groq, proxy propio, etc.).
- **Prioridad:** Media.
- **Solución recomendada:** validar la URL antes de la petición y rechazarla si contiene `userinfo` o parámetros de query con nombres de credenciales, indicando que use el campo de API Key (que ya se envía en la cabecera `Authorization: Bearer`).

### F-04 — Credenciales de IA en `localStorage`, `sessionStorage` o IndexedDB — **FALSO POSITIVO**

- Las credenciales de IA viven en `credentialsMap: Map<AIProviderId, AISecureCredentials>` en memoria (`aiEngine.ts:48`); `setCredentials` no persiste nada.
- En `sessionStorage` solo se guarda el **identificador de proveedor activo** (`estudio_ai_active_provider`), no la clave.
- En IndexedDB (`EstudioAudiovisualDB`) se guardan proyectos y blobs de medios; no hay credenciales.
- Riesgo residual: la clave permanece en memoria del proceso mientras la pestaña esté abierta (necesario para usarla) y es accesible a scripts del mismo origen, algo inherente a cualquier cliente que llame a la API directamente. No se puede eliminar sin un proxy del lado servidor.

### F-05 — Token simulado en `localStorage` (`estudio_cloud_session`) — **FALSO POSITIVO (con nota)**

- `src/services/cloud/api.ts:51` guarda `{ userId, email, token: 'jwt_mock_…' }` generado localmente por `login()`. No existe backend que lo valide ni concede acceso a nada; es un mock de demostración.
- **Nota para el futuro:** si se conecta autenticación real (Supabase/Auth), un token de sesión en `localStorage` sería vulnerable a XSS. Recomendación: cookies `HttpOnly`/`SameSite` o almacenamiento seguro nativo (Capacitor Secure Storage) cuando exista backend real. No se modifica ahora porque no hay credencial real ni backend.

### F-06 — URLs completas en logs y errores — **PARCIALMENTE CONFIRMADO, sin credenciales**

- `src/services/audio/AudioEngine.ts:80` lanza `Error descargando audio desde ${url} …` y `:78` hace `fetch(url)` para audio. Las URLs son `blob:`/`data:`/assets locales del proyecto; no contienen credenciales.
- `console.error/warn` localizados en `src/App.tsx`, `src/modules/HomeDashboard.tsx`, `src/services/sync/syncEngine.ts`, `src/services/audio/AudioRecorder.ts`, `src/services/storage/projectBackup.ts` registran errores, pero ninguno incluye credenciales ni URLs de proveedores de IA. No hay telemetría ni envío de logs a terceros.
- **Clasificación:** falso positivo respecto a AL-04. Sin cambios (evitar refactor fuera de alcance).

### F-07 — Documentación que afirma «clave en sessionStorage» — **INEXACTITUD DOCUMENTAL**

- `docs/PHASE_7A_AI_EXPERIENCE.md:66` indica «Clave en `sessionStorage`». El código real usa memoria de sesión (`Map`), que es más seguro. No hay exposición; se deja constancia aquí y **no se alteran los informes/fases originales** por instrucción expresa.

### F-08 — Secretos versionados o inyectados en el bundle — **FALSO POSITIVO**

- `git grep` de patrones `AIza…`, `sk-…`, `gsk_…`, `gAAAA…` no encuentra claves reales; el único acierto es una imagen PNG en base64 dentro de un test (`data:image/png;base64,iVBORw0KGgo…`), que coincide con el patrón `gAAAA…` por azar del base64.
- No hay `.env` versionado, ni `VITE_*`, ni claves en `supabase/schema.sql`, ni en `capacitor.config.json`.
- El bundle `dist/` no contiene `generateContent?key=` y sí contiene la cabecera `x-goog-api-key` (verificado tras el build).

## 4. Clasificación de riesgo (resumen)

| ID | Hallazgo | Archivo | Clasificación | Impacto | Prioridad |
|---|---|---|---|---|---|
| F-01 | API key de Gemini en query string | `src/services/ai/aiEngine.ts` (`executeGemini`) | **Confirmado** | Robo de clave vía Resource Timing, proxies, HAR, logs | **Alta** |
| F-02 | Cuerpos de error sin redacción | `src/services/ai/aiEngine.ts` (ambos proveedores) | **Confirmado** | Eco de clave/URL en UI y registros | Media |
| F-03 | Endpoint configurable con credenciales en URL | `src/services/ai/aiEngine.ts` (`executeOpenAICompatible`) | **Confirmado** | Clave en URL/userinfo | Media |
| F-04 | Credenciales en localStorage/IndexedDB | `aiEngine.ts`, `db.ts` | Falso positivo | — | — |
| F-05 | Token mock en localStorage | `src/services/cloud/api.ts` | Falso positivo (nota futura) | Bajo si se añade backend real | Baja |
| F-06 | URLs en logs/errores de audio | `src/services/audio/AudioEngine.ts` | Falso positivo para AL-04 | — | — |
| F-07 | Doc dice «clave en sessionStorage» | `docs/PHASE_7A_AI_EXPERIENCE.md` | Inexactitud documental | Ninguno | Baja |
| F-08 | Secretos en repo/bundle | Todo el repo | Falso positivo | — | — |

## 5. Limitación estructural (no corregible en este alcance)

Cualquier aplicación **100% cliente** que llame directamente a la API de un proveedor con la clave del usuario envía esa clave al dispositivo y al proveedor. No puede considerarse secreta frente al propietario del dispositivo ni frente a scripts del mismo origen. La corrección aplicada elimina los canales de fuga evitables (URL, errores, logs), pero **no** convierte la clave en un secreto servidor.

Para eliminar esa limitación haría falta un proxy del lado servidor que custodie la clave (por ejemplo, una función serverless en el plan gratuito). Ese trabajo **no se ha realizado**: el encargo prohíbe construir infraestructura nueva y el proyecto no tiene backend operativo. Se documenta como propuesta en `docs/P1S_SECURITY_FIXES.md` (sección 5).

## 6. Conclusión

AL-04 es una **vulnerabilidad real y confirmada**, no un falso positivo. Su causa es una única concatenación de la API key en la URL del proveedor Gemini. Se corrigió junto con dos canales de exposición asociados (errores sin redacción y endpoints configurables con credenciales en URL). El resto de los vectores investigados (persistencia local, logs, variables de entorno, repositorio y bundle) resultaron falsos positivos o inexactitudes documentales, documentados sin modificar los informes originales.
