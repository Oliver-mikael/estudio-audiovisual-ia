# Auditoría Independiente 7A–7F (rama audit/integral-7a-7f)

## Resumen
- Rama aislada: `audit/integral-7a-7f` (base `98d035d`).
- Código: React 18 + TS + Vite + Capacitor, offline-first con IndexedDB.
- `npm ci` OK (8 vulns reportadas por npm audit).
- `npx tsc --noEmit`: FALLA (2 errores).
- `npm run build`: FALLA por los mismos errores TS.
- `npx vitest run`: 12/13 archivos OK, 71/73 tests OK; 2 fallan por `indexedDB is not defined` (entorno node por defecto).
- No se ejecutó simulación integral de producción (sin navegador/Canvas real en este entorno). No se inventan resultados.

## Hallazgos clave
- CR-01 TS no compila (renderEngine.ts:144 var no usada; ProductionStudio.tsx:730 easing string vs EasingCurve).
- CR-02 Tests de persistencia EAI fallan en entorno node por falta de jsdom/setup de indexedDB.
- AL-01 AudioEngine buffer cache key mismatch: `loadBuffer` cachea por URL, `scheduleClip` busca por `clip.assetId` → audio importado puede no sonar en export.
- AL-02 AudioMixer declara ducking pero no aplica ducking real.
- AL-03 Render/export duration basada en scenes; timeline edits sincronizan escenas pero V2/multitrack no se renderizan; export a 2.5Mbps fixed.
- AL-04 API key de Gemini se envía en query string (riesgo XSS/leak).
- ME-01 IndexedDB sin migraciones/versionado incremental, transacciones por store aisladas; no hay atomicidad multi-store.
- ME-02 Object URLs e imageCache/bufferCache sin límite → riesgo OOM en Android.
- ME-03 Storage persistence best-effort; deleteAssetSafely no borra blob de IndexedDB.
- OB-01 Sin lint configurado; sin E2E/Playwright config detectado.

## Veredicto
NO APROBADO para producción confiable hasta corregir CR-01/CR-02 y AL-01/AL-02. Funcionalidad parcialmente verificada (71/73 tests unitarios). Exportación real no verificada en este entorno.
