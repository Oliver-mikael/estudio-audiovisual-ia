# P1-S — Correcciones de Seguridad Implementadas (AL-04)

## 1. Resumen

Se corrigieron **tres problemas de seguridad confirmados** derivados de AL-04:

1. La API key de Gemini se enviaba en la query string de la petición (`?key=…`).
2. Los cuerpos de error de los proveedores se propagaban a la UI sin redactar.
3. El endpoint configurable del proveedor OpenAI-compatible podía transportar credenciales en la propia URL.

No se añadieron funcionalidades, dependencias ni infraestructura. No se modificaron expectativas de pruebas existentes.

## 2. Corrección 1 — Clave de Gemini en cabecera (F-01)

**Archivo:** `src/services/ai/aiEngine.ts` (`executeGemini`).

**Antes** (clave enmascarada):

```ts
const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${creds.apiKey}`;

const res = await fetch(url, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  ...
});
```

**Después:**

```ts
const GEMINI_GENERATE_CONTENT_URL =
  'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

// The API key travels only in the request header; never in the URL/query string.
const res = await fetch(GEMINI_GENERATE_CONTENT_URL, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-goog-api-key': creds.apiKey,
  },
  ...
});
```

**Justificación técnica:** `x-goog-api-key` es el mecanismo de autenticación documentado por Google para la API de Gemini; la propia documentación de Google Cloud advierte que el parámetro `key` en la URL expone la clave a robo mediante escaneos de URL. Los SDK oficiales de Google envían la clave por cabecera, por lo que el patrón es compatible con las peticiones CORS del navegador (preflight `OPTIONS` incluido).

**Compatibilidad:** el resto de la petición (cuerpo, `generationConfig`, `AbortSignal`, parseo de respuesta) queda intacto. No cambia el contrato de `executeTask` ni la UI.

## 3. Corrección 2 — Redacción de secretos en errores (F-02)

**Archivo:** `src/services/ai/aiEngine.ts`.

Se añadió el helper exportado `redactSensitiveText(value, knownSecrets)` que enmascara:

- Valores secretos conocidos (la API key activa, longitud ≥ 6) → `[REDACTED]`.
- Parámetros de query con nombres de credenciales (`key`, `api_key`, `api-key`, `access_token`, `token`, `auth`, `authorization`, `password`, `passwd`, `secret`, `client_secret`, `credential(s)`, `sig`, `signature`).
- Cabeceras `Bearer …` / `Basic …`.
- `userinfo` de URLs (`https://usuario:contraseña@host`).
- Patrones de claves habituales: `AIza…` (Google), `sk-…` (OpenAI), `gsk_…` (Groq), `gAAAA…` (Google OAuth).

Aplicación:

```ts
// executeTask (catch final): todo error devuelto al llamador pasa por redacción
error: redactSensitiveText(
  err?.message || 'Error desconocido durante la ejecución de IA',
  [activeCredentials?.apiKey]
),

// Gemini / OpenAI-compatible: el cuerpo de error del proveedor también se redacta
throw new Error(
  `Error en API Gemini (${res.status}): ${redactSensitiveText(errBody.slice(0, 150), [creds.apiKey])}`
);
```

**Compatibilidad:** los mensajes siguen siendo descriptivos e incluyen el código HTTP; solo se sustituyen los valores sensibles. La UI (`AIAssistantDrawer`) no requiere cambios.

**Limitación:** la redacción es defensa en profundidad; reconoce los formatos listados y el valor exacto de la clave activa. Un proveedor que ofusque la clave de forma no reconocible podría escapar al filtro, aunque la corrección 1 elimina el canal principal (la URL).

## 4. Corrección 3 — Validación del endpoint configurable (F-03)

**Archivo:** `src/services/ai/aiEngine.ts` (`resolveCompatibleEndpoint`, usado por `executeOpenAICompatible`).

Reglas:

- La URL debe ser absoluta y usar `https:` (o `http:` para Ollama/servidores locales).
- Se rechaza si contiene `userinfo` (`usuario:contraseña@`).
- Se rechaza si algún parámetro de query usa un nombre de credencial (misma lista que la redacción).

Ejemplo de mensaje devuelto (sin reproducir el valor sensible): *«El endpoint incluye credenciales en la query string. Usa el campo de API Key; la petición no se enviará.»*

**Compatibilidad:** los endpoints legítimos siguen funcionando, incluidos los que usan parámetros no sensibles como `?api-version=2024-02-01`. El envío de la clave continúa por `Authorization: Bearer …` (sin cambios). El único comportamiento alterado es el de configuraciones inseguras, que ahora fallan de forma explícita y accionable en lugar de filtrar la credencial.

## 5. Limitación estructural y alternativa sin coste

La aplicación es *cliente puro*: la clave del usuario debe llegar al navegador/WebView para llamar al proveedor. Ninguna corrección en el cliente puede convertirla en un secreto frente al propietario del dispositivo ni frente a scripts del mismo origen.

**Alternativa recomendada (NO implementada, requiere infraestructura nueva):**

- Un *proxy* serverless mínimo (una sola función) que custodie la clave en una variable de entorno del servidor y exponga un endpoint propio; el cliente deja de manejar la clave y solo envía la carga útil.
- Encaja en planes gratuitos de funciones serverless, pero requiere desplegar y mantener un servicio, elegir proveedor, configurar CORS y autenticación de usuarios. El encargo prohíbe crear infraestructura nueva y el proyecto no tiene backend operativo, por lo que se documenta y no se improvisa.
- Si en el futuro se adopta, el proxy debe: validar origen, limitar tasa y tamaño, no registrar la clave ni el cuerpo completo, y devolver errores ya redactados.

## 6. Archivos modificados

| Archivo | Cambio |
|---|---|
| `src/services/ai/aiEngine.ts` | URL de Gemini sin `?key=`; cabecera `x-goog-api-key`; helper `redactSensitiveText`; helper `resolveCompatibleEndpoint`; redacción en errores de ambos proveedores y en el `catch` de `executeTask` |
| `src/__tests__/aiSecurity.test.ts` | **Nuevo.** 7 pruebas de regresión de seguridad |
| `docs/P1S_SECURITY_AUDIT.md` | **Nuevo.** Auditoría, hallazgos y clasificación |
| `docs/P1S_SECURITY_FIXES.md` | **Nuevo.** Este documento |
| `docs/P1S_SECURITY_TEST_RESULTS.md` | **Nuevo.** Evidencia de validación |

No se modificaron pruebas existentes, informes de auditoría previos, `main`, APK ni configuración de despliegue.

## 7. Verificación de que no hay otras claves en URLs

- `git grep` de `[?&](key|api_key|apikey|access_token|token|auth|secret)=` en `src/`: solo aparece el comentario explicativo del nuevo helper y el patrón de redacción (sin clave real).
- El bundle de producción no contiene `generateContent?key=` y sí contiene `x-goog-api-key` (ver `docs/P1S_SECURITY_TEST_RESULTS.md`).
- No hay `VITE_*`, `.env` versionado ni secretos literales en el repositorio.

## 8. Riesgos residuales

1. La clave sigue siendo visible para el usuario y para scripts del mismo origen (inherente al modelo cliente).
2. La redacción de errores es basada en patrones; cubre los formatos conocidos.
3. El token mock de `localStorage` (`estudio_cloud_session`) no es una credencial real; si se añade autenticación real, migrar a cookies `HttpOnly`/almacenamiento seguro nativo.
4. No se verificó una llamada real a Gemini/Groq (prohibido generar tráfico/costes en este encargo); la cabecera está respaldada por la documentación oficial y por las pruebas con `fetch` simulado.
5. `docs/PHASE_7A_AI_EXPERIENCE.md` afirma que la clave vive en `sessionStorage`; el código usa memoria. Inexactitud documental no corregida para no alterar el historial de fases.
