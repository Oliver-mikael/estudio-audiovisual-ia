# Hallazgos y Plan de Corrección

## P0 (bloqueantes)
- CR-01: TS no compila (renderEngine.ts, ProductionStudio.tsx).
- CR-02: tests persistencia fallan por entorno (indexedDB).

## P1 (alta)
- AL-01: audio cache key mismatch.
- AL-02: ducking no implementado.
- AL-03: export duration/timeline desync.
- AL-04: API key en query string.

## P2 (media)
- ME-01..05: caches sin límite, IDB sin migración, blobs huérfanos, usage count, setInterval drift.

## P3 (mejoras)
- OB-01: lint, E2E, perfiles export, low-end Android.

## Pruebas post-fix
- tsc --noEmit, npm run build, vitest con jsdom, export smoke test en navegador.
