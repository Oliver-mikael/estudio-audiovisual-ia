// Development-only real export smoke test.
// Builds a short project with generated pictures, voice, music and subtitles and
// runs the real exporter, then decodes the produced file again. Attached to
// window.__EAI_EXPORT_SMOKE__ by main.tsx so browser automation can execute it.
import { ExportProfile, MediaAsset, Project, TimelineClip, TimelineTrack } from '../types';
import { VideoExporter } from '../engine/exporter';
import { getProjectDurationMs } from '../engine/mediaComposition';
import type { ExportSettings } from '../services/export/exportPlan';

const WIDTH = 640;
const HEIGHT = 360;
const CLIP_MS = 2000;
const SCENE_COUNT = 3;

const PALETTE = [
  { from: '#1e1b4b', to: '#312e81', accent: '#818cf8', label: 'ESCENA 1' },
  { from: '#0f2f2b', to: '#065f46', accent: '#34d399', label: 'ESCENA 2' },
  { from: '#3b1220', to: '#7f1d1d', accent: '#f87171', label: 'ESCENA 3' },
];

function canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error('No se pudo generar la imagen de prueba.'));
    }, 'image/png');
  });
}

async function createFrameAsset(index: number): Promise<MediaAsset> {
  const palette = PALETTE[index];
  const canvas = document.createElement('canvas');
  canvas.width = WIDTH;
  canvas.height = HEIGHT;
  const ctx = canvas.getContext('2d')!;

  const gradient = ctx.createLinearGradient(0, 0, WIDTH, HEIGHT);
  gradient.addColorStop(0, palette.from);
  gradient.addColorStop(1, palette.to);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  ctx.fillStyle = palette.accent;
  ctx.fillRect(40, HEIGHT / 2 - 4, WIDTH - 80, 8);

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 44px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(palette.label, WIDTH / 2, HEIGHT / 2 + 60);

  ctx.font = '500 20px sans-serif';
  ctx.fillStyle = palette.accent;
  ctx.fillText(`CUADRO ${index + 1} DE ${SCENE_COUNT}`, WIDTH / 2, HEIGHT / 2 - 30);

  const blob = await canvasToBlob(canvas);

  return {
    id: `smoke-image-${index + 1}`,
    name: `smoke-frame-${index + 1}.png`,
    type: 'image',
    url: '',
    fileBlob: blob,
    mimeType: 'image/png',
    sizeBytes: blob.size,
    license: 'Custom / Owned',
    provenance: 'Generado por la prueba de exportación',
    createdAt: Date.now(),
    width: WIDTH,
    height: HEIGHT,
  };
}

function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  const writeString = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, samples.length * 2, true);

  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(44 + i * 2, clamped * 0x7fff, true);
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

function buildVoice(durationSeconds: number, sampleRate = 48000): Blob {
  const samples = new Float32Array(Math.floor(durationSeconds * sampleRate));
  // One 0.18s pulse every 0.5s: easy to hear and to detect in the exported file.
  for (let pulse = 0; pulse * 0.5 < durationSeconds; pulse++) {
    const start = Math.floor(pulse * 0.5 * sampleRate);
    const length = Math.floor(0.18 * sampleRate);
    const frequency = pulse % 2 === 0 ? 660 : 880;
    for (let i = 0; i < length && start + i < samples.length; i++) {
      const envelope = Math.sin((Math.PI * i) / length) ** 2;
      samples[start + i] = 0.55 * envelope * Math.sin((2 * Math.PI * frequency * i) / sampleRate);
    }
  }
  return encodeWav(samples, sampleRate);
}

function buildMusic(durationSeconds: number, sampleRate = 48000): Blob {
  const samples = new Float32Array(Math.floor(durationSeconds * sampleRate));
  const chord = [220, 277.18, 329.63];
  for (let i = 0; i < samples.length; i++) {
    const t = i / sampleRate;
    let value = 0;
    for (const frequency of chord) value += Math.sin(2 * Math.PI * frequency * t);
    samples[i] = 0.09 * (value / chord.length) * (0.7 + 0.3 * Math.sin(2 * Math.PI * 0.5 * t));
  }
  return encodeWav(samples, sampleRate);
}

function createAsset(
  id: string,
  name: string,
  type: 'audio',
  blob: Blob,
  durationSeconds: number
): MediaAsset {
  return {
    id,
    name,
    type,
    url: '',
    fileBlob: blob,
    mimeType: 'audio/wav',
    sizeBytes: blob.size,
    license: 'Custom / Owned',
    provenance: 'Generado por la prueba de exportación',
    createdAt: Date.now(),
    durationSeconds,
  };
}

function visualClip(id: string, assetId: string, startMs: number, transition: boolean, audioOffsetMs: number = 0): TimelineClip {
  return {
    id,
    name: assetId,
    trackId: 'track-v1',
    assetId,
    type: 'image',
    startMs,
    durationMs: CLIP_MS,
    offsetMs: 0,
    opacity: 1,
    volume: 1,
    speed: 1,
    audioOffset: audioOffsetMs,
    transform: { x: 0, y: 0, scale: 1, rotation: 0 },
    transition: transition
      ? { id: `${id}-fade`, type: 'fade', durationMs: 400, easing: 'ease-in-out' }
      : undefined,
  };
}

/**
 * Records a short WebM clip with picture *and* its own soundtrack. The embedded
 * tone is a 1200 Hz pulse train, which never appears in the timeline audio, so the
 * exported mix can prove the video's own audio was actually captured.
 */
async function recordTestVideo(seconds = 2): Promise<Blob> {
  const canvas = document.createElement('canvas');
  canvas.width = 320;
  canvas.height = 180;
  const ctx = canvas.getContext('2d')!;
  const stream = canvas.captureStream(30);
  const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
    ? 'video/webm;codecs=vp8,opus'
    : 'video/webm';

  const audioCtx = new AudioContext();
  await audioCtx.resume();
  const oscillator = audioCtx.createOscillator();
  const pulseGain = audioCtx.createGain();
  const audioDestination = audioCtx.createMediaStreamDestination();

  oscillator.type = 'sine';
  oscillator.frequency.setValueAtTime(1200, audioCtx.currentTime);
  pulseGain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
  for (let start = 0; start < seconds; start += 0.4) {
    pulseGain.gain.setValueAtTime(0.0001, audioCtx.currentTime + start);
    pulseGain.gain.linearRampToValueAtTime(0.45, audioCtx.currentTime + start + 0.02);
    pulseGain.gain.setValueAtTime(0.45, audioCtx.currentTime + start + 0.16);
    pulseGain.gain.linearRampToValueAtTime(0.0001, audioCtx.currentTime + start + 0.2);
  }
  oscillator.connect(pulseGain);
  pulseGain.connect(audioDestination);
  oscillator.start();

  const combinedStream = new MediaStream([
    ...stream.getVideoTracks(),
    ...audioDestination.stream.getAudioTracks(),
  ]);

  const recorder = new MediaRecorder(combinedStream, { mimeType });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size > 0) chunks.push(event.data);
  };

  const stopped = new Promise<Blob>((resolve) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType }));
  });

  recorder.start(100);
  const startedAt = performance.now();

  await new Promise<void>((resolve) => {
    const draw = () => {
      const elapsed = (performance.now() - startedAt) / 1000;
      if (elapsed >= seconds) {
        resolve();
        return;
      }
      // Bright yellow base with a blue bar sweeping left to right: easy to detect
      // in the exported file and to prove the video track actually advanced.
      ctx.fillStyle = '#facc15';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      const barX = (elapsed / seconds) * (canvas.width - 60);
      ctx.fillStyle = '#1d4ed8';
      ctx.fillRect(barX, 0, 60, canvas.height);
      requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);
  });

  recorder.stop();
  stream.getTracks().forEach((track) => track.stop());
  const blob = await stopped;
  oscillator.stop();
  pulseGain.disconnect();
  audioDestination.disconnect();
  await audioCtx.close();
  return blob;
}

/**
 * Decodes the exported file's audio and reports its RMS energy per window, so the
 * mix can be checked in time (which source was audible, and when).
 */
async function analyzeAudioWindows(
  blob: Blob,
  windowSeconds = 0.25
): Promise<{ durationSeconds: number; windows: Array<{ startSeconds: number; rms: number }> } | null> {
  try {
    const offline = new OfflineAudioContext(1, 1, 48000);
    const buffer = await offline.decodeAudioData(await blob.arrayBuffer());
    if (!buffer || buffer.length === 0) return null;

    const channels: Float32Array[] = [];
    for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
      channels.push(buffer.getChannelData(channel));
    }

    const windowSamples = Math.max(1, Math.floor(windowSeconds * buffer.sampleRate));
    const windows: Array<{ startSeconds: number; rms: number }> = [];
    for (let offset = 0; offset < buffer.length; offset += windowSamples) {
      const end = Math.min(buffer.length, offset + windowSamples);
      let sum = 0;
      let count = 0;
      for (let i = offset; i < end; i++) {
        let sample = 0;
        for (const channel of channels) sample += channel[i] || 0;
        sample /= channels.length;
        sum += sample * sample;
        count++;
      }
      windows.push({
        startSeconds: Math.round((offset / buffer.sampleRate) * 100) / 100,
        rms: Math.round(Math.sqrt(sum / Math.max(1, count)) * 10000) / 10000,
      });
    }

    return { durationSeconds: buffer.duration, windows };
  } catch {
    return null;
  }
}

function captionClip(id: string, startMs: number, text: string): TimelineClip {
  return {
    id,
    name: 'Subtítulo',
    trackId: 'track-t1',
    type: 'caption',
    startMs,
    durationMs: CLIP_MS,
    offsetMs: 0,
    opacity: 1,
    textPayload: text,
  };
}

interface BuildProjectOptions {
  includeVideo?: boolean;
  /** Leaves the A1/A2 tracks empty so only the video's own audio can be heard. */
  omitTrackAudio?: boolean;
  /** Forces the video clip volume to 0 to prove its audio is really gated. */
  muteVideoAudio?: boolean;
  /** Audio offset in ms for J/L cut testing (positive = J-cut, negative = L-cut). */
  audioOffsetMs?: number;
  /** Film grain amount (0-0.2). */
  filmGrainAmount?: number;
}

async function buildProject(options: BuildProjectOptions = {}): Promise<Project> {
  const { includeVideo = false, omitTrackAudio = false, muteVideoAudio = false, audioOffsetMs = 0, filmGrainAmount = 0.08 } = options;
  const durationSeconds = (SCENE_COUNT * CLIP_MS) / 1000;
  const images = await Promise.all(
    Array.from({ length: SCENE_COUNT }, (_, index) => createFrameAsset(index))
  );

  let videoAsset: MediaAsset | null = null;
  if (includeVideo) {
    const videoBlob = await recordTestVideo(2);
    videoAsset = {
      id: 'smoke-video',
      name: 'smoke-video.webm',
      type: 'video',
      url: '',
      fileBlob: videoBlob,
      mimeType: videoBlob.type || 'video/webm',
      sizeBytes: videoBlob.size,
      license: 'Custom / Owned',
      provenance: 'Generado por la prueba de exportación',
      createdAt: Date.now(),
      durationSeconds: 2,
    };
  }
  const voice = createAsset(
    'smoke-voice',
    'smoke-voice.wav',
    'audio',
    buildVoice(durationSeconds),
    durationSeconds
  );
  const music = createAsset(
    'smoke-music',
    'smoke-music.wav',
    'audio',
    buildMusic(durationSeconds),
    durationSeconds
  );

  const tracks: TimelineTrack[] = [
    {
      id: 'track-v1',
      name: 'Video 1 (Base)',
      type: 'video',
      order: 0,
      isMuted: false,
      isLocked: false,
      isVisible: true,
      clips: images.map((asset, index) =>
        visualClip(`smoke-v1-${index}`, asset.id, index * CLIP_MS, index > 0, audioOffsetMs)
      ),
    },
    {
      id: 'track-v2',
      name: 'Video 2 (Capas / Overlays)',
      type: 'video',
      order: 1,
      isMuted: false,
      isLocked: false,
      isVisible: true,
      clips: videoAsset
        ? [
            {
              id: 'smoke-v2',
              name: 'Clip de video real',
              trackId: 'track-v2',
              assetId: videoAsset.id,
              type: 'video',
              startMs: 0,
              durationMs: 2000,
              offsetMs: 0,
              opacity: 1,
              volume: muteVideoAudio ? 0 : 1,
              speed: 1,
              transform: { x: 0, y: 0, scale: 0.45, rotation: 0 },
            },
          ]
        : [],
    },
    {
      id: 'track-a1',
      name: 'Audio 1 (Locución)',
      type: 'audio',
      order: 2,
      isMuted: false,
      isLocked: false,
      isVisible: true,
      clips: omitTrackAudio
        ? []
        : [
            {
              id: 'smoke-a1',
              name: 'Voz de prueba',
              trackId: 'track-a1',
              assetId: voice.id,
              type: 'audio',
              startMs: 0,
              durationMs: SCENE_COUNT * CLIP_MS,
              offsetMs: 0,
              volume: 1,
              speed: 1,
              audioOffset: audioOffsetMs,
            },
          ],
    },
    {
      id: 'track-a2',
      name: 'Audio 2 (Música)',
      type: 'audio',
      order: 3,
      isMuted: false,
      isLocked: false,
      isVisible: true,
      clips: omitTrackAudio
        ? []
        : [
            {
              id: 'smoke-a2',
              name: 'Música de prueba',
              trackId: 'track-a2',
              assetId: music.id,
              type: 'audio',
              startMs: 0,
              durationMs: SCENE_COUNT * CLIP_MS,
              offsetMs: 0,
              volume: 1,
              speed: 1,
              audioOffset: audioOffsetMs,
            },
          ],
    },
    {
      id: 'track-t1',
      name: 'Texto 1 (Subtítulos)',
      type: 'text',
      order: 4,
      isMuted: false,
      isLocked: false,
      isVisible: true,
      clips: [
        captionClip('smoke-sub-1', 0, 'Prueba real de exportación'),
        captionClip('smoke-sub-2', CLIP_MS, 'Subtítulos sincronizados'),
        captionClip('smoke-sub-3', CLIP_MS * 2, 'Audio y video alineados'),
      ],
    },
  ];

  return {
    id: 'export-smoke-test',
    title: 'Prueba Exportación Real',
    description: 'Proyecto sintético con imágenes, voz, música y subtítulos.',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    angles: [],
    sources: [],
    script: {
      title: 'Prueba Exportación Real',
      summary: '',
      targetAudience: '',
      tone: 'Divulgativo',
      scenes: [],
    },
    mediaAssets: [...images, ...(videoAsset ? [videoAsset] : []), voice, music],
    settings: {
      fps: 30,
      resolution: { width: WIDTH, height: HEIGHT },
      aspectRatio: '16:9',
      filmGrain: { enabled: true, amount: filmGrainAmount },
      filmGrainEnabled: true,
      filmGrainAmount: filmGrainAmount,
    },
    timeline: { tracks },
  };
}

function toBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export interface ExportSmokeTestResult {
  ok: boolean;
  sizeBytes: number;
  mimeType: string;
  /** Real output of the resolved export plan (size, fps, container, warnings). */
  plan: Awaited<ReturnType<typeof VideoExporter.exportProjectVideo>>['plan'] | null;
  durationSeconds: number;
  verification: Awaited<ReturnType<typeof VideoExporter.exportProjectVideo>>['verification'];
  progressMessages: string[];
  audioWindows: Array<{ startSeconds: number; rms: number }> | null;
  /** Mean RMS inside the video clip window (0.2s-1.8s). */
  videoWindowRms: number | null;
  /** Mean RMS after the video clip ends (2.4s-5.4s). */
  afterVideoRms: number | null;
}

export interface ExportSmokeOptions {
  width?: number;
  height?: number;
  fps?: number;
  includeVideo?: boolean;
  omitTrackAudio?: boolean;
  muteVideoAudio?: boolean;
  /** Audio offset in ms for J/L cut testing. */
  audioOffsetMs?: number;
  /** Film grain amount (0-0.2). */
  filmGrainAmount?: number;
  /** Exercises the real settings -> plan -> recorder path. */
  settings?: ExportSettings;
}

function meanRmsInRange(
  windows: Array<{ startSeconds: number; rms: number }> | null,
  fromSeconds: number,
  toSeconds: number
): number | null {
  if (!windows || windows.length === 0) return null;
  const selected = windows.filter(
    (window) => window.startSeconds >= fromSeconds && window.startSeconds < toSeconds
  );
  if (selected.length === 0) return null;
  const total = selected.reduce((sum, window) => sum + window.rms, 0);
  return Math.round((total / selected.length) * 10000) / 10000;
}

export async function runExportSmokeTest(
  options: ExportSmokeOptions = {}
): Promise<ExportSmokeTestResult> {
  const project = await buildProject({
    includeVideo: Boolean(options.includeVideo),
    omitTrackAudio: Boolean(options.omitTrackAudio),
    muteVideoAudio: Boolean(options.muteVideoAudio),
    audioOffsetMs: options.audioOffsetMs,
    filmGrainAmount: options.filmGrainAmount,
  });
  const exportWidth = options.width ?? WIDTH;
  const exportHeight = options.height ?? HEIGHT;
  const profile: ExportProfile = {
    id: 'smoke-profile',
    name: 'Prueba de exportación',
    format: 'webm',
    aspectRatio: '16:9',
    resolution: { width: exportWidth, height: exportHeight },
    fps: (options.fps ?? 30) as ExportProfile['fps'],
    bitrateBps: 1_600_000,
    includeAudio: true,
    description: 'Perfil corto de verificación de exportación.',
  };

  const progressMessages: string[] = [];
  const result = await VideoExporter.exportProjectVideo(
    project,
    (progress, message) => progressMessages.push(`${progress}% ${message}`),
    options.settings ? { settings: options.settings } : { profile }
  );

  const bytes = new Uint8Array(await result.blob.arrayBuffer());
  const audioWindows = await analyzeAudioWindows(result.blob, 0.2);
  (window as unknown as Record<string, unknown>).__EAI_LAST_EXPORT__ = {
    base64: toBase64(bytes),
    mimeType: result.mimeType,
    extension: result.extension,
    width: result.width,
    height: result.height,
    fps: result.fps,
    expectedDurationSeconds: getProjectDurationMs(project) / 1000,
    verification: result.verification,
    audioWindows: audioWindows?.windows ?? null,
    plan: result.plan ?? null,
  };

  return {
    ok: Boolean(result.verification?.ok),
    sizeBytes: result.blob.size,
    mimeType: result.mimeType,
    plan: result.plan ?? null,
    durationSeconds: result.durationSeconds,
    verification: result.verification,
    progressMessages: progressMessages.slice(-4),
    audioWindows: audioWindows?.windows ?? null,
    videoWindowRms: meanRmsInRange(audioWindows?.windows ?? null, 0.2, 1.8),
    afterVideoRms: meanRmsInRange(audioWindows?.windows ?? null, 2.4, 5.4),
  };
}
