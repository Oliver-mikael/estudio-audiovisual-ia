import { describe, it, expect } from 'vitest';
import { getAssetDisplayUrl } from '../services/media/thumbnailService';
import { MediaAsset } from '../types';

const base: MediaAsset = {
  id: 'asset-1',
  name: 'imagen.png',
  type: 'image',
  url: '',
  mimeType: 'image/png',
  sizeBytes: 1024,
  license: 'Custom / Owned',
  provenance: 'test',
  createdAt: 1,
};

describe('getAssetDisplayUrl', () => {
  it('prefers the persisted thumbnail', () => {
    expect(
      getAssetDisplayUrl({ ...base, thumbnailUrl: 'data:image/jpeg;base64,abc', url: 'https://x/y.png' })
    ).toBe('data:image/jpeg;base64,abc');
  });

  it('falls back to a remote url when there is no thumbnail', () => {
    expect(getAssetDisplayUrl({ ...base, url: 'https://x/y.png' })).toBe('https://x/y.png');
  });

  it('ignores dead object urls from a previous session', () => {
    expect(getAssetDisplayUrl({ ...base, url: 'blob:https://app/1234' })).toBeUndefined();
  });
});
