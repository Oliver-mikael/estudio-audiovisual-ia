// Regression tests for AL-01 (audio buffer cache key mismatch) and
// AL-02 (auto-ducking declared but never applied).
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { AudioEngine } from '../services/audio/AudioEngine';
import { AudioMixer } from '../services/audio/AudioMixer';
import { Project, MediaAsset } from '../types';

class MockGainNode {
  gain = {
    value: 1,
    setValueAtTime: vi.fn((value: number) => {
      this.gain.value = value;
    }),
    linearRampToValueAtTime: vi.fn((value: number, _startTime?: number) => {
      this.gain.value = value;
    }),
  };
  connect = vi.fn();
  disconnect = vi.fn();
}

class MockAudioBufferSourceNode {
  buffer: unknown = null;
  playbackRate = { value: 1 };
  connect = vi.fn();
  disconnect = vi.fn();
  start = vi.fn();
  stop = vi.fn();
  onended: (() => void) | null = null;
}

class MockOscillatorNode {
  type = 'sine';
  frequency = { value: 220, setValueAtTime: vi.fn() };
  connect = vi.fn();
  disconnect = vi.fn();
  start = vi.fn();
  stop = vi.fn();
}

class MockAudioContext {
  state = 'running';
  currentTime = 0;
  createGain = vi.fn(() => new MockGainNode());
  createBufferSource = vi.fn(() => new MockAudioBufferSourceNode());
  createOscillator = vi.fn(() => new MockOscillatorNode());
  createMediaStreamDestination = vi.fn(() => ({
    stream: { getAudioTracks: () => [{} as MediaStreamTrack] },
  }));
  decodeAudioData = vi.fn(async (_buffer: ArrayBuffer) => ({
    duration: 5,
    numberOfChannels: 2,
    sampleRate: 44100,
    length: 220500,
  }));
  resume = vi.fn(async () => {});
  close = vi.fn(async () => {});
}

const VOICE_URL = 'blob:mock/imported-voice';

function makeProject(options: {
  assetId?: string;
  withAsset?: boolean;
  narrationMuted?: boolean;
  includeMusicTrack?: boolean;
} = {}): Project {
  const { assetId, withAsset = false, narrationMuted = false, includeMusicTrack = true } = options;

  const mediaAssets: MediaAsset[] = withAsset && assetId
    ? [
        {
          id: assetId,
          name: 'Voz importada',
          type: 'audio',
          url: VOICE_URL,
          mimeType: 'audio/webm',
          sizeBytes: 3,
          license: 'Propietario',
          provenance: 'Import',
          createdAt: 1,
          fileBlob: new Blob([new Uint8Array([1, 2, 3])], { type: 'audio/webm' }),
        },
      ]
    : [];

  return {
    id: 'proj_audio_regression',
    title: 'Audio regression',
    description: '',
    createdAt: 1,
    updatedAt: 1,
    angles: [],
    sources: [],
    script: {
      title: 'Script',
      summary: '',
      targetAudience: 'General',
      tone: 'Divulgativo',
      scenes: [
        {
          id: 'sc_1',
          title: 'Escena 1',
          visualIntent: 'Visual',
          narrationText: 'Locución de prueba',
          durationSeconds: 2,
          cameraMotion: 'Static',
          transition: 'Fade',
        },
      ],
    },
    mediaAssets,
    settings: {
      resolution: { width: 1280, height: 720 },
      fps: 30,
      aspectRatio: '16:9',
    },
    timeline: {
      tracks: [
        {
          id: 'track-a1',
          name: 'Audio 1 (Locución)',
          type: 'audio',
          order: 2,
          isMuted: narrationMuted,
          isLocked: false,
          isVisible: true,
          clips: [
            {
              id: 'clip_a1',
              trackId: 'track-a1',
              type: 'audio',
              name: 'Locución',
              startMs: 1000,
              durationMs: 1000,
              offsetMs: 0,
              volume: 1,
              assetId,
            },
          ],
        },
        ...(includeMusicTrack
          ? [
              {
                id: 'track-a2',
                name: 'Audio 2 (Música)',
                type: 'audio' as const,
                order: 5,
                isMuted: false,
                isLocked: false,
                isVisible: true,
                clips: [
                  {
                    id: 'clip_a2',
                    trackId: 'track-a2',
                    type: 'audio' as const,
                    name: 'Música',
                    startMs: 0,
                    durationMs: 4000,
                    offsetMs: 0,
                    volume: 1,
                  },
                ],
              },
            ]
          : []),
      ],
      markers: [],
    },
  };
}

function contextOf(engine: AudioEngine): MockAudioContext {
  return engine.getContext() as unknown as MockAudioContext;
}

function rampValues(node: MockGainNode): number[] {
  return node.gain.linearRampToValueAtTime.mock.calls.map((call) => call[0] as number);
}

describe('AL-01: caché de buffers de audio por assetId', () => {
  beforeEach(() => {
    (global as any).window = global;
    (global as any).AudioContext = MockAudioContext;
    (global as any).webkitAudioContext = MockAudioContext;
  });

  afterEach(() => {
    AudioEngine.getInstance().dispose();
    vi.unstubAllGlobals();
  });

  it('reutiliza para el clip un buffer cargado por URL del asset (sin re-decodificar)', async () => {
    const engine = AudioEngine.getInstance();
    const project = makeProject({ assetId: 'asset_voice', withAsset: true });
    const asset = project.mediaAssets![0];

    await engine.loadBuffer(asset.url, asset.fileBlob);
    await engine.play(project, 0);

    const ctx = contextOf(engine);
    expect(ctx.createBufferSource).toHaveBeenCalledTimes(1);
    expect(ctx.decodeAudioData).toHaveBeenCalledTimes(1);

    const source = ctx.createBufferSource.mock.results[0].value as MockAudioBufferSourceNode;
    expect(source.buffer).toBeTruthy();
    expect(source.start).toHaveBeenCalled();
  });

  it('precarga el binario del timeline y lo indexa por assetId', async () => {
    const engine = AudioEngine.getInstance();
    const project = makeProject({ assetId: 'asset_voice', withAsset: true });

    const result = await engine.preloadProjectAudio(project);

    expect(result.loadedCount).toBe(1);
    expect(result.failedClipAssetIds).toEqual([]);

    await engine.play(project, 0);
    const ctx = contextOf(engine);
    expect(ctx.createBufferSource).toHaveBeenCalledTimes(1);
    expect(ctx.decodeAudioData).toHaveBeenCalledTimes(1);
  });

  it('reporta assets sin binario disponible y usa el tono sintético como fallback', async () => {
    const engine = AudioEngine.getInstance();
    const project = makeProject({ assetId: 'asset_missing', withAsset: false });

    const result = await engine.preloadProjectAudio(project);
    expect(result.loadedCount).toBe(0);
    expect(result.failedClipAssetIds).toEqual(['asset_missing']);

    await engine.play(project, 0);
    const ctx = contextOf(engine);
    expect(ctx.createBufferSource).not.toHaveBeenCalled();
    expect(ctx.createOscillator).toHaveBeenCalled();
  });
});

describe('AL-02: auto-ducking aplicado sobre las pistas de fondo', () => {
  beforeEach(() => {
    (global as any).window = global;
    (global as any).AudioContext = MockAudioContext;
    (global as any).webkitAudioContext = MockAudioContext;
  });

  afterEach(() => {
    AudioEngine.getInstance().dispose();
    vi.unstubAllGlobals();
  });

  it('construye las opciones de ducking desde la mezcladora (A2 al 60%)', () => {
    const mixer = new AudioMixer();
    const options = mixer.getDuckingOptions();

    expect(options.enabled).toBe(true);
    expect(options.triggerTrackIds).toEqual(['track-a1']);
    expect(options.amountByTrackId?.['track-a2']).toBeCloseTo(0.6, 5);
    expect(options.amountByTrackId?.['track-a1']).toBeUndefined();

    mixer.setDuckingEnabled(false);
    expect(mixer.getDuckingOptions().enabled).toBe(false);
  });

  it('atenúa A2 durante la locución y recupera el nivel nominal 300 ms después', async () => {
    const engine = AudioEngine.getInstance();
    const mixer = new AudioMixer();
    await engine.initContext();
    engine.setupTracks(mixer.getTrackConfigs());

    const project = makeProject({ includeMusicTrack: true });
    await engine.play(project, 0, mixer.getDuckingOptions());

    const musicGain = engine.getTrackGainNode('track-a2') as unknown as MockGainNode;
    expect(musicGain).toBeDefined();

    const calls = musicGain.gain.linearRampToValueAtTime.mock.calls;
    const ducked = calls.find((call) => (call[0] as number) < 0.25);
    const recovered = calls.find((call) => (call[0] as number) === 0.25);

    expect(ducked).toBeDefined();
    // Base A2 = 0.25; reducción del 60% => 0.25 * 0.4 = 0.1
    expect(ducked![0]).toBeCloseTo(0.1, 5);
    // La locución empieza en 1000 ms => la atenuación llega a 1.0 s de reproducción
    expect(ducked![1]).toBeCloseTo(1.0, 5);
    expect(recovered).toBeDefined();
    // Cese en 2000 ms + 300 ms de recuperación => 2.3 s
    expect(recovered![1]).toBeCloseTo(2.3, 5);
  });

  it('no automatiza ganancia cuando el ducking está deshabilitado', async () => {
    const engine = AudioEngine.getInstance();
    const mixer = new AudioMixer();
    await engine.initContext();
    engine.setupTracks(mixer.getTrackConfigs());

    const ducking = { ...mixer.getDuckingOptions(), enabled: false };
    await engine.play(makeProject(), 0, ducking);

    const musicGain = engine.getTrackGainNode('track-a2') as unknown as MockGainNode;
    expect(rampValues(musicGain)).toHaveLength(0);
  });

  it('mantiene silenciada la pista A2 si está en mute', async () => {
    const engine = AudioEngine.getInstance();
    const mixer = new AudioMixer();
    mixer.toggleMute('track-a2');
    await engine.initContext();
    engine.setupTracks(mixer.getTrackConfigs());

    await engine.play(makeProject(), 0, mixer.getDuckingOptions());

    const musicGain = engine.getTrackGainNode('track-a2') as unknown as MockGainNode;
    expect(rampValues(musicGain).every((value) => value === 0)).toBe(true);
  });

  it('no atenúa si la pista de locución está silenciada', async () => {
    const engine = AudioEngine.getInstance();
    const mixer = new AudioMixer();
    await engine.initContext();
    engine.setupTracks(mixer.getTrackConfigs());

    await engine.play(makeProject({ narrationMuted: true }), 0, mixer.getDuckingOptions());

    const musicGain = engine.getTrackGainNode('track-a2') as unknown as MockGainNode;
    expect(rampValues(musicGain)).toHaveLength(0);
  });
});
