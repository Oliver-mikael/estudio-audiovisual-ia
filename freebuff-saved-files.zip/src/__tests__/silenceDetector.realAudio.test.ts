import { describe, it, expect } from 'vitest';
import { readFileSync } from 'fs';
import { resolve } from 'path';
import { SilenceDetector } from '../services/audio/silenceDetector';

function parseWavSamples(filePath: string): { samples: Float32Array; sampleRate: number } {
  const buf = readFileSync(filePath);
  // Parse WAV header
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  // Find 'fmt ' chunk
  let offset = 12; // Skip RIFF header
  let sampleRate = 44100;
  let bitsPerSample = 16;
  let numChannels = 1;
  let dataOffset = 0;
  let dataSize = 0;

  while (offset < buf.length - 8) {
    const chunkId = String.fromCharCode(buf[offset], buf[offset + 1], buf[offset + 2], buf[offset + 3]);
    const chunkSize = view.getUint32(offset + 4, true);
    if (chunkId === 'fmt ') {
      numChannels = view.getUint16(offset + 10, true);
      sampleRate = view.getUint32(offset + 12, true);
      bitsPerSample = view.getUint16(offset + 22, true);
    } else if (chunkId === 'data') {
      dataOffset = offset + 8;
      dataSize = chunkSize;
      break;
    }
    offset += 8 + chunkSize;
    if (chunkSize % 2 !== 0) offset += 1; // pad
  }

  const bytesPerSample = bitsPerSample / 8;
  const totalSamples = dataSize / (bytesPerSample * numChannels);
  const samples = new Float32Array(totalSamples);

  for (let i = 0; i < totalSamples; i++) {
    if (bitsPerSample === 16) {
      const idx = dataOffset + i * numChannels * 2;
      samples[i] = view.getInt16(idx, true) / 32768;
    }
  }

  return { samples, sampleRate };
}

describe('Silence Detector with real audio', () => {
  it('detects the 3 silence segments in test audio', () => {
    const wavPath = resolve(__dirname, '../../public/test-audio/test_silence.wav');
    const { samples, sampleRate } = parseWavSamples(wavPath);

    const segments = SilenceDetector.detectFromSamples(samples, sampleRate, {
      thresholdDb: -40,
      minDurationMs: 500,
      windowMs: 50,
    });

    // Expected silences: 4-7s, 11-14s, 18-20s
    expect(segments.length).toBeGreaterThanOrEqual(3);

    // Check first silence is around 4-7s
    const firstSilence = segments[0];
    expect(firstSilence.startMs).toBeGreaterThanOrEqual(3500);
    expect(firstSilence.startMs).toBeLessThanOrEqual(4500);
    expect(firstSilence.endMs).toBeGreaterThanOrEqual(6500);
    expect(firstSilence.endMs).toBeLessThanOrEqual(7500);

    // Check second silence is around 11-14s
    const secondSilence = segments[1];
    expect(secondSilence.startMs).toBeGreaterThanOrEqual(10500);
    expect(secondSilence.startMs).toBeLessThanOrEqual(11500);
    expect(secondSilence.endMs).toBeGreaterThanOrEqual(13500);
    expect(secondSilence.endMs).toBeLessThanOrEqual(14500);

    // Check third silence is around 18-20s
    const thirdSilence = segments[2];
    expect(thirdSilence.startMs).toBeGreaterThanOrEqual(17500);
    expect(thirdSilence.startMs).toBeLessThanOrEqual(18500);
    expect(thirdSilence.endMs).toBeGreaterThanOrEqual(19500);
  });

  it('detects silences with different thresholds', () => {
    const wavPath = resolve(__dirname, '../../public/test-audio/test_silence.wav');
    const { samples, sampleRate } = parseWavSamples(wavPath);

    // With -20 dB threshold, should still detect the silences
    const segments = SilenceDetector.detectFromSamples(samples, sampleRate, {
      thresholdDb: -20,
      minDurationMs: 500,
      windowMs: 50,
    });

    expect(segments.length).toBeGreaterThanOrEqual(3);
  });

  it('does not detect silences with very short min duration', () => {
    const wavPath = resolve(__dirname, '../../public/test-audio/test_silence.wav');
    const { samples, sampleRate } = parseWavSamples(wavPath);

    // With very high min duration, should detect fewer or no segments
    const segments = SilenceDetector.detectFromSamples(samples, sampleRate, {
      thresholdDb: -40,
      minDurationMs: 5000,
      windowMs: 50,
    });

    // The 4-7s silence is 3s, 11-14s is 3s, 18-20s is 2s. All < 5s, so no segments
    expect(segments.length).toBe(0);
  });
});
