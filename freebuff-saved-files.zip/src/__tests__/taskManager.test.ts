// Tests for the persistent background task queue: ordering, retries, cancel,
// pause/resume and recovery of interrupted work after a restart.
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { BackgroundTaskManager } from '../services/jobs/taskManager';

class MemoryStorage {
  private map = new Map<string, string>();
  getItem(key: string) {
    return this.map.get(key) ?? null;
  }
  setItem(key: string, value: string) {
    this.map.set(key, value);
  }
  removeItem(key: string) {
    this.map.delete(key);
  }
  clear() {
    this.map.clear();
  }
}

async function waitFor(predicate: () => boolean, timeoutMs = 2000): Promise<void> {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error('waitFor timeout');
    await new Promise((resolve) => setTimeout(resolve, 5));
  }
}

describe('BackgroundTaskManager', () => {
  const originalStorage = (globalThis as { localStorage?: unknown }).localStorage;

  beforeEach(() => {
    (globalThis as { localStorage?: unknown }).localStorage = new MemoryStorage();
  });

  afterEach(() => {
    (globalThis as { localStorage?: unknown }).localStorage = originalStorage;
    vi.restoreAllMocks();
  });

  it('ejecuta las tareas en orden FIFO y marca progreso', async () => {
    const manager = new BackgroundTaskManager();
    const order: string[] = [];

    manager.registerHandler('AUTOSAVE', async (task, ctx) => {
      ctx.update({ progress: 50, message: 'mitad' });
      order.push(task.label);
    });

    manager.enqueue({ kind: 'AUTOSAVE', label: 'primera' });
    manager.enqueue({ kind: 'AUTOSAVE', label: 'segunda' });

    await waitFor(
      () => manager.getTasks().filter((task) => task.status === 'completed').length === 2
    );

    expect(order).toEqual(['primera', 'segunda']);
    expect(manager.getTasks().every((task) => task.progress === 100)).toBe(true);
  });

  it('reintenta un fallo transitorio y termina completada', async () => {
    const manager = new BackgroundTaskManager();
    let attempts = 0;
    manager.registerHandler('BACKUP', async () => {
      attempts += 1;
      if (attempts < 2) throw new Error('red');
    });

    manager.enqueue({ kind: 'BACKUP', label: 'respaldo', maxAttempts: 2 });
    await waitFor(() => manager.getTasks()[0].status === 'completed');

    expect(attempts).toBe(2);
    expect(manager.getTasks()[0].attempts).toBe(2);
  });

  it('marca fallo definitivo cuando se agotan los intentos', async () => {
    const manager = new BackgroundTaskManager();
    manager.registerHandler('EXPORT', async () => {
      throw new Error('sin memoria');
    });

    manager.enqueue({ kind: 'EXPORT', label: 'export', maxAttempts: 1 });
    await waitFor(() => manager.getTasks()[0].status === 'failed');

    expect(manager.getTasks()[0].error).toBe('sin memoria');
  });

  it('cancela una tarea en ejecución y aborta su señal', async () => {
    const manager = new BackgroundTaskManager();
    let aborted = false;
    manager.registerHandler('EXPORT', async (_task, ctx) => {
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(resolve, 500);
        ctx.signal.addEventListener('abort', () => {
          aborted = true;
          clearTimeout(timer);
          reject(new DOMException('cancelada', 'AbortError'));
        });
      });
    });

    const task = manager.enqueue({ kind: 'EXPORT', label: 'export largo' });
    await waitFor(() => manager.getTask(task.id)?.status === 'running');
    manager.cancel(task.id);
    await waitFor(() => manager.getTask(task.id)?.status === 'cancelled');

    expect(aborted).toBe(true);
  });

  it('pausa y reanuda una tarea', async () => {
    const manager = new BackgroundTaskManager();
    let runs = 0;
    manager.registerHandler('SYNC', async (_task, ctx) => {
      runs += 1;
      if (runs === 1) {
        await new Promise<void>((_resolve, reject) => {
          ctx.signal.addEventListener('abort', () =>
            reject(new DOMException('pausada', 'AbortError'))
          );
        });
      }
    });

    const task = manager.enqueue({ kind: 'SYNC', label: 'sync' });
    await waitFor(() => manager.getTask(task.id)?.status === 'running');
    manager.pause(task.id);
    await waitFor(() => manager.getTask(task.id)?.status === 'paused');

    manager.resume(task.id);
    await waitFor(() => manager.getTask(task.id)?.status === 'completed');
    expect(runs).toBe(2);
  });

  it('recupera tareas interrumpidas tras reiniciar la aplicación', async () => {
    const first = new BackgroundTaskManager();
    const gate: { release?: () => void } = {};
    first.registerHandler('BACKUP', async () => {
      await new Promise<void>((resolve) => {
        gate.release = resolve;
      });
    });
    first.enqueue({ kind: 'BACKUP', label: 'respaldo largo' });
    await waitFor(() => first.getTasks()[0].status === 'running');

    // Simulate the app being killed while the task was still running: the
    // persisted state says `running`, which the next session turns into
    // `interrupted`.
    const restarted = new BackgroundTaskManager();
    expect(restarted.getTasks()[0].status).toBe('interrupted');

    let reran = false;
    restarted.registerHandler('BACKUP', async () => {
      reran = true;
    });
    expect(restarted.resumeInterrupted()).toBe(1);
    await waitFor(() => restarted.getTasks()[0].status === 'completed');
    expect(reran).toBe(true);
    gate.release?.();
  });

  it('persiste el estado y expone tareas pendientes', () => {
    const manager = new BackgroundTaskManager();
    manager.registerHandler('CLEANUP', async () => {});
    const task = manager.enqueue({ kind: 'CLEANUP', label: 'limpieza', requiresAppOpen: false });

    const stored = JSON.parse(localStorage.getItem('estudio_background_tasks_v1') || '[]');
    expect(stored[0].id).toBe(task.id);
    expect(manager.getTask(task.id)?.requiresAppOpen).toBe(false);
  });
});
