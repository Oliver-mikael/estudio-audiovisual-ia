// Tests for cloud integrity hashing, upload planning, backup/restore and
// conflict resolution using an in-memory provider (no network).
import { describe, it, expect, beforeEach } from 'vitest';
import type { Project } from '../types';
import {
  saveMediaAssetBlob,
  saveProjectToStorage,
  getProjectFromStorage,
  getMediaAssetBlob,
  getAllProjectsFromStorage,
  deleteProjectFromStorage,
} from '../services/storage/db';
import {
  BACKUP_MANIFEST_NAME,
  buildBackupManifest,
  planBackupUploads,
  resolveProjectConflict,
  restoreFromBackup,
  runBackup,
} from '../services/cloud/backupEngine';
import { md5Hex, md5Blob, sha256Blob } from '../services/cloud/hash';
import type {
  CloudProvider,
  CloudStatus,
  RemoteFile,
  UploadRequest,
} from '../services/cloud/types';

const encoder = new TextEncoder();

function makeProject(overrides: Partial<Project> = {}): Project {
  return {
    id: 'proj-cloud-1',
    title: 'Proyecto Nube',
    description: 'prueba',
    createdAt: 1000,
    updatedAt: 2000,
    angles: [],
    sources: [],
    script: {
      title: 'Guion',
      summary: '',
      targetAudience: 'General',
      tone: 'Divulgativo',
      scenes: [],
    },
    mediaAssets: [
      {
        id: 'asset-audio-1',
        name: 'voz.wav',
        type: 'audio',
        url: '',
        mimeType: 'audio/wav',
        sizeBytes: 11,
        license: 'propia',
        provenance: 'prueba',
        createdAt: 1500,
      },
    ],
    settings: { fps: 30, resolution: { width: 1280, height: 720 }, aspectRatio: '16:9' },
    ...overrides,
  };
}

class MemoryProvider implements CloudProvider {
  id = 'google-drive' as const;
  label = 'Memoria';
  limitations: string[] = [];
  supportsResume = true;
  files = new Map<string, { blob: Blob; checksum: string; modifiedAt: number }>();
  uploads = 0;
  failOnce = new Set<string>();

  isConfigured() {
    return true;
  }
  async connect(): Promise<CloudStatus> {
    return this.getStatus();
  }
  disconnect() {}
  async getStatus(): Promise<CloudStatus> {
    return { providerId: this.id, configured: true, connected: true };
  }
  async ensureFolder(): Promise<string> {
    return 'folder';
  }
  async list(): Promise<RemoteFile[]> {
    return Array.from(this.files.entries()).map(([name, value]) => ({
      id: name,
      name,
      sizeBytes: value.blob.size,
      modifiedAt: value.modifiedAt,
      checksum: value.checksum,
    }));
  }
  async upload(request: UploadRequest): Promise<RemoteFile> {
    this.uploads += 1;
    if (this.failOnce.delete(request.name)) {
      throw new Error('fallo de red simulado');
    }
    const checksum = await md5Blob(request.data);
    this.files.set(request.name, { blob: request.data, checksum, modifiedAt: Date.now() });
    request.onProgress?.(request.data.size, request.data.size);
    return {
      id: request.name,
      name: request.name,
      sizeBytes: request.data.size,
      modifiedAt: Date.now(),
      checksum,
    };
  }
  async download(fileId: string): Promise<Blob> {
    const file = this.files.get(fileId);
    if (!file) throw new Error('no existe');
    return file.blob;
  }
  async remove(fileId: string): Promise<void> {
    this.files.delete(fileId);
  }
}

describe('Hashes de integridad', () => {
  it('calcula MD5 según los vectores de RFC 1321', () => {
    expect(md5Hex(encoder.encode(''))).toBe('d41d8cd98f00b204e9800998ecf8427e');
    expect(md5Hex(encoder.encode('abc'))).toBe('900150983cd24fb0d6963f7d28e17f72');
    expect(md5Hex(encoder.encode('message digest'))).toBe('f96b697d7cb7938d525a2f31aaf161d0');
  });

  it('calcula SHA-256 de un blob', async () => {
    const digest = await sha256Blob(new Blob(['abc']));
    expect(digest).toBe('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  });
});

describe('Manifiesto y plan de subida', () => {
  beforeEach(async () => {
    for (const project of await getAllProjectsFromStorage()) {
      await deleteProjectFromStorage(project.id);
    }

    // Fixtures shared by the manifest tests: one project with its binary, and a
    // second project referencing an asset whose binary is gone.
    await saveMediaAssetBlob({
      id: 'asset-audio-1',
      name: 'voz.wav',
      type: 'audio',
      url: '',
      mimeType: 'audio/wav',
      sizeBytes: 11,
      license: 'propia',
      provenance: 'prueba',
      createdAt: 1500,
      fileBlob: new Blob(['hola mundo!'], { type: 'audio/wav' }),
    });
    await saveProjectToStorage(makeProject());
    await saveProjectToStorage(
      makeProject({
        id: 'proj-missing',
        title: 'Proyecto con medio perdido',
        mediaAssets: [
          {
            id: 'asset-perdido',
            name: 'perdido.mp4',
            type: 'video',
            url: '',
            mimeType: 'video/mp4',
            sizeBytes: 100,
            license: 'propia',
            provenance: 'prueba',
            createdAt: 1500,
          },
        ],
      })
    );
  });

  it('hashea proyectos y medios, y marca binarios ausentes', async () => {
    const manifest = await buildBackupManifest('google-drive');
    const projectEntry = manifest.entries.find((entry) => entry.kind === 'project');
    const assetEntry = manifest.entries.find((entry) => entry.id === 'asset-audio-1');
    const missingEntry = manifest.entries.find((entry) => entry.id === 'asset-perdido');

    expect(projectEntry?.sha256).toMatch(/^[a-f0-9]{64}$/);
    expect(assetEntry?.md5).toMatch(/^[a-f0-9]{32}$/);
    expect(assetEntry?.sizeBytes).toBe(11);
    expect(missingEntry?.missing).toBe(true);
    expect(manifest.totals.projectBytes).toBeGreaterThan(0);
  });

  it('deduplica por MD5 y sube solo lo que falta', async () => {
    const manifest = await buildBackupManifest('google-drive');
    const audio = manifest.entries.find((entry) => entry.id === 'asset-audio-1');
    expect(audio).toBeDefined();

    const remote: RemoteFile[] = [
      {
        id: 'remote-1',
        name: 'cualquier-nombre',
        sizeBytes: audio!.sizeBytes,
        modifiedAt: Date.now(),
        checksum: audio!.md5,
      },
    ];
    const plan = planBackupUploads(manifest, remote);
    expect(plan.deduped.some((entry) => entry.entry.id === 'asset-audio-1')).toBe(true);
    expect(plan.uploads.some((entry) => entry.id === 'asset-audio-1')).toBe(false);
    expect(plan.missing).toHaveLength(1);
  });
});

describe('Respaldo completo y restauración', () => {
  it('sube, verifica y permite restaurar en un almacenamiento vacío', async () => {
    await saveProjectToStorage(makeProject());
    await saveMediaAssetBlob({
      id: 'asset-audio-1',
      name: 'voz.wav',
      type: 'audio',
      url: '',
      mimeType: 'audio/wav',
      sizeBytes: 11,
      license: 'propia',
      provenance: 'prueba',
      createdAt: 1500,
      fileBlob: new Blob(['hola mundo!'], { type: 'audio/wav' }),
    });

    const provider = new MemoryProvider();
    const result = await runBackup({ provider });
    expect(result.uploadedCount).toBeGreaterThanOrEqual(2);
    expect(result.verifiedCount).toBeGreaterThanOrEqual(2);
    expect(provider.files.has(BACKUP_MANIFEST_NAME)).toBe(true);

    // A second run with the same content only re-uploads the manifest.
    provider.uploads = 0;
    const second = await runBackup({ provider, fresh: true });
    expect(second.dedupedCount).toBeGreaterThanOrEqual(2);
    expect(second.uploadedCount).toBe(0);
    expect(provider.uploads).toBe(1);
  });

  it('restaura un proyecto que ya no existe localmente', async () => {
    await saveProjectToStorage(makeProject());
    await saveMediaAssetBlob({
      id: 'asset-audio-1',
      name: 'voz.wav',
      type: 'audio',
      url: '',
      mimeType: 'audio/wav',
      sizeBytes: 11,
      license: 'propia',
      provenance: 'prueba',
      createdAt: 1500,
      fileBlob: new Blob(['hola mundo!'], { type: 'audio/wav' }),
    });
    const provider = new MemoryProvider();
    await runBackup({ provider });

    await deleteProjectFromStorage('proj-cloud-1');
    expect(await getProjectFromStorage('proj-cloud-1')).toBeNull();

    const restored = await restoreFromBackup({ provider });
    expect(restored.projectsRestored).toBeGreaterThanOrEqual(1);
    const project = await getProjectFromStorage('proj-cloud-1');
    expect(project?.title).toBe('Proyecto Nube');
    const asset = await getMediaAssetBlob('asset-audio-1');
    expect(asset?.fileBlob).toBeDefined();
    expect(await asset!.fileBlob!.text()).toBe('hola mundo!');
  });

  it('no sobrescribe trabajo local más reciente y crea una copia', async () => {
    await saveProjectToStorage(makeProject());
    const provider = new MemoryProvider();
    await runBackup({ provider });

    // Local edits are newer than the backup entry.
    const newer = makeProject({ title: 'Versión local reciente', updatedAt: Date.now() + 60_000 });
    await saveProjectToStorage(newer);

    const restored = await restoreFromBackup({ provider, strategy: 'keep-both' });
    expect(restored.conflicts.length).toBe(1);
    expect(restored.conflicts[0].resolution).toBe('imported-copy');
    expect(restored.conflicts[0].copyId).toBeTruthy();

    const local = await getProjectFromStorage('proj-cloud-1');
    expect(local?.title).toBe('Versión local reciente');
    const copy = await getProjectFromStorage(restored.conflicts[0].copyId!);
    expect(copy?.title).toContain('versión en la nube');
  });

  it('falla si el archivo remoto no coincide con la integridad del manifiesto', async () => {
    await saveProjectToStorage(makeProject());
    const provider = new MemoryProvider();
    await runBackup({ provider });

    const file = provider.files.get(BACKUP_MANIFEST_NAME)!;
    const manifest = JSON.parse(await file.blob.text());
    const projectEntry = manifest.entries.find((entry: { kind: string }) => entry.kind === 'project');
    provider.files.set(projectEntry.name, {
      blob: new Blob(['contenido alterado']),
      checksum: 'x',
      modifiedAt: Date.now(),
    });

    await expect(restoreFromBackup({ provider })).rejects.toThrow(/integridad/i);
  });
});

describe('Resolución de conflictos', () => {
  const local = makeProject({ updatedAt: 5000 });

  it('usa la nube cuando es más reciente', () => {
    expect(resolveProjectConflict(local, 9000, 'keep-both')).toBe('used-remote');
  });

  it('nunca sobrescribe lo local más reciente con keep-both', () => {
    expect(resolveProjectConflict(local, 1000, 'keep-both')).toBe('imported-copy');
    expect(resolveProjectConflict(local, 1000, 'prefer-local')).toBe('kept-local');
    expect(resolveProjectConflict(local, 1000, 'prefer-remote')).toBe('used-remote');
  });
});
