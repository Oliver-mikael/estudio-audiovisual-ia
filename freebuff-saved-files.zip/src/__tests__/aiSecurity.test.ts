// Security regression tests for the AI engine (P1-S / AL-04)
// Ensures API keys travel in headers only and never appear in errors.
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  aiEngine,
  redactSensitiveText,
  resolveCompatibleEndpoint,
} from '../services/ai/aiEngine';
import { DEMO_PROJECT } from '../data/demoProject';

const FAKE_GEMINI_KEY = 'test-gemini-key-do-not-use-0001';
const FAKE_OPENAI_KEY = 'test-openai-key-do-not-use-0002';

function makeResponse(
  body: unknown,
  options: { ok?: boolean; status?: number; rawText?: string } = {}
) {
  return {
    ok: options.ok ?? true,
    status: options.status ?? 200,
    json: async () => body,
    text: async () => options.rawText ?? JSON.stringify(body),
  };
}

function readRequest(fetchMock: ReturnType<typeof vi.fn>) {
  const call = fetchMock.mock.calls[0] as [string, { method: string; headers: Record<string, string> }];
  return { url: call[0], init: call[1] };
}

const geminiSuccessBody = {
  candidates: [{ content: { parts: [{ text: 'respuesta de prueba' }] } }],
};

describe('P1-S Seguridad de credenciales de IA (AL-04)', () => {
  beforeEach(() => {
    vi.stubGlobal('navigator', { onLine: true });
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    aiEngine.setActiveProvider('offline-heuristic');
    aiEngine.setCredentials('gemini-free', {});
    aiEngine.setCredentials('openai-compatible', {});
  });

  it('envía la API key de Gemini en la cabecera x-goog-api-key y nunca en la URL', async () => {
    const fetchMock = vi.fn().mockResolvedValue(makeResponse(geminiSuccessBody));
    vi.stubGlobal('fetch', fetchMock);

    aiEngine.setActiveProvider('gemini-free');
    aiEngine.setCredentials('gemini-free', { apiKey: FAKE_GEMINI_KEY });

    const result = await aiEngine.executeTask({
      task: 'EXPAND_SCENE_NARRATION',
      context: aiEngine.buildContextFromProject(DEMO_PROJECT),
      userPrompt: 'Mejorar la narración',
    });

    expect(result.success).toBe(true);
    expect(fetchMock).toHaveBeenCalledTimes(1);

    const { url, init } = readRequest(fetchMock);
    expect(url).not.toContain('?');
    expect(url).not.toContain(FAKE_GEMINI_KEY);
    expect(url).not.toMatch(/[?&]key=/);
    expect(init.method).toBe('POST');
    expect(init.headers['x-goog-api-key']).toBe(FAKE_GEMINI_KEY);
  });

  it('redacta la API key cuando el proveedor la devuelve dentro del cuerpo de error', async () => {
    const errorBody = JSON.stringify({
      error: {
        code: 400,
        message: `API key not valid: ${FAKE_GEMINI_KEY}`,
        status: 'INVALID_ARGUMENT',
      },
    });

    const fetchMock = vi
      .fn()
      .mockResolvedValue(makeResponse({}, { ok: false, status: 400, rawText: errorBody }));
    vi.stubGlobal('fetch', fetchMock);

    aiEngine.setActiveProvider('gemini-free');
    aiEngine.setCredentials('gemini-free', { apiKey: FAKE_GEMINI_KEY });

    const result = await aiEngine.executeTask({
      task: 'EXPAND_SCENE_NARRATION',
      context: aiEngine.buildContextFromProject(DEMO_PROJECT),
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain('400');
    expect(result.error).toContain('[REDACTED]');
    expect(result.error).not.toContain(FAKE_GEMINI_KEY);
  });

  it('rechaza un endpoint compatible que incluya la clave en la query string sin realizar la petición', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);

    aiEngine.setActiveProvider('openai-compatible');
    aiEngine.setCredentials('openai-compatible', {
      apiKey: FAKE_OPENAI_KEY,
      endpointUrl: `https://api.groq.com/openai/v1?api_key=${FAKE_OPENAI_KEY}`,
    });

    const result = await aiEngine.executeTask({
      task: 'CRITIQUE_SCRIPT',
      context: aiEngine.buildContextFromProject(DEMO_PROJECT),
    });

    expect(result.success).toBe(false);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(result.error).toMatch(/query string/i);
    expect(result.error).not.toContain(FAKE_OPENAI_KEY);
  });

  it('rechaza un endpoint con credenciales embebidas en la URL (userinfo)', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);

    aiEngine.setActiveProvider('openai-compatible');
    aiEngine.setCredentials('openai-compatible', {
      apiKey: FAKE_OPENAI_KEY,
      endpointUrl: `https://user:${FAKE_OPENAI_KEY}@api.groq.com/openai/v1`,
    });

    const result = await aiEngine.executeTask({
      task: 'CRITIQUE_SCRIPT',
      context: aiEngine.buildContextFromProject(DEMO_PROJECT),
    });

    expect(result.success).toBe(false);
    expect(fetchMock).not.toHaveBeenCalled();
    expect(result.error).toMatch(/credenciales/i);
    expect(result.error).not.toContain(FAKE_OPENAI_KEY);
  });

  it('usa Authorization Bearer para proveedores compatibles sin exponer la clave en la URL', async () => {
    const fetchMock = vi
      .fn()
      .mockResolvedValue(
        makeResponse({ choices: [{ message: { content: 'ok' } }] })
      );
    vi.stubGlobal('fetch', fetchMock);

    aiEngine.setActiveProvider('openai-compatible');
    aiEngine.setCredentials('openai-compatible', {
      apiKey: FAKE_OPENAI_KEY,
      endpointUrl: 'https://api.groq.com/openai/v1',
      modelName: 'llama-3.3-70b-versatile',
    });

    const result = await aiEngine.executeTask({
      task: 'CRITIQUE_SCRIPT',
      context: aiEngine.buildContextFromProject(DEMO_PROJECT),
    });

    expect(result.success).toBe(true);
    const { url, init } = readRequest(fetchMock);
    expect(url).toBe('https://api.groq.com/openai/v1/chat/completions');
    expect(url).not.toContain(FAKE_OPENAI_KEY);
    expect(init.headers.Authorization).toBe(`Bearer ${FAKE_OPENAI_KEY}`);
  });

  it('resolveCompatibleEndpoint acepta endpoints legítimos con parámetros no sensibles', () => {
    expect(resolveCompatibleEndpoint('https://example.com/openai/v1?api-version=2024-02-01')).toBe(
      'https://example.com/openai/v1?api-version=2024-02-01'
    );
  });

  it('redactSensitiveText enmascara valores conocidos, query strings y cabeceras', () => {
    const text = `GET https://api.example.com/v1?key=${FAKE_GEMINI_KEY}&model=x Authorization: Bearer ${FAKE_OPENAI_KEY}`;
    const redacted = redactSensitiveText(text, [FAKE_GEMINI_KEY, FAKE_OPENAI_KEY]);

    expect(redacted).not.toContain(FAKE_GEMINI_KEY);
    expect(redacted).not.toContain(FAKE_OPENAI_KEY);
    expect(redacted).toContain('[REDACTED]');
    expect(redacted).toContain('model=x');
  });
});
