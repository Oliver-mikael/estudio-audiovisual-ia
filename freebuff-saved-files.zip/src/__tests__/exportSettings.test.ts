// Tests for the export configuration domain: resolutions, aspect ratios, fps,
// quality/bitrate policy, size estimation, risk assessment, format detection
// and plan building (including honest fallbacks).
import { describe, it, expect } from 'vitest';
import { DEMO_PROJECT } from '../data/demoProject';
import {
  assessExportRisk,
  changeProjectFormat,
  computeResolution,
  estimateExportBytes,
  estimateVideoBitrateBps,
  formatBytes,
  hasBlockingWarning,
  inferExportAspect,
  inferResolutionTier,
  MAX_VIDEO_BITRATE_BPS,
  MIN_VIDEO_BITRATE_BPS,
} from '../services/export/exportConfig';
import {
  detectExportCapabilities,
  resolveExportFormat,
  probeFrameRateSupport,
} from '../services/export/codecs';
import {
  buildExportPlan,
  createExportSettingsFromProject,
  type ExportSettings,
} from '../services/export/exportPlan';

const baseSettings: ExportSettings = {
  resolutionTier: '1080p',
  aspectRatio: '16:9',
  fps: 30,
  formatPreference: 'auto',
  quality: 'standard',
  customBitrateBps: null,
  audioQuality: 'standard',
  includeAudio: true,
  fitMode: 'fill',
  framing: { x: 0.5, y: 0.5 },
};

describe('Resoluciones y relaciones de aspecto', () => {
  it('calcula el lado corto según el tier y el aspecto', () => {
    expect(computeResolution('720p', '16:9')).toEqual({ width: 1280, height: 720 });
    expect(computeResolution('1080p', '9:16')).toEqual({ width: 1080, height: 1920 });
    expect(computeResolution('1080p', '1:1')).toEqual({ width: 1080, height: 1080 });
    expect(computeResolution('720p', '4:3')).toEqual({ width: 960, height: 720 });
    expect(computeResolution('2160p', '16:9')).toEqual({ width: 3840, height: 2160 });
  });

  it('mantiene dimensiones pares para los codificadores', () => {
    for (const tier of ['360p', '480p', '720p', '1080p', '1440p', '2160p'] as const) {
      for (const aspect of ['16:9', '9:16', '1:1', '4:3'] as const) {
        const { width, height } = computeResolution(tier, aspect);
        expect(width % 2).toBe(0);
        expect(height % 2).toBe(0);
      }
    }
  });
});

describe('Bitrate y estimación de peso', () => {
  it('crece con resolución, fps y calidad', () => {
    const low = estimateVideoBitrateBps({ width: 1280, height: 720, fps: 30, quality: 'economic' });
    const std = estimateVideoBitrateBps({ width: 1280, height: 720, fps: 30, quality: 'standard' });
    const high = estimateVideoBitrateBps({ width: 1920, height: 1080, fps: 60, quality: 'high' });
    expect(low).toBeLessThan(std);
    expect(std).toBeLessThan(high);
    expect(low).toBeGreaterThanOrEqual(MIN_VIDEO_BITRATE_BPS);
    expect(high).toBeLessThanOrEqual(MAX_VIDEO_BITRATE_BPS);
  });

  it('estima el tamaño con sobrecarga de contenedor', () => {
    const bytes = estimateExportBytes({
      durationSeconds: 60,
      videoBitrateBps: 2_500_000,
      audioBitrateBps: 128_000,
    });
    // 60 s * 2.628 Mbps / 8 = 19.71 MB payload + 2% contenedor
    expect(bytes).toBeGreaterThan(19 * 1024 * 1024);
    expect(bytes).toBeLessThan(20 * 1024 * 1024);
  });

  it('formatea bytes de forma legible', () => {
    expect(formatBytes(0)).toBe('0 B');
    expect(formatBytes(1536)).toBe('1.50 KB');
    expect(formatBytes(500 * 1024 * 1024)).toBe('500 MB');
  });
});

describe('Evaluación de riesgos antes de exportar', () => {
  it('marca riesgo alto por tamaño en memoria', () => {
    const warnings = assessExportRisk({
      estimatedBytes: 600 * 1024 * 1024,
      durationSeconds: 120,
      width: 1920,
      height: 1080,
      fps: 30,
      availableBytes: 10 * 1024 * 1024 * 1024,
      deviceMemoryGb: 8,
    });
    expect(warnings.some((warning) => warning.code === 'large-estimate')).toBe(true);
    expect(hasBlockingWarning(warnings)).toBe(true);
  });

  it('detecta espacio insuficiente usando un margen de seguridad', () => {
    const warnings = assessExportRisk({
      estimatedBytes: 100 * 1024 * 1024,
      durationSeconds: 60,
      width: 1280,
      height: 720,
      fps: 30,
      availableBytes: 110 * 1024 * 1024,
      deviceMemoryGb: 8,
    });
    expect(warnings.some((warning) => warning.code === 'insufficient-space')).toBe(true);
  });

  it('avisa de 4K con poca memoria y de fps altos', () => {
    const warnings = assessExportRisk({
      estimatedBytes: 30 * 1024 * 1024,
      durationSeconds: 30,
      width: 3840,
      height: 2160,
      fps: 60,
      availableBytes: null,
      deviceMemoryGb: 3,
    });
    expect(warnings.some((warning) => warning.code === 'low-memory-4k')).toBe(true);
    expect(warnings.some((warning) => warning.code === 'high-fps')).toBe(true);
  });
});

describe('Cambio de formato del proyecto', () => {
  it('conserva clips, offsets y animaciones al cambiar el lienzo', () => {
    const before = DEMO_PROJECT;
    const after = changeProjectFormat(before, {
      resolution: { width: 1080, height: 1920 },
      fps: 25,
      aspectRatio: '9:16',
    });

    expect(after.settings).toEqual({
      fps: 25,
      resolution: { width: 1080, height: 1920 },
      aspectRatio: '9:16',
      filmGrain: { enabled: true, amount: 0.08 },
      filmGrainEnabled: true,
      filmGrainAmount: 0.08,
    });
    expect(after.timeline).toEqual(before.timeline);
    expect(after.mediaAssets).toEqual(before.mediaAssets);
    expect(after.script).toEqual(before.script);
    expect(after.id).toBe(before.id);
  });

  it('infiere tier y aspecto del proyecto', () => {
    expect(inferResolutionTier(DEMO_PROJECT)).toBe('720p');
    expect(inferExportAspect(DEMO_PROJECT)).toBe('16:9');
  });
});

describe('Detección real de formatos', () => {
  it('solo marca soportados los mime types que el navegador confirma', () => {
    const capabilities = detectExportCapabilities(
      (mime) => mime.includes('mp4') || mime.startsWith('video/webm;codecs=vp9')
    );
    expect(capabilities.supportedFormatIds).toContain('mp4-h264-aac');
    expect(capabilities.supportedFormatIds).toContain('webm-vp9-opus');
    expect(capabilities.supportedFormatIds).not.toContain('webm-vp8-opus');
    expect(capabilities.preferredFormatId).toBe('mp4-h264-aac');
  });

  it('no ofrece nada cuando MediaRecorder no soporta ningún códec', () => {
    const capabilities = detectExportCapabilities(() => false);
    expect(capabilities.supportedFormatIds).toHaveLength(0);
    expect(capabilities.preferredFormatId).toBeNull();
  });

  it('reporta explícitamente el reemplazo de MP4 por WebM', () => {
    const capabilities = detectExportCapabilities((mime) =>
      mime.startsWith('video/webm;codecs=vp8')
    );
    const resolution = resolveExportFormat('mp4', capabilities, true);
    expect(resolution.format?.container).toBe('webm');
    expect(resolution.fellBack).toBe(true);
    expect(resolution.reason).toContain('MP4');
  });

  it('auto elige el mejor formato disponible', () => {
    const capabilities = detectExportCapabilities((mime) =>
      mime.startsWith('video/webm;codecs=vp9')
    );
    const resolution = resolveExportFormat('auto', capabilities, true);
    expect(resolution.format?.id).toBe('webm-vp9-opus');
    expect(resolution.fellBack).toBe(false);
  });

  it('el sondeo de FPS devuelve false sin canvas (entorno de pruebas)', () => {
    expect(probeFrameRateSupport(1280, 720, 60)).toBe(false);
  });
});

describe('Construcción del plan de exportación', () => {
  const capabilities = detectExportCapabilities((mime) =>
    mime.startsWith('video/webm;codecs=vp9') || mime.startsWith('video/mp4')
  );

  it('rechaza timelines vacíos', () => {
    const result = buildExportPlan({
      settings: baseSettings,
      durationSeconds: 0,
      capabilities,
    });
    expect(result.ok).toBe(false);
  });

  it('resuelve tamaño, bitrate, audio y contenedor', () => {
    const result = buildExportPlan({
      settings: { ...baseSettings, aspectRatio: '9:16', resolutionTier: '720p' },
      durationSeconds: 10,
      capabilities,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.plan.width).toBe(720);
    expect(result.plan.height).toBe(1280);
    expect(result.plan.audioBitrateBps).toBe(128_000);
    expect(result.plan.extension).toBe('mp4');
    expect(result.plan.estimatedBytes).toBeGreaterThan(0);
    expect(result.plan.composition.fitMode).toBe('fill');
  });

  it('respeta el bitrate personalizado con límites', () => {
    const result = buildExportPlan({
      settings: { ...baseSettings, customBitrateBps: 999_999_999 },
      durationSeconds: 5,
      capabilities,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.plan.videoBitrateBps).toBe(MAX_VIDEO_BITRATE_BPS);
  });

  it('sin audio usa el mime solo-video y bitrate de audio 0', () => {
    const result = buildExportPlan({
      settings: { ...baseSettings, includeAudio: false, formatPreference: 'webm' },
      durationSeconds: 5,
      capabilities,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.plan.audioBitrateBps).toBe(0);
    expect(result.plan.mimeType).toBe('video/webm;codecs=vp9');
  });

  it('agrega advertencia cuando el contenedor pedido no existe', () => {
    const webmOnly = detectExportCapabilities((mime) =>
      mime.startsWith('video/webm;codecs=vp8')
    );
    const result = buildExportPlan({
      settings: { ...baseSettings, formatPreference: 'mp4' },
      durationSeconds: 5,
      capabilities: webmOnly,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.plan.formatFellBack).toBe(true);
    expect(result.plan.extension).toBe('webm');
    expect(result.plan.warnings.some((warning) => warning.code === 'container-fallback')).toBe(
      true
    );
  });

  it('crea la configuración inicial desde el proyecto', () => {
    const settings = createExportSettingsFromProject(DEMO_PROJECT);
    expect(settings.resolutionTier).toBe('720p');
    expect(settings.aspectRatio).toBe('16:9');
    expect(settings.fps).toBe(30);
    expect(settings.includeAudio).toBe(true);
  });
});
