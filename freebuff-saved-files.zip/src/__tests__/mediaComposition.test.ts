// Regression tests for timeline media composition helpers used by preview and export.
import { describe, expect, it } from 'vitest';
import { Project, TimelineClip, TimelineTrack } from '../types';
import {
  buildClipFilter,
  getActiveClipOnTrack,
  getActiveTextClips,
  getActiveVisualClips,
  getClipLocalTimeMs,
  getClipProgress,
  getClipVisualTransform,
  getProjectDurationMs,
  getTimelineDurationMs,
  getVideoFileExtension,
  getVisualTracks,
  resolveExportSettings,
} from '../engine/mediaComposition';
import { DEMO_PROJECT } from '../data/demoProject';

function makeClip(overrides: Partial<TimelineClip> = {}): TimelineClip {
  return {
    id: 'clip-1',
    name: 'Clip',
    trackId: 'track-v1',
    type: 'video',
    startMs: 0,
    durationMs: 5000,
    offsetMs: 0,
    ...overrides,
  };
}

function makeTrack(overrides: Partial<TimelineTrack> = {}): TimelineTrack {
  return {
    id: 'track-v1',
    name: 'Video 1',
    type: 'video',
    order: 0,
    isMuted: false,
    isLocked: false,
    isVisible: true,
    clips: [],
    ...overrides,
  };
}

function makeProject(tracks: TimelineTrack[], scenesSeconds: number[] = []): Project {
  return {
    ...DEMO_PROJECT,
    timeline: { tracks },
    script: {
      ...DEMO_PROJECT.script,
      scenes: scenesSeconds.map((seconds, index) => ({
        id: `scene-${index + 1}`,
        title: `Escena ${index + 1}`,
        narrationText: 'Texto de prueba',
        visualIntent: 'Test',
        cameraMotion: 'Static',
        transition: 'Cut',
        durationSeconds: seconds,
      })),
    },
  };
}

describe('Media composition: timeline duration', () => {
  it('uses the end of the last clip when the timeline is longer than the scenes', () => {
    const project = makeProject(
      [
        makeTrack({
          id: 'track-v1',
          order: 0,
          clips: [makeClip({ startMs: 0, durationMs: 4000 })],
        }),
        makeTrack({
          id: 'track-a1',
          type: 'audio',
          order: 1,
          clips: [makeClip({ id: 'audio-1', type: 'audio', startMs: 6000, durationMs: 3000 })],
        }),
      ],
      [4]
    );

    expect(getTimelineDurationMs(project)).toBe(9000);
    expect(getProjectDurationMs(project)).toBe(9000);
  });

  it('falls back to the scene sum for legacy projects without a timeline', () => {
    const project: Project = {
      ...DEMO_PROJECT,
      timeline: undefined,
      script: {
        ...DEMO_PROJECT.script,
        scenes: [
          { ...DEMO_PROJECT.script.scenes[0], durationSeconds: 2.5 },
          { ...DEMO_PROJECT.script.scenes[1], durationSeconds: 3.5 },
        ],
      },
    };

    expect(getTimelineDurationMs(project)).toBe(0);
    expect(getProjectDurationMs(project)).toBe(6000);
  });
});

describe('Media composition: active clips and layering', () => {
  it('returns visible visual tracks ordered back-to-front', () => {
    const project = makeProject([
      makeTrack({ id: 'track-v2', order: 2, clips: [] }),
      makeTrack({ id: 'track-v1', order: 0, clips: [] }),
      makeTrack({ id: 'track-v3', order: 3, isVisible: false, clips: [] }),
    ]);

    expect(getVisualTracks(project).map((track) => track.id)).toEqual(['track-v1', 'track-v2']);
  });

  it('composites base and overlay clips and ignores hidden or muted tracks', () => {
    const project = makeProject([
      makeTrack({
        id: 'track-v1',
        order: 0,
        clips: [makeClip({ id: 'base', startMs: 0, durationMs: 5000, assetId: 'asset-base' })],
      }),
      makeTrack({
        id: 'track-v2',
        order: 1,
        clips: [makeClip({ id: 'overlay', startMs: 1000, durationMs: 2000, assetId: 'asset-overlay' })],
      }),
      makeTrack({
        id: 'track-v3',
        order: 2,
        isVisible: false,
        clips: [makeClip({ id: 'hidden', startMs: 0, durationMs: 5000 })],
      }),
    ]);

    const active = getActiveVisualClips(project, 1500);
    expect(active.map(({ clip }) => clip.id)).toEqual(['base', 'overlay']);

    const mutedOverlay = makeProject([
      makeTrack({
        id: 'track-v2',
        order: 1,
        clips: [makeClip({ id: 'muted', startMs: 0, durationMs: 5000, isMuted: true })],
      }),
    ]);
    expect(getActiveVisualClips(mutedOverlay, 1000)).toHaveLength(0);
  });

  it('picks the clip that starts last when clips overlap on the same track', () => {
    const track = makeTrack({
      clips: [
        makeClip({ id: 'first', startMs: 0, durationMs: 4000 }),
        makeClip({ id: 'second', startMs: 2000, durationMs: 4000 }),
      ],
    });

    expect(getActiveClipOnTrack(track, 1000)?.id).toBe('first');
    expect(getActiveClipOnTrack(track, 3000)?.id).toBe('second');
    expect(getActiveClipOnTrack(track, 7000)).toBeUndefined();
  });

  it('returns active text clips only for visible text/subtitle tracks', () => {
    const project = makeProject([
      makeTrack({
        id: 'track-t1',
        type: 'text',
        order: 1,
        clips: [makeClip({ id: 'caption', type: 'caption', textPayload: 'Hola', durationMs: 3000 })],
      }),
      makeTrack({
        id: 'track-t2',
        type: 'subtitles',
        order: 2,
        isVisible: false,
        clips: [makeClip({ id: 'hidden-caption', type: 'caption', durationMs: 3000 })],
      }),
    ]);

    expect(getActiveTextClips(project, 500).map(({ clip }) => clip.id)).toEqual(['caption']);
  });
});

describe('Media composition: clip timing and animation', () => {
  it('maps timeline time to media time honoring offset and speed', () => {
    const clip = makeClip({ startMs: 2000, durationMs: 6000, offsetMs: 500, speed: 2 });

    expect(getClipLocalTimeMs(clip, 2000)).toBe(500);
    expect(getClipLocalTimeMs(clip, 4000)).toBe(4500);
    expect(getClipLocalTimeMs(clip, 1000)).toBe(500);
  });

  it('clamps progress to the clip bounds', () => {
    const clip = makeClip({ startMs: 1000, durationMs: 2000 });

    expect(getClipProgress(clip, 0)).toBe(0);
    expect(getClipProgress(clip, 2000)).toBe(0.5);
    expect(getClipProgress(clip, 9000)).toBe(1);
  });

  it('applies static transform and opacity, and interpolates keyframes', () => {
    const staticClip = makeClip({
      transform: { x: 10, y: -20, scale: 1.2, rotation: 15 },
      opacity: 0.8,
    });
    const staticTransform = getClipVisualTransform(staticClip, 0);
    expect(staticTransform.positionX).toBe(10);
    expect(staticTransform.positionY).toBe(-20);
    expect(staticTransform.scale).toBeCloseTo(1.2);
    expect(staticTransform.rotation).toBe(15);
    expect(staticTransform.opacity).toBeCloseTo(0.8);

    const animatedClip = makeClip({
      animations: [
        {
          property: 'scale',
          keyframes: [
            { id: 'k1', timeOffsetMs: 0, value: 1 },
            { id: 'k2', timeOffsetMs: 1000, value: 2, easing: 'linear' },
          ],
        },
      ],
    });

    expect(getClipVisualTransform(animatedClip, 500).scale).toBeCloseTo(1.5);
  });
});

describe('Media composition: color grading', () => {
  it('returns none for clips without adjustments or presets', () => {
    expect(buildClipFilter(makeClip())).toBe('none');
  });

  it('combines preset and color adjustments into a canvas filter', () => {
    const clip = makeClip({
      filterPreset: 'noir',
      colorAdjustments: {
        brightness: 0.1,
        contrast: 1.2,
        saturation: 0.8,
        temperature: 50,
        vignette: 0,
      },
    });

    const filter = buildClipFilter(clip);
    expect(filter).toContain('grayscale(1)');
    expect(filter).toContain('brightness(1.100)');
    expect(filter).toContain('contrast(1.200)');
    expect(filter).toContain('saturate(0.800)');
    expect(filter).toContain('sepia(');
  });
});

describe('Media composition: export settings', () => {
  it('prefers the selected export profile over project defaults', () => {
    const settings = resolveExportSettings(makeProject([], [5]), {
      id: 'vertical',
      name: 'Vertical',
      format: 'webm',
      aspectRatio: '9:16',
      resolution: { width: 1080, height: 1920 },
      fps: 60,
      bitrateBps: 4_000_000,
      includeAudio: false,
      description: '',
    });

    expect(settings).toEqual({
      width: 1080,
      height: 1920,
      fps: 60,
      bitrateBps: 4_000_000,
      includeAudio: false,
      format: 'webm',
    });
  });

  it('falls back to project settings when no profile is selected', () => {
    const settings = resolveExportSettings(DEMO_PROJECT);

    expect(settings.width).toBe(1280);
    expect(settings.height).toBe(720);
    expect(settings.fps).toBe(30);
    expect(settings.includeAudio).toBe(true);
  });

  it('derives the file extension from the recorded mime type', () => {
    expect(getVideoFileExtension('video/webm;codecs=vp9,opus')).toBe('webm');
    expect(getVideoFileExtension('video/mp4')).toBe('mp4');
  });
});
