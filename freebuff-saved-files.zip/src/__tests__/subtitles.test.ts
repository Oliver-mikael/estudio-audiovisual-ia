// Subtitle/SRT tests: parsing tolerance, serialization round-trip and the
// mapping between cues and the T1 caption track used by render and export.
import { describe, expect, it } from 'vitest';
import { DEMO_PROJECT } from '../data/demoProject';
import {
  addSubtitleCue,
  applyCuesToProject,
  formatSrtTimestamp,
  getCaptionTrackCues,
  getProjectSubtitleCues,
  getSceneNarrationCues,
  parseSrt,
  parseSrtDetailed,
  parseSrtTimestamp,
  removeSubtitleCue,
  serializeSrt,
  stripSubtitleMarkup,
  updateSubtitleCue,
} from '../services/subtitles/subtitleService';

const SAMPLE_SRT = `\uFEFF1
00:00:01,500 --> 00:00:04,000
Primera línea

2
00:00:04.250 --> 00:00:06.000 X1:40 X2:600
<i>Segunda</i> línea
con salto

3
00:00:07,000 --> 00:00:08,000
{\\an8}Tercera
`;

describe('SRT parsing', () => {
  it('parses BOM, CRLF, dot milliseconds, cue settings and multiline text', () => {
    const raw = SAMPLE_SRT.replace(/\n/g, '\r\n');
    const result = parseSrtDetailed(raw);

    expect(result.skippedBlocks).toBe(0);
    expect(result.cues).toHaveLength(3);
    expect(result.cues[0]).toMatchObject({ startMs: 1500, endMs: 4000, text: 'Primera línea' });
    expect(result.cues[1].startMs).toBe(4250);
    expect(result.cues[1].text).toBe('Segunda línea\ncon salto');
    expect(result.cues[2].text).toBe('Tercera');
  });

  it('parses blocks without an index line', () => {
    const cues = parseSrt('00:00:02,000 --> 00:00:03,000\nSin índice\n');
    expect(cues).toHaveLength(1);
    expect(cues[0].text).toBe('Sin índice');
  });

  it('skips malformed blocks without aborting the file', () => {
    const broken = `1
00:00:01,000 --> 00:00:02,000
Válido

2
sin flecha
Texto

3
00:00:05,000 --> 00:00:04,000
Fin antes del inicio

4
00:00:06,000 --> 00:00:07,000
`;

    const result = parseSrtDetailed(broken);
    expect(result.cues).toHaveLength(1);
    expect(result.cues[0].text).toBe('Válido');
    expect(result.skippedBlocks).toBe(3);
  });

  it('formats and parses timestamps symmetrically', () => {
    expect(formatSrtTimestamp(0)).toBe('00:00:00,000');
    expect(formatSrtTimestamp(3_723_456)).toBe('01:02:03,456');
    expect(parseSrtTimestamp('01:02:03,456')).toBe(3_723_456);
    expect(parseSrtTimestamp('00:02,500')).toBe(2500);
    expect(parseSrtTimestamp('99:99,000')).toBeNull();
    expect(parseSrtTimestamp('texto')).toBeNull();
  });

  it('removes styling markup but keeps the words', () => {
    expect(stripSubtitleMarkup('<i>Hola</i> {\\an8}mundo')).toBe('Hola mundo');
  });
});

describe('SRT serialization', () => {
  it('round-trips cues with stable timing and text', () => {
    const original = parseSrt(SAMPLE_SRT);
    const reparsed = parseSrt(serializeSrt(original));

    expect(reparsed.map(({ startMs, endMs, text }) => ({ startMs, endMs, text }))).toEqual(
      original.map(({ startMs, endMs, text }) => ({ startMs, endMs, text }))
    );
    expect(serializeSrt(reparsed).startsWith('1\n00:00:01,500 --> 00:00:04,000')).toBe(true);
  });

  it('orders cues, enforces a minimum duration and handles empty input', () => {
    const output = serializeSrt([
      { id: 'b', startMs: 5000, endMs: 5000, text: 'Segundo' },
      { id: 'a', startMs: 1000, endMs: 2000, text: 'Primero' },
    ]);

    expect(output.indexOf('Primero')).toBeLessThan(output.indexOf('Segundo'));
    expect(output).toContain('00:00:05,000 --> 00:00:05,200');
    expect(serializeSrt([])).toBe('');
  });
});

describe('Subtitle track integration', () => {
  it('replaces only T1 while preserving video clips', () => {
    const applied = applyCuesToProject(DEMO_PROJECT, [
      { id: 'cue-2', startMs: 3000, endMs: 5000, text: 'Hola' },
      { id: 'cue-1', startMs: 0, endMs: 2000, text: 'Inicio' },
    ]);

    const t1 = applied.timeline!.tracks.find((track) => track.id === 'track-t1')!;
    expect(t1.clips).toHaveLength(2);
    expect(t1.clips[0]).toMatchObject({
      id: 'cue-1',
      type: 'caption',
      startMs: 0,
      durationMs: 2000,
      textPayload: 'Inicio',
    });
    expect(t1.clips[1].startMs).toBe(3000);

    const v1Original = DEMO_PROJECT.timeline?.tracks.find((track) => track.id === 'track-v1');
    const v1Applied = applied.timeline!.tracks.find((track) => track.id === 'track-v1');
    if (v1Original) {
      expect(v1Applied?.clips).toEqual(v1Original.clips);
    }
  });

  it('updates, clamps and removes individual cues', () => {
    const withCues = applyCuesToProject(DEMO_PROJECT, [
      { id: 'cue-1', startMs: 1000, endMs: 3000, text: 'Uno' },
    ]);

    const updated = updateSubtitleCue(withCues, 'cue-1', {
      startMs: 2500,
      endMs: 2500,
      text: 'Editado',
    });
    const cue = getCaptionTrackCues(updated)[0];
    expect(cue.startMs).toBe(2500);
    expect(cue.endMs).toBe(2700);
    expect(cue.text).toBe('Editado');

    const removed = removeSubtitleCue(updated, 'cue-1');
    expect(getCaptionTrackCues(removed)).toHaveLength(0);
    expect(removeSubtitleCue(updated, 'inexistente')).toBeTruthy();
  });

  it('adds a cue at the requested time without deleting existing ones', () => {
    const withCue = applyCuesToProject(DEMO_PROJECT, [
      { id: 'cue-1', startMs: 0, endMs: 2000, text: 'Uno' },
    ]);
    const { project } = addSubtitleCue(withCue, 2000, 1500, 'Dos');

    expect(getCaptionTrackCues(project)).toHaveLength(2);
    expect(getCaptionTrackCues(project)[1]).toMatchObject({
      startMs: 2000,
      endMs: 3500,
      text: 'Dos',
    });
  });

  it('falls back to scene narration only when T1 is empty', () => {
    const sceneCues = getSceneNarrationCues(DEMO_PROJECT);
    expect(sceneCues.length).toBe(DEMO_PROJECT.script.scenes.length);
    expect(sceneCues[0].startMs).toBe(0);
    expect(sceneCues[0].text).toBe(DEMO_PROJECT.script.scenes[0].narrationText);

    const emptyCaptions = applyCuesToProject(DEMO_PROJECT, []);
    expect(getCaptionTrackCues(emptyCaptions)).toHaveLength(0);
    expect(getProjectSubtitleCues(emptyCaptions)).toEqual(sceneCues);

    const withCaption = applyCuesToProject(DEMO_PROJECT, [
      { id: 'cue-1', startMs: 0, endMs: 1000, text: 'Propio' },
    ]);
    expect(getProjectSubtitleCues(withCaption)).toHaveLength(1);
  });
});
