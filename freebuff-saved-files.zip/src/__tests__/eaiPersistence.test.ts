// End-to-end .eai integrity tests on the real IndexedDB layer: portable packages
// must not lose binaries, overwrite unrelated data or resurrect skipped projects.
import { beforeEach, describe, expect, it } from 'vitest';
import { IDBFactory } from 'fake-indexeddb';
import { Project } from '../types';
import {
  createEAIPackage,
  restoreProjectFromEAI,
  validateAndParseEAIPackage,
} from '../services/storage/projectBackup';
import {
  getAllProjectsFromStorage,
  getMediaAssetBlob,
  getProjectFromStorage,
  saveMediaAssetBlob,
  saveProjectToStorage,
} from '../services/storage/db';

function makeProject(withBlob = true): Project {
  const blob = new Blob(['contenido-real'], { type: 'image/png' });
  return {
    id: 'proj-eai-1',
    title: 'Proyecto EAI',
    description: 'Prueba de integridad',
    createdAt: 1000,
    updatedAt: 1000,
    angles: [],
    sources: [],
    script: {
      title: 'Proyecto EAI',
      summary: '',
      targetAudience: 'General',
      tone: 'Divulgativo',
      scenes: [],
    },
    settings: {
      fps: 30,
      resolution: { width: 1280, height: 720 },
      aspectRatio: '16:9',
    },
    mediaAssets: [
      {
        id: 'asset-eai-1',
        name: 'imagen.png',
        type: 'image',
        url: 'blob:stale',
        mimeType: 'image/png',
        sizeBytes: 14,
        license: 'Propia',
        provenance: 'Test',
        createdAt: 1,
        ...(withBlob ? { fileBlob: blob } : {}),
      },
    ],
  };
}

describe('.eai portable packages', () => {
  beforeEach(() => {
    globalThis.indexedDB = new IDBFactory() as unknown as IDBFactory;
  });

  it('strips binary placeholders from the project payload and bundles base64', async () => {
    const project = makeProject();
    await saveMediaAssetBlob(project.mediaAssets[0]);
    await saveProjectToStorage(project);

    const pkg = await createEAIPackage(project);

    expect(pkg.project.mediaAssets[0].fileBlob).toBeUndefined();
    expect(pkg.bundledAssets[0].dataBase64).toBeTruthy();
    expect(pkg.checksum).toBeTruthy();
  });

  it('restores a copy with its media available from IndexedDB', async () => {
    const project = makeProject();
    await saveMediaAssetBlob(project.mediaAssets[0]);
    await saveProjectToStorage(project);

    const pkg = await createEAIPackage(project);
    const restored = await restoreProjectFromEAI(pkg, 'create_copy');

    expect(restored.id).not.toBe(project.id);
    expect(restored.title).toContain('Copia importada');

    const stored = await getProjectFromStorage(restored.id);
    expect(stored?.mediaAssets[0].fileBlob).toBeUndefined();

    const asset = await getMediaAssetBlob('asset-eai-1');
    expect(asset?.fileBlob).toBeInstanceOf(Blob);
    expect(await asset?.fileBlob?.text()).toBe('contenido-real');

    // The original project keeps existing untouched.
    expect(await getProjectFromStorage('proj-eai-1')).not.toBeNull();
    expect((await getAllProjectsFromStorage()).length).toBe(2);
  });

  it('does not overwrite a project when the skip strategy matches an existing id', async () => {
    const project = makeProject();
    await saveProjectToStorage(project);

    const pkg = await createEAIPackage(project);
    pkg.project.title = 'Título alterado en el paquete';

    const result = await restoreProjectFromEAI(pkg, 'skip');

    expect(result.title).toBe('Proyecto EAI');
    expect((await getAllProjectsFromStorage()).length).toBe(1);
  });

  it('overwrites metadata while preserving existing binaries if the package lacks them', async () => {
    const project = makeProject();
    await saveMediaAssetBlob(project.mediaAssets[0]);
    await saveProjectToStorage(project);

    const pkg = await createEAIPackage(project);
    pkg.bundledAssets = pkg.bundledAssets.map(({ dataBase64: _data, ...asset }) => asset);
    pkg.project.description = 'Descripción actualizada';

    const restored = await restoreProjectFromEAI(pkg, 'overwrite');

    expect(restored.id).toBe('proj-eai-1');
    expect(restored.description).toBe('Descripción actualizada');
    expect((await getProjectFromStorage('proj-eai-1'))?.description).toBe('Descripción actualizada');

    const asset = await getMediaAssetBlob('asset-eai-1');
    expect(await asset?.fileBlob?.text()).toBe('contenido-real');
  });

  it('rejects tampered checksums and foreign files', async () => {
    const project = makeProject(false);
    const pkg = await createEAIPackage(project);

    const tampered = JSON.stringify({
      ...pkg,
      project: { ...pkg.project, title: 'Manipulado' },
    });
    const parsed = await validateAndParseEAIPackage(tampered);
    expect(parsed.checksumValid).toBe(false);

    await expect(validateAndParseEAIPackage('{"format":"OTRO"}')).rejects.toThrow();
    await expect(validateAndParseEAIPackage('no es json')).rejects.toThrow();
    await expect(
      restoreProjectFromEAI({ ...pkg, project: {} as unknown as Project }, 'create_copy')
    ).rejects.toThrow();
  });
});
