// Persistence regression tests: schema migration, durable IndexedDB round-trips,
// orphan binary cleanup, active-project recovery and debounced autosave.
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Project, TimelineTrack } from '../types';
import { DEMO_PROJECT } from '../data/demoProject';
import {
  migrateProject,
  needsProjectMigration,
  PROJECT_SCHEMA_VERSION,
} from '../services/storage/projectMigration';
import {
  cleanupOrphanedAssets,
  deleteProjectFromStorage,
  getAllProjectsFromStorage,
  getLastActiveProjectId,
  getMediaAssetBlob,
  getProjectFromStorage,
  saveMediaAssetBlob,
  saveProjectToStorage,
  setLastActiveProjectId,
} from '../services/storage/db';
import { ProjectAutosaver } from '../services/storage/autosave';

function makeLegacyProject(): Record<string, unknown> {
  return {
    id: 'legacy-1',
    title: 'Proyecto legado',
    description: 'Sin timeline ni versión',
    createdAt: 1000,
    updatedAt: 2000,
    angles: [],
    sources: [],
    script: {
      title: 'Proyecto legado',
      summary: '',
      targetAudience: 'Público general',
      tone: 'Tono inventado',
      scenes: [
        {
          id: 'scene-1',
          title: 'Escena',
          narrationText: 'Narración',
          visualIntent: 'Mostrar',
          cameraMotion: 'Movimiento raro',
          transition: 'Corte raro',
          durationSeconds: 3,
        },
      ],
    },
    mediaAssets: [],
    settings: { fps: 0, resolution: { width: 0, height: -10 }, aspectRatio: '21:9' },
  };
}

describe('Project schema migration', () => {
  it('upgrades a legacy document and repairs invalid values', () => {
    const migrated = migrateProject(makeLegacyProject());

    expect(migrated.schemaVersion).toBe(PROJECT_SCHEMA_VERSION);
    expect(migrated.settings.fps).toBe(30);
    expect(migrated.settings.resolution.width).toBe(1280);
    expect(migrated.settings.resolution.height).toBe(720);
    expect(migrated.settings.aspectRatio).toBe('16:9');
    expect(migrated.script.tone).toBe('Divulgativo');
    expect(migrated.script.scenes[0].cameraMotion).toBe('Static');
    expect(migrated.script.scenes[0].transition).toBe('Cut');
    expect(migrated.timeline?.tracks.length).toBeGreaterThan(0);
    expect(migrated.timeline?.tracks.find((t) => t.id === 'track-v1')?.clips).toHaveLength(1);
  });

  it('normalizes clip timing and preserves valid timeline data', () => {
    const tracks: TimelineTrack[] = [
      {
        id: 'track-v1',
        name: 'Video 1',
        type: 'video',
        order: 0,
        isMuted: false,
        isLocked: false,
        isVisible: true,
        clips: [
          {
            id: 'clip-a',
            name: 'Clip A',
            trackId: 'track-v1',
            type: 'image',
            startMs: -50,
            durationMs: 0,
            offsetMs: -20,
            speed: 99,
            opacity: 4,
            assetId: 'asset-1',
          },
        ],
      },
    ];

    const migrated = migrateProject({
      ...DEMO_PROJECT,
      timeline: { tracks },
    });

    const clip = migrated.timeline!.tracks[0].clips[0];
    expect(clip.startMs).toBe(0);
    expect(clip.durationMs).toBe(100);
    expect(clip.offsetMs).toBe(0);
    expect(clip.speed).toBe(4);
    expect(clip.opacity).toBe(1);
    expect(clip.assetId).toBe('asset-1');
    expect(clip.transform).toEqual({ x: 0, y: 0, scale: 1, rotation: 0 });
  });

  it('is idempotent and does not mutate the input', () => {
    const legacy = makeLegacyProject();
    const snapshot = JSON.parse(JSON.stringify(legacy));

    const once = migrateProject(legacy);
    const twice = migrateProject(once);

    expect(legacy).toEqual(snapshot);
    expect(twice).toEqual(once);
    expect(needsProjectMigration(legacy)).toBe(true);
    expect(needsProjectMigration(once)).toBe(false);
  });
});

describe('IndexedDB persistence layer', () => {
  it('round-trips projects and keeps binaries in the asset store', async () => {
    const project: Project = { ...DEMO_PROJECT, id: 'roundtrip-1' };
    const blob = new Blob(['hola'], { type: 'text/plain' });
    const asset = {
      id: 'asset-1',
      name: 'archivo.txt',
      type: 'image' as const,
      url: 'blob:stale',
      fileBlob: blob,
      mimeType: 'text/plain',
      sizeBytes: 4,
      license: 'Propia',
      provenance: 'Test',
      createdAt: Date.now(),
    };

    await saveMediaAssetBlob(asset);
    await saveProjectToStorage({ ...project, mediaAssets: [asset] });

    const restored = await getProjectFromStorage('roundtrip-1');
    expect(restored?.title).toBe(project.title);
    expect(restored?.timeline?.tracks.length).toBeGreaterThan(0);
    // Project records do not duplicate binary payloads.
    expect(restored?.mediaAssets[0].fileBlob).toBeUndefined();

    const storedAsset = await getMediaAssetBlob('asset-1');
    expect(storedAsset?.fileBlob).toBeInstanceOf(Blob);
    expect(await getLastActiveProjectId()).toBeNull();
  });

  it('remembers the last active project', async () => {
    await setLastActiveProjectId('proj-42');
    expect(await getLastActiveProjectId()).toBe('proj-42');
    await setLastActiveProjectId('proj-43');
    expect(await getLastActiveProjectId()).toBe('proj-43');
  });

  it('deletes a project and frees only its unreferenced binaries', async () => {
    const blob = new Blob(['x'], { type: 'image/png' });
    const asset = {
      id: 'asset-shared',
      name: 'imagen.png',
      type: 'image' as const,
      url: '',
      fileBlob: blob,
      mimeType: 'image/png',
      sizeBytes: 12,
      license: 'Propia',
      provenance: 'Test',
      createdAt: 1,
    };
    await saveMediaAssetBlob(asset);
    await saveMediaAssetBlob({ ...asset, id: 'asset-orphan' });

    await saveProjectToStorage({ ...DEMO_PROJECT, id: 'proj-delete', mediaAssets: [asset] });
    await saveProjectToStorage({ ...DEMO_PROJECT, id: 'proj-keep', mediaAssets: [asset] });

    await deleteProjectFromStorage('proj-delete');

    expect(await getProjectFromStorage('proj-delete')).toBeNull();
    expect((await getAllProjectsFromStorage()).map((p) => p.id)).toEqual(['proj-keep']);
    expect(await getMediaAssetBlob('asset-shared')).not.toBeNull();

    const cleanup = await cleanupOrphanedAssets(0);
    expect(cleanup.deletedCount).toBe(1);
    expect(await getMediaAssetBlob('asset-orphan')).toBeNull();
    expect(await getMediaAssetBlob('asset-shared')).not.toBeNull();
  });

  it('preserves recently created assets during orphan cleanup', async () => {
    await saveMediaAssetBlob({
      id: 'asset-fresh',
      name: 'recien-importado.png',
      type: 'image',
      url: '',
      mimeType: 'image/png',
      sizeBytes: 1,
      license: 'Propia',
      provenance: 'Importación en curso',
      createdAt: Date.now(),
    });

    const cleanup = await cleanupOrphanedAssets(60_000);
    expect(cleanup.deletedCount).toBe(0);
    expect(await getMediaAssetBlob('asset-fresh')).not.toBeNull();
  });
});

describe('Project autosave', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('coalesces rapid edits and saves only the newest state', async () => {
    const save = vi.fn(async (_project: Project) => undefined);
    const autosaver = new ProjectAutosaver({ save, debounceMs: 500 });

    autosaver.schedule({ ...DEMO_PROJECT, title: 'A' });
    autosaver.schedule({ ...DEMO_PROJECT, title: 'B' });
    autosaver.schedule({ ...DEMO_PROJECT, title: 'C' });

    expect(save).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(500);

    expect(save).toHaveBeenCalledTimes(1);
    expect(save.mock.calls[0][0].title).toBe('C');
  });

  it('retries transient failures and reports the recovered state', async () => {
    const save = vi
      .fn<[Project], Promise<void>>()
      .mockRejectedValueOnce(new Error('QuotaExceeded'))
      .mockResolvedValue(undefined);
    const statuses: string[] = [];
    const autosaver = new ProjectAutosaver({
      save,
      debounceMs: 50,
      retryDelayMs: 100,
      onStatus: (status) => statuses.push(status),
    });

    autosaver.schedule(DEMO_PROJECT);
    await vi.advanceTimersByTimeAsync(500);

    expect(save).toHaveBeenCalledTimes(2);
    expect(statuses).toContain('saving');
    expect(statuses[statuses.length - 1]).toBe('saved');
  });

  it('reports an error after exhausting retries without dropping later edits', async () => {
    const save = vi.fn(async () => {
      throw new Error('DB bloqueada');
    });
    const onStatus = vi.fn();
    const autosaver = new ProjectAutosaver({
      save,
      debounceMs: 10,
      retryDelayMs: 10,
      maxRetries: 1,
      onStatus,
    });

    autosaver.schedule(DEMO_PROJECT);
    await vi.advanceTimersByTimeAsync(200);

    expect(save).toHaveBeenCalledTimes(2);
    expect(onStatus).toHaveBeenCalledWith('error', expect.any(Error));
    expect(autosaver.getStatus()).toBe('error');
  });

  it('flushes pending changes immediately and stops accepting edits after dispose', async () => {
    const save = vi.fn(async () => undefined);
    const autosaver = new ProjectAutosaver({ save, debounceMs: 5000 });

    autosaver.schedule({ ...DEMO_PROJECT, title: 'Sin esperar' });
    await autosaver.dispose();

    expect(save).toHaveBeenCalledTimes(1);

    autosaver.schedule({ ...DEMO_PROJECT, title: 'Ignorado' });
    await vi.advanceTimersByTimeAsync(10_000);
    expect(save).toHaveBeenCalledTimes(1);
  });
});
