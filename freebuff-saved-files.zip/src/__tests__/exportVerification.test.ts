import { describe, it, expect } from 'vitest';
import { summarizeExportVerification } from '../engine/exportVerification';

const baseMetrics = {
  durationSeconds: 6.05,
  width: 640,
  height: 360,
  frames: [
    { luminance: 40, hash: 1 },
    { luminance: 52, hash: 2 },
    { luminance: 33, hash: 3 },
  ],
  audio: { durationSeconds: 6, peak: 0.4 },
  expected: { durationSeconds: 6, width: 640, height: 360, expectAudioTrack: true },
};

describe('summarizeExportVerification', () => {
  it('accepts a file with matching duration, size, picture and audio', () => {
    const result = summarizeExportVerification(baseMetrics);
    expect(result.ok).toBe(true);
    expect(result.warnings).toEqual([]);
    expect(result.framesSampled).toBe(3);
    expect(result.distinctFrames).toBe(3);
    expect(result.hasAudioTrack).toBe(true);
  });

  it('rejects a file whose duration does not match the timeline', () => {
    const result = summarizeExportVerification({ ...baseMetrics, durationSeconds: 12.5 });
    expect(result.ok).toBe(false);
    expect(result.warnings.join(' ')).toContain('Duración detectada');
  });

  it('rejects an unreadable duration and wrong resolution', () => {
    const result = summarizeExportVerification({
      ...baseMetrics,
      durationSeconds: null,
      width: 1280,
      height: 720,
    });
    expect(result.ok).toBe(false);
    expect(result.warnings.join(' ')).toContain('duración reproducible');
    expect(result.warnings.join(' ')).toContain('Resolución detectada');
  });

  it('rejects black output and reports a silent audio track', () => {
    const result = summarizeExportVerification({
      ...baseMetrics,
      frames: [{ luminance: 0.4, hash: 9 }],
      audio: { durationSeconds: 6, peak: 0 },
    });
    expect(result.ok).toBe(false);
    expect(result.warnings.join(' ')).toContain('negro');
    expect(result.warnings.join(' ')).toContain('silencio');
  });

  it('warns when the audio track cannot be decoded', () => {
    const result = summarizeExportVerification({ ...baseMetrics, audio: null });
    expect(result.ok).toBe(true);
    expect(result.hasAudioTrack).toBe(false);
    expect(result.warnings.join(' ')).toContain('pista de audio');
  });

  it('warns when every sampled frame is identical but keeps the file usable', () => {
    const result = summarizeExportVerification({
      ...baseMetrics,
      frames: [
        { luminance: 40, hash: 7 },
        { luminance: 40, hash: 7 },
      ],
    });
    expect(result.ok).toBe(true);
    expect(result.warnings.join(' ')).toContain('idénticos');
  });
});
