import { describe, it, expect } from 'vitest';
import { Project } from '../types';
import { DEMO_PROJECT } from '../data/demoProject';
import { migrateProject } from '../services/storage/projectMigration';
import { TimelineEngine, UndoRedoManager } from '../services/timeline/timelineEngine';
import { getFilmGrainSettings } from '../engine/mediaComposition';
import { SilenceDetector } from '../services/audio/silenceDetector';

describe('Film grain', () => {
  it('defaults to 8% enabled', () => {
    const grain = getFilmGrainSettings(DEMO_PROJECT);
    expect(grain.enabled).toBe(true);
    expect(grain.amount).toBeCloseTo(0.08);
  });

  it('migrates legacy projects with default grain', () => {
    const migrated = migrateProject({ ...DEMO_PROJECT, settings: { ...DEMO_PROJECT.settings, filmGrain: undefined, filmGrainEnabled: undefined, filmGrainAmount: undefined } });
    expect(migrated.settings.filmGrain?.amount).toBeCloseTo(0.08);
    expect(migrated.settings.filmGrain?.enabled).toBe(true);
  });

  it('respects explicit 0% grain', () => {
    const project = { ...DEMO_PROJECT, settings: { ...DEMO_PROJECT.settings, filmGrain: { enabled: true, amount: 0 }, filmGrainEnabled: true, filmGrainAmount: 0 } };
    const grain = getFilmGrainSettings(project);
    expect(grain.enabled).toBe(true);
    expect(grain.amount).toBe(0);
  });

  it('respects 20% grain', () => {
    const project = { ...DEMO_PROJECT, settings: { ...DEMO_PROJECT.settings, filmGrain: { enabled: true, amount: 0.2 }, filmGrainEnabled: true, filmGrainAmount: 0.2 } };
    const grain = getFilmGrainSettings(project);
    expect(grain.enabled).toBe(true);
    expect(grain.amount).toBeCloseTo(0.2);
  });

  it('disables grain when enabled is false', () => {
    const project = { ...DEMO_PROJECT, settings: { ...DEMO_PROJECT.settings, filmGrain: { enabled: false, amount: 0.08 }, filmGrainEnabled: false, filmGrainAmount: 0.08 } };
    const grain = getFilmGrainSettings(project);
    expect(grain.enabled).toBe(false);
  });
});

describe('Silence detection', () => {
  it('detects a silent segment', () => {
    const sampleRate = 1000;
    const samples = new Array(2000).fill(0);
    // loud burst then silence then loud burst
    for (let i = 0; i < 200; i++) samples[i] = 0.5;
    for (let i = 1800; i < 2000; i++) samples[i] = 0.5;
    const segments = SilenceDetector.detectFromSamples(samples, sampleRate, {
      thresholdDb: -40,
      minDurationMs: 500,
      windowMs: 50,
    });
    expect(segments.length).toBeGreaterThan(0);
    expect(segments[0].durationMs).toBeGreaterThanOrEqual(500);
  });
});

describe('J/L cuts (audioOffset)', () => {
  it('defaults to 0 and persists', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clip = initialized.timeline!.tracks[0].clips[0];
    expect(clip.audioOffset).toBe(0);
  });

  it('sets and clamps audioOffset', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const updated = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, 5000);
    const clip = updated.timeline!.tracks[0].clips[0];
    expect(clip.audioOffset).toBe(2000);

    const updated2 = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, -5000);
    expect(updated2.timeline!.tracks[0].clips[0].audioOffset).toBe(-2000);
  });

  it('migrates audioOffset', () => {
    const raw = { ...DEMO_PROJECT, timeline: { tracks: [{ id: 'track-v1', name: 'V', type: 'video', order: 0, isMuted: false, isLocked: false, isVisible: true, clips: [{ id: 'c1', name: 'C', trackId: 'track-v1', type: 'video', startMs: 0, durationMs: 1000, offsetMs: 0, audioOffset: 123.4 }] }] } };
    const migrated = migrateProject(raw as unknown as Project);
    expect(migrated.timeline!.tracks[0].clips[0].audioOffset).toBe(123);
  });

  it('audioOffset +500 means J-cut (audio starts 500ms before video)', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const updated = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, 500);
    const clip = updated.timeline!.tracks[0].clips[0];
    expect(clip.audioOffset).toBe(500);
    // Positive audioOffset: audio enters before video (J-cut)
    // clipStartMs = max(0, clip.startMs - audioOffsetMs) = max(0, clip.startMs - 500)
    const clipStartMs = Math.max(0, clip.startMs - clip.audioOffset!);
    // For the demo clip (startMs=0), clipStartMs is clamped to 0
    expect(clipStartMs).toBe(Math.max(0, clip.startMs - 500));
  });

  it('audioOffset -500 means L-cut (audio starts 500ms after video)', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const updated = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, -500);
    const clip = updated.timeline!.tracks[0].clips[0];
    expect(clip.audioOffset).toBe(-500);
    // Negative audioOffset: audio enters after video (L-cut)
    // clipStartMs = max(0, clip.startMs - audioOffsetMs) = max(0, clip.startMs + 500)
    const clipStartMs = Math.max(0, clip.startMs - clip.audioOffset!);
    expect(clipStartMs).toBe(Math.max(0, clip.startMs + 500));
  });

  it('audioOffset values are clamped to +/-2000ms', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const updated1 = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, 10000);
    expect(updated1.timeline!.tracks[0].clips[0].audioOffset).toBe(2000);
    const updated2 = TimelineEngine.setAudioOffset(initialized, 'track-v1', clipId, -10000);
    expect(updated2.timeline!.tracks[0].clips[0].audioOffset).toBe(-2000);
  });
});

describe('Silence actions', () => {
  it('cuts a silence range and preserves leading/trailing clips', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const start = initialized.timeline!.tracks[0].clips[0].startMs;
    const cut = TimelineEngine.cutClipRange(initialized, 'track-v1', clipId, start + 200, start + 700);
    const clips = cut.timeline!.tracks[0].clips;
    expect(clips.some((c) => c.id === `${clipId}-lead`)).toBe(true);
    expect(clips.some((c) => c.id === `${clipId}-tail`)).toBe(true);
    expect(clips.some((c) => c.id === clipId)).toBe(false);
  });

  it('mutes a silence range without deleting audio', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const start = initialized.timeline!.tracks[0].clips[0].startMs;
    const muted = TimelineEngine.muteClipRange(initialized, 'track-v1', clipId, start + 200, start + 700);
    const mutedClip = muted.timeline!.tracks[0].clips.find((c) => c.id === `${clipId}-muted`);
    expect(mutedClip).toBeDefined();
    expect(mutedClip?.isMuted).toBe(true);
    expect(mutedClip?.volume).toBe(0);
  });

  it('supports undo/redo after silence cut', () => {
    const initialized = TimelineEngine.ensureTimeline(DEMO_PROJECT);
    const history = new UndoRedoManager(10);
    const clipId = initialized.timeline!.tracks[0].clips[0].id;
    const start = initialized.timeline!.tracks[0].clips[0].startMs;
    history.pushState(initialized);
    const cut = TimelineEngine.cutClipRange(initialized, 'track-v1', clipId, start + 200, start + 700);
    const undone = history.undo(cut);
    expect(undone?.timeline?.tracks[0].clips.some((c) => c.id === clipId)).toBe(true);
  });
});
