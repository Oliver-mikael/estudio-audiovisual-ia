import { describe, it, expect } from 'vitest';
import { encodeEbmlSize, patchWebmDuration } from '../engine/webmDuration';

function bytes(...values: number[]): Uint8Array {
  return new Uint8Array(values);
}

function concat(parts: Uint8Array[]): Uint8Array {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

function element(id: number[], payload: Uint8Array, size?: Uint8Array): Uint8Array {
  const encodedSize = size ?? encodeEbmlSize(payload.length);
  return concat([new Uint8Array(id), encodedSize, payload]);
}

function blobFrom(data: Uint8Array, type: string): Blob {
  const copy = new Uint8Array(data);
  return new Blob([copy.buffer as ArrayBuffer], { type });
}

function buildWebm(options: { duration?: boolean; seekHead?: boolean } = {}): Uint8Array {
  const infoChildren = [
    element([0x2a, 0xd7, 0xb1], bytes(0x0f, 0x42, 0x40)), // TimecodeScale 1,000,000
    element([0x4d, 0x80], new TextEncoder().encode('test')),
  ];
  if (options.duration) {
    const duration = new Uint8Array(8);
    new DataView(duration.buffer).setFloat64(0, 6000, false);
    infoChildren.push(element([0x44, 0x89], duration));
  }
  const info = element([0x15, 0x49, 0xa9, 0x66], concat(infoChildren));
  const segmentChildren = [
    ...(options.seekHead ? [element([0x11, 0x4d, 0x9b, 0x74], new Uint8Array(0))] : []),
    info,
    element([0x1f, 0x43, 0xb6, 0x75], bytes(0xe7, 0x81, 0x00)),
  ];
  const segmentPayload = concat(segmentChildren);
  // Unknown-size segment, like MediaRecorder output (8-byte unknown size).
  const segment = concat([
    new Uint8Array([0x18, 0x53, 0x80, 0x67]),
    new Uint8Array([0x01, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff]),
    segmentPayload,
  ]);

  const ebmlHeader = element(
    [0x1a, 0x45, 0xdf, 0xa3],
    concat([element([0x42, 0x86], bytes(1)), element([0x42, 0xf7], bytes(1))])
  );
  return concat([ebmlHeader, segment]);
}

function hasDuration(bytesIn: Uint8Array): boolean {
  for (let i = 0; i < bytesIn.length - 1; i++) {
    if (bytesIn[i] === 0x44 && bytesIn[i + 1] === 0x89) return true;
  }
  return false;
}

describe('patchWebmDuration', () => {
  it('encodes EBML sizes with the marker bit', () => {
    expect(Array.from(encodeEbmlSize(5))).toEqual([0x85]);
    expect(Array.from(encodeEbmlSize(200))).toEqual([0x40, 0xc8]);
    expect(Array.from(encodeEbmlSize(127))).toEqual([0x40, 0x7f]);
  });

  it('inserts a Duration element into a live WebM', async () => {
    const original = buildWebm();
    const blob = blobFrom(original, 'video/webm');
    const patched = await patchWebmDuration(blob, 6.1);

    expect(patched).not.toBeNull();
    const out = new Uint8Array(await patched!.arrayBuffer());
    expect(out.length).toBe(original.length + 11);
    expect(hasDuration(out)).toBe(true);
    expect(hasDuration(original)).toBe(false);

    // Duration is stored in TimecodeScale units (ms with the default scale).
    const marker = out.findIndex((value, index) => value === 0x44 && out[index + 1] === 0x89);
    const durationValue = new DataView(out.buffer).getFloat64(marker + 3, false);
    expect(durationValue).toBeCloseTo(6100, 3);
  });

  it('does not duplicate an existing Duration', async () => {
    const blob = blobFrom(buildWebm({ duration: true }), 'video/webm');
    expect(await patchWebmDuration(blob, 6)).toBeNull();
  });

  it('refuses containers with absolute-offset tables', async () => {
    const blob = blobFrom(buildWebm({ seekHead: true }), 'video/webm');
    expect(await patchWebmDuration(blob, 6)).toBeNull();
  });

  it('ignores MP4 files', async () => {
    const blob = blobFrom(new Uint8Array(64), 'video/mp4');
    expect(await patchWebmDuration(blob, 6)).toBeNull();
  });
});
