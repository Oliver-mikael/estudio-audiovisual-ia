// Background Task Manager
// A persistent, cancellable job queue for autosave, backup/sync, export and
// restore. It is honest about execution: tasks stay in this module ("app must
// stay open") unless a handler really runs in a Worker/Service Worker, which is
// reported through `requiresAppOpen: false`.
//
// State is persisted on every transition so an interrupted session (app closed,
// OS killed the WebView) is recovered on the next start instead of being lost.

export type BackgroundTaskKind =
  | 'AUTOSAVE'
  | 'BACKUP'
  | 'SYNC'
  | 'EXPORT'
  | 'RESTORE'
  | 'CLEANUP';

export type BackgroundTaskStatus =
  | 'queued'
  | 'running'
  | 'paused'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'interrupted';

export interface BackgroundTask {
  id: string;
  kind: BackgroundTaskKind;
  label: string;
  status: BackgroundTaskStatus;
  /** 0..100 */
  progress: number;
  message?: string;
  error?: string;
  createdAt: number;
  updatedAt: number;
  startedAt?: number;
  finishedAt?: number;
  attempts: number;
  maxAttempts: number;
  /**
   * `true` means the work needs this tab/app alive (export, IndexedDB writes).
   * Only a handler backed by a Worker/Service Worker may report `false`.
   */
  requiresAppOpen: boolean;
  resumable: boolean;
  metadata?: Record<string, unknown>;
}

export interface TaskContext {
  signal: AbortSignal;
  update: (patch: { progress?: number; message?: string }) => void;
}

export type TaskHandler = (task: BackgroundTask, context: TaskContext) => Promise<void>;

export interface EnqueueTaskInput {
  kind: BackgroundTaskKind;
  label: string;
  metadata?: Record<string, unknown>;
  requiresAppOpen?: boolean;
  resumable?: boolean;
  maxAttempts?: number;
}

type Listener = (tasks: BackgroundTask[]) => void;

const STORAGE_KEY = 'estudio_background_tasks_v1';
const MAX_FINISHED_TASKS = 40;

function now(): number {
  return Date.now();
}

function createId(kind: BackgroundTaskKind): string {
  return `task_${kind.toLowerCase()}_${now()}_${Math.random().toString(36).slice(2, 7)}`;
}

/** localStorage when present, otherwise an in-memory map (tests/SSR). */
function readPersisted(): BackgroundTask[] {
  try {
    if (typeof localStorage === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as BackgroundTask[]) : [];
  } catch {
    return [];
  }
}

export class BackgroundTaskManager {
  private tasks: BackgroundTask[] = [];
  private handlers = new Map<BackgroundTaskKind, TaskHandler>();
  private listeners = new Set<Listener>();
  private controllers = new Map<string, AbortController>();
  private running = false;
  private notificationsEnabled = false;

  constructor() {
    this.tasks = readPersisted().map((task) =>
      task.status === 'running'
        ? { ...task, status: 'interrupted', updatedAt: now() }
        : task
    );
    this.persist();
  }

  public registerHandler(kind: BackgroundTaskKind, handler: TaskHandler): void {
    this.handlers.set(kind, handler);
  }

  public hasHandler(kind: BackgroundTaskKind): boolean {
    return this.handlers.has(kind);
  }

  public getTasks(): BackgroundTask[] {
    return [...this.tasks];
  }

  public getTasksByStatus(...statuses: BackgroundTaskStatus[]): BackgroundTask[] {
    return this.tasks.filter((task) => statuses.includes(task.status));
  }

  public getTask(taskId: string): BackgroundTask | null {
    return this.tasks.find((task) => task.id === taskId) ?? null;
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    listener(this.getTasks());
    return () => this.listeners.delete(listener);
  }

  /** Asks the browser for notification permission (no-op when unsupported). */
  public async enableNotifications(): Promise<boolean> {
    if (typeof Notification === 'undefined') return false;
    if (Notification.permission === 'granted') {
      this.notificationsEnabled = true;
      return true;
    }
    if (Notification.permission === 'denied') return false;
    try {
      const result = await Notification.requestPermission();
      this.notificationsEnabled = result === 'granted';
      return this.notificationsEnabled;
    } catch {
      return false;
    }
  }

  public enqueue(input: EnqueueTaskInput): BackgroundTask {
    const task: BackgroundTask = {
      id: createId(input.kind),
      kind: input.kind,
      label: input.label,
      status: 'queued',
      progress: 0,
      createdAt: now(),
      updatedAt: now(),
      attempts: 0,
      maxAttempts: Math.max(1, input.maxAttempts ?? 2),
      requiresAppOpen: input.requiresAppOpen ?? true,
      resumable: input.resumable ?? true,
      metadata: input.metadata,
    };

    this.tasks = [task, ...this.tasks];
    this.trimFinished();
    this.persist();
    this.emit();
    void this.runQueue();
    return task;
  }

  /**
   * Re-queues tasks left in `interrupted` state by a previous session. Tasks
   * that are not resumable are marked failed with an explicit reason.
   */
  public resumeInterrupted(): number {
    let resumed = 0;
    for (const task of this.tasks) {
      if (task.status !== 'interrupted') continue;
      if (task.resumable && this.handlers.has(task.kind)) {
        task.status = 'queued';
        task.message = 'Reanudando tras una interrupción de la aplicación...';
        task.updatedAt = now();
        resumed += 1;
      } else {
        task.status = 'failed';
        task.error = 'La operación se interrumpió al cerrarse la aplicación y no se puede reanudar.';
        task.updatedAt = now();
        task.finishedAt = now();
      }
    }
    this.persist();
    this.emit();
    if (resumed > 0) void this.runQueue();
    return resumed;
  }

  public cancel(taskId: string): void {
    const task = this.getTask(taskId);
    if (!task) return;
    if (task.status === 'completed' || task.status === 'failed' || task.status === 'cancelled') return;

    this.controllers.get(taskId)?.abort();
    this.controllers.delete(taskId);
    task.status = 'cancelled';
    task.message = 'Cancelada por el usuario.';
    task.finishedAt = now();
    task.updatedAt = now();
    this.persist();
    this.emit();
  }

  public pause(taskId: string): void {
    const task = this.getTask(taskId);
    if (!task || (task.status !== 'running' && task.status !== 'queued')) return;
    this.controllers.get(taskId)?.abort();
    this.controllers.delete(taskId);
    task.status = 'paused';
    task.message = 'Pausada; se puede reanudar manualmente.';
    task.updatedAt = now();
    this.persist();
    this.emit();
  }

  public resume(taskId: string): void {
    const task = this.getTask(taskId);
    if (!task || !['paused', 'failed', 'interrupted', 'cancelled'].includes(task.status)) return;
    task.status = 'queued';
    task.error = undefined;
    task.progress = 0;
    task.message = 'En cola para reanudar...';
    task.finishedAt = undefined;
    task.updatedAt = now();
    this.persist();
    this.emit();
    void this.runQueue();
  }

  public retry(taskId: string): void {
    const task = this.getTask(taskId);
    if (!task) return;
    task.attempts = 0;
    this.resume(taskId);
  }

  public clearFinished(): void {
    this.tasks = this.tasks.filter(
      (task) => !['completed', 'failed', 'cancelled'].includes(task.status)
    );
    this.persist();
    this.emit();
  }

  /** True while anything is queued or running (used for beforeunload hints). */
  public hasPendingWork(): boolean {
    return this.tasks.some((task) => task.status === 'queued' || task.status === 'running');
  }

  private async runQueue(): Promise<void> {
    if (this.running) return;
    this.running = true;

    try {
      for (;;) {
        // Oldest queued task first so a big export does not starve autosave.
        const next = [...this.tasks]
          .reverse()
          .find((task) => task.status === 'queued' && this.handlers.has(task.kind));
        if (!next) break;

        await this.execute(next);
      }
    } finally {
      this.running = false;
    }
  }

  private async execute(task: BackgroundTask): Promise<void> {
    const handler = this.handlers.get(task.kind);
    if (!handler) {
      task.status = 'failed';
      task.error = `No hay ejecutor registrado para ${task.kind}.`;
      task.updatedAt = now();
      this.persist();
      this.emit();
      return;
    }

    const controller = new AbortController();
    this.controllers.set(task.id, controller);

    task.status = 'running';
    task.progress = Math.max(0, task.progress);
    task.startedAt = task.startedAt ?? now();
    task.finishedAt = undefined;
    task.attempts += 1;
    task.message = 'En ejecución...';
    task.updatedAt = now();
    this.persist();
    this.emit();

    try {
      await handler(task, {
        signal: controller.signal,
        update: (patch) => {
          if (patch.progress !== undefined) {
            task.progress = Math.max(0, Math.min(100, Math.round(patch.progress)));
          }
          if (patch.message !== undefined) task.message = patch.message;
          task.updatedAt = now();
          this.persist();
          this.emit();
        },
      });

      // A cancel/pause during the run already set the final state.
      if (task.status === 'running') {
        task.status = 'completed';
        task.progress = 100;
        task.message = 'Completada.';
        task.finishedAt = now();
        task.updatedAt = now();
        this.notify(task);
      }
    } catch (error) {
      const aborted =
        controller.signal.aborted ||
        (error instanceof DOMException && error.name === 'AbortError') ||
        (error instanceof Error && error.name === 'AbortError');

      if (aborted) {
        // pause()/cancel() set the intended state before aborting.
        if (task.status === 'running') {
          task.status = 'interrupted';
          task.message = 'Interrumpida.';
        }
      } else if (task.status === 'running') {
        const message = error instanceof Error ? error.message : String(error);
        if (task.attempts < task.maxAttempts) {
          task.status = 'queued';
          task.message = `Reintentando (${task.attempts + 1}/${task.maxAttempts}): ${message}`;
        } else {
          task.status = 'failed';
          task.error = message;
          task.message = 'Falló.';
          task.finishedAt = now();
        }
      }
      task.updatedAt = now();
    } finally {
      this.controllers.delete(task.id);
      this.persist();
      this.emit();
    }
  }

  private notify(task: BackgroundTask): void {
    if (!this.notificationsEnabled && typeof Notification !== 'undefined') {
      this.notificationsEnabled = Notification.permission === 'granted';
    }
    if (!this.notificationsEnabled || typeof Notification === 'undefined') return;
    try {
      new Notification('Estudio Audiovisual', {
        body: `${task.label}: completada.`,
        tag: task.id,
      });
    } catch {
      /* Notifications are best effort (Android WebView may refuse them). */
    }
  }

  private trimFinished(): void {
    const finished = this.tasks.filter((task) =>
      ['completed', 'failed', 'cancelled'].includes(task.status)
    );
    if (finished.length <= MAX_FINISHED_TASKS) return;
    const keep = new Set(
      finished
        .sort((a, b) => b.updatedAt - a.updatedAt)
        .slice(0, MAX_FINISHED_TASKS)
        .map((task) => task.id)
    );
    this.tasks = this.tasks.filter(
      (task) => !finished.some((entry) => entry.id === task.id) || keep.has(task.id)
    );
  }

  private persist(): void {
    try {
      if (typeof localStorage === 'undefined') return;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.tasks));
    } catch {
      /* Quota or private mode: the in-memory queue still works. */
    }
  }

  private emit(): void {
    const snapshot = this.getTasks();
    for (const listener of this.listeners) listener(snapshot);
  }
}

export const backgroundTaskManager = new BackgroundTaskManager();
