// Subtitle Service (SRT)
// Parses/serializes SubRip files and maps cues to/from the T1 caption track so
// subtitles are editable, synchronized with the timeline and rendered/exported.
import { Project, SubtitleCue, TimelineClip } from '../../types';
import { TimelineEngine } from '../timeline/timelineEngine';

const SUBTITLE_TRACK_ID = 'track-t1';
const MIN_CUE_DURATION_MS = 200;
const MAX_CUE_DURATION_MS = 60 * 60 * 1000;

export interface SrtParseResult {
  cues: SubtitleCue[];
  skippedBlocks: number;
}

function buildCueId(index: number): string {
  return `cue-${Date.now()}-${index}-${Math.random().toString(36).slice(2, 6)}`;
}

/** Converts milliseconds to the SRT timestamp format (HH:MM:SS,mmm). */
export function formatSrtTimestamp(ms: number): string {
  const clamped = Math.max(0, Math.round(ms));
  const hours = Math.floor(clamped / 3_600_000);
  const minutes = Math.floor((clamped % 3_600_000) / 60_000);
  const seconds = Math.floor((clamped % 60_000) / 1000);
  const millis = clamped % 1000;
  return `${hours.toString().padStart(2, '0')}:${minutes
    .toString()
    .padStart(2, '0')}:${seconds.toString().padStart(2, '0')},${millis
    .toString()
    .padStart(3, '0')}`;
}

/** Parses an SRT timestamp (accepts comma or dot, optional hour) into milliseconds. */
export function parseSrtTimestamp(value: string): number | null {
  const match = value
    .trim()
    .match(/^(?:(\d{1,3}):)?(\d{1,2}):(\d{1,2})[,.](\d{1,3})$/);
  if (!match) return null;

  const hours = match[1] ? parseInt(match[1], 10) : 0;
  const minutes = parseInt(match[2], 10);
  const seconds = parseInt(match[3], 10);
  const millis = parseInt(match[4].padEnd(3, '0'), 10);

  if (minutes > 59 || seconds > 59) return null;
  return hours * 3_600_000 + minutes * 60_000 + seconds * 1000 + millis;
}

/** Removes SRT styling tags so text renders cleanly on the canvas. */
export function stripSubtitleMarkup(text: string): string {
  return text
    .replace(/<[^>]+>/g, '')
    .replace(/\{[^}]*\}/g, '')
    .replace(/\r/g, '')
    .trim();
}

/**
 * Parses SRT content defensively: tolerant of BOM, CRLF, missing indices and
 * cue positioning settings; malformed blocks are skipped instead of aborting.
 */
export function parseSrtDetailed(raw: string): SrtParseResult {
  const normalized = raw.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const blocks = normalized.split(/\n{2,}/);
  const cues: SubtitleCue[] = [];
  let skippedBlocks = 0;

  for (const block of blocks) {
    const lines = block.split('\n').filter((line) => line.trim().length > 0);
    if (lines.length < 2) {
      if (block.trim()) skippedBlocks++;
      continue;
    }

    const timeLineIndex = lines.findIndex((line) => line.includes('-->'));
    if (timeLineIndex === -1) {
      skippedBlocks++;
      continue;
    }

    const [rawStart, rawEnd] = lines[timeLineIndex].split('-->');
    const textLines = lines.slice(timeLineIndex + 1);
    if (!rawStart || !rawEnd || textLines.length === 0) {
      skippedBlocks++;
      continue;
    }

    // Ignore optional cue settings after the end timestamp (e.g. "X1:40 X2:600").
    const endToken = rawEnd.trim().split(/\s+/)[0];
    const startMs = parseSrtTimestamp(rawStart);
    const endMs = parseSrtTimestamp(endToken);
    const text = stripSubtitleMarkup(textLines.join('\n'));

    if (startMs === null || endMs === null || endMs <= startMs || !text) {
      skippedBlocks++;
      continue;
    }

    cues.push({
      id: buildCueId(cues.length),
      startMs,
      endMs: Math.min(endMs, startMs + MAX_CUE_DURATION_MS),
      text,
      isVerified: false,
    });
  }

  cues.sort((a, b) => a.startMs - b.startMs);
  return { cues, skippedBlocks };
}

export function parseSrt(raw: string): SubtitleCue[] {
  return parseSrtDetailed(raw).cues;
}

/** Serializes cues into a valid SRT document, enforcing positive durations. */
export function serializeSrt(cues: SubtitleCue[]): string {
  const ordered = [...cues].sort((a, b) => a.startMs - b.startMs);

  return ordered
    .map((cue, index) => {
      const start = Math.max(0, Math.round(cue.startMs));
      const end = Math.max(start + MIN_CUE_DURATION_MS, Math.round(cue.endMs));
      const text = cue.text.replace(/\r/g, '').trim();
      return `${index + 1}\n${formatSrtTimestamp(start)} --> ${formatSrtTimestamp(end)}\n${text}`;
    })
    .join('\n\n')
    .concat(ordered.length > 0 ? '\n' : '');
}

/**
 * Cues currently present in the project: T1 caption clips first, then scene
 * narration fragments as a fallback so SRT export always has content.
 */
export function getCaptionTrackCues(project: Project): SubtitleCue[] {
  const track = project.timeline?.tracks.find((candidate) => candidate.id === SUBTITLE_TRACK_ID);
  if (!track) return [];

  return track.clips
    .map((clip) => ({
      id: clip.id,
      startMs: clip.startMs,
      endMs: clip.startMs + clip.durationMs,
      text: (clip.textPayload || '').trim(),
    }))
    .filter((cue) => cue.text.length > 0)
    .sort((a, b) => a.startMs - b.startMs);
}

export function getProjectSubtitleCues(project: Project): SubtitleCue[] {
  const captionCues = getCaptionTrackCues(project);
  return captionCues.length > 0 ? captionCues : getSceneNarrationCues(project);
}

/** One cue per scene, using the scene duration as its time range. */
export function getSceneNarrationCues(project: Project): SubtitleCue[] {
  const cues: SubtitleCue[] = [];
  let cursorMs = 0;

  for (const [index, scene] of (project.script?.scenes || []).entries()) {
    const durationMs = Math.max(MIN_CUE_DURATION_MS, Math.round(scene.durationSeconds * 1000));
    const text = (scene.narrationText || '').trim();
    if (text) {
      cues.push({
        id: `scene-cue-${scene.id || index}`,
        startMs: cursorMs,
        endMs: cursorMs + durationMs,
        text,
      });
    }
    cursorMs += durationMs;
  }

  return cues;
}

/**
 * Replaces the T1 caption track with the given cues. Idempotent and safe for the
 * timeline model: only caption clips are touched, V1/A1 remain intact.
 */
export function applyCuesToProject(project: Project, cues: SubtitleCue[]): Project {
  const withTimeline = TimelineEngine.ensureTimeline(project);
  const ordered = [...cues].sort((a, b) => a.startMs - b.startMs);

  const clips: TimelineClip[] = ordered.map((cue, index) => {
    const startMs = Math.max(0, Math.round(cue.startMs));
    const durationMs = Math.max(MIN_CUE_DURATION_MS, Math.round(cue.endMs - startMs));

    return {
      id: cue.id || `cue-clip-${index}-${Date.now()}`,
      name: `Subtítulo ${index + 1}`,
      trackId: SUBTITLE_TRACK_ID,
      type: 'caption',
      startMs,
      durationMs,
      offsetMs: 0,
      opacity: 1,
      textPayload: cue.text,
    };
  });

  const tracks = withTimeline.timeline!.tracks.map((track) =>
    track.id === SUBTITLE_TRACK_ID ? { ...track, clips } : track
  );

  return {
    ...withTimeline,
    updatedAt: Date.now(),
    timeline: { ...withTimeline.timeline!, tracks },
  };
}

export function updateSubtitleCue(
  project: Project,
  cueId: string,
  patch: Partial<Pick<SubtitleCue, 'startMs' | 'endMs' | 'text'>>
): Project {
  const withTimeline = TimelineEngine.ensureTimeline(project);
  const tracks = withTimeline.timeline!.tracks.map((track) => {
    if (track.id !== SUBTITLE_TRACK_ID) return track;

    return {
      ...track,
      clips: track.clips
        .map((clip) => {
          if (clip.id !== cueId) return clip;

          const startMs = Math.max(0, Math.round(patch.startMs ?? clip.startMs));
          const endMs = Math.max(
            startMs + MIN_CUE_DURATION_MS,
            Math.round(patch.endMs ?? clip.startMs + clip.durationMs)
          );

          return {
            ...clip,
            startMs,
            durationMs: Math.max(MIN_CUE_DURATION_MS, endMs - startMs),
            textPayload: patch.text !== undefined ? patch.text : clip.textPayload,
          };
        })
        .sort((a, b) => a.startMs - b.startMs),
    };
  });

  return { ...withTimeline, updatedAt: Date.now(), timeline: { ...withTimeline.timeline!, tracks } };
}

export function addSubtitleCue(
  project: Project,
  startMs: number,
  durationMs: number = 2500,
  text: string = 'Nuevo subtítulo'
): { project: Project; cueId: string } {
  const cueId = `cue-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const cue: SubtitleCue = {
    id: cueId,
    startMs: Math.max(0, Math.round(startMs)),
    endMs: Math.max(0, Math.round(startMs)) + Math.max(MIN_CUE_DURATION_MS, Math.round(durationMs)),
    text,
  };

  // Keep existing cues untouched: overlaps are resolved by the editor, never by
  // silently deleting the user's subtitles.
  return { project: applyCuesToProject(project, [...getCaptionTrackCues(project), cue]), cueId };
}

export function removeSubtitleCue(project: Project, cueId: string): Project {
  const withTimeline = TimelineEngine.ensureTimeline(project);
  const tracks = withTimeline.timeline!.tracks.map((track) =>
    track.id === SUBTITLE_TRACK_ID
      ? { ...track, clips: track.clips.filter((clip) => clip.id !== cueId) }
      : track
  );

  return { ...withTimeline, updatedAt: Date.now(), timeline: { ...withTimeline.timeline!, tracks } };
}

/** Suggests the next free start time for a new cue. */
export function getNextCueStartMs(project: Project): number {
  const cues = getCaptionTrackCues(project);
  if (cues.length === 0) return 0;
  return Math.max(...cues.map((cue) => cue.endMs));
}
