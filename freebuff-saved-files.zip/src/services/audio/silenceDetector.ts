// Automatic silence detection based on the Web Audio API.
// Examines decoded audio buffers (or project clips) and returns the silent
// ranges as timeline markers. Pure-ish helpers so they can be unit-tested with
// synthetic sample arrays.

import { Project, TimelineMarker, SilenceSegment } from '../../types';

export interface SilenceDetectionOptions {
  /** Threshold in dB below which audio is considered silence (default -40). */
  thresholdDb?: number;
  /** Minimum silence duration in ms (default 500). */
  minDurationMs?: number;
  /** Analysis window in ms (default 50). */
  windowMs?: number;
  /** Gap shorter than this is merged into the silence (default 100). */
  holdMs?: number;
}

export interface SilenceAnalysisResult {
  segments: SilenceSegment[];
  markers: TimelineMarker[];
}

const DEFAULT_THRESHOLD_DB = -40;
const DEFAULT_MIN_DURATION_MS = 500;
const DEFAULT_WINDOW_MS = 50;
const DEFAULT_HOLD_MS = 100;

function clampOptions(options: SilenceDetectionOptions = {}): Required<SilenceDetectionOptions> {
  return {
    thresholdDb: Number.isFinite(options.thresholdDb) ? (options.thresholdDb as number) : DEFAULT_THRESHOLD_DB,
    minDurationMs: Math.max(50, Math.round(options.minDurationMs ?? DEFAULT_MIN_DURATION_MS)),
    windowMs: Math.max(10, Math.round(options.windowMs ?? DEFAULT_WINDOW_MS)),
    holdMs: Math.max(0, Math.round(options.holdMs ?? DEFAULT_HOLD_MS)),
  };
}

function toDb(rms: number): number {
  if (!Number.isFinite(rms) || rms <= 0) return -Infinity;
  return 20 * Math.log10(rms);
}

interface AudioLikeBuffer {
  sampleRate: number;
  numberOfChannels: number;
  length: number;
  getChannelData(channel: number): Float32Array;
}

/**
 * Detects silence segments inside a decoded audio buffer.
 */
export function detectSilencesInBuffer(
  buffer: AudioLikeBuffer,
  options: SilenceDetectionOptions = {}
): SilenceSegment[] {
  const opts = clampOptions(options);
  const sampleRate = buffer.sampleRate;
  const windowSamples = Math.max(1, Math.round((opts.windowMs / 1000) * sampleRate));
  const minWindows = Math.max(1, Math.ceil(opts.minDurationMs / opts.windowMs));
  const holdWindows = Math.max(0, Math.round(opts.holdMs / opts.windowMs));

  const windows: boolean[] = [];
  const totalWindows = Math.floor(buffer.length / windowSamples);
  for (let w = 0; w < totalWindows; w++) {
    let sumSquares = 0;
    let count = 0;
    for (let ch = 0; ch < buffer.numberOfChannels; ch++) {
      const data = buffer.getChannelData(ch);
      const start = w * windowSamples;
      for (let i = 0; i < windowSamples; i++) {
        const sample = data[start + i] || 0;
        sumSquares += sample * sample;
        count++;
      }
    }
    const rms = Math.sqrt(sumSquares / Math.max(1, count));
    windows.push(toDb(rms) < opts.thresholdDb);
  }

  // Merge short non-silent gaps inside a silence (hold).
  const merged: boolean[] = [...windows];
  if (holdWindows > 0) {
    for (let i = 0; i < merged.length; i++) {
      if (merged[i]) continue;
      // gap of silence? Actually fill short non-silent gaps.
      let gap = 0;
      while (i + gap < merged.length && !merged[i + gap]) gap++;
      if (gap <= holdWindows && i > 0 && i + gap < merged.length && merged[i - 1] && merged[i + gap]) {
        for (let j = 0; j < gap; j++) merged[i + j] = true;
      }
    }
  }

  const segments: SilenceSegment[] = [];
  let runStart = -1;
  for (let i = 0; i <= merged.length; i++) {
    const isSilent = i < merged.length && merged[i];
    if (isSilent && runStart === -1) runStart = i;
    if ((!isSilent || i === merged.length) && runStart !== -1) {
      const runLength = i - runStart;
      if (runLength >= minWindows) {
        const startMs = Math.round((runStart * opts.windowMs));
        const endMs = Math.round((i * opts.windowMs));
        segments.push({
          id: `silence-${runStart}-${i}`,
          startMs,
          endMs,
          durationMs: endMs - startMs,
        });
      }
      runStart = -1;
    }
  }

  return segments;
}

/**
 * Detects silences from a plain sample array (mono). Useful for tests.
 */
export function detectSilencesInSamples(
  samples: Float32Array | number[],
  sampleRate: number,
  options: SilenceDetectionOptions = {}
): SilenceSegment[] {
  const buffer: AudioLikeBuffer = {
    sampleRate,
    numberOfChannels: 1,
    length: samples.length,
    getChannelData: () => (samples instanceof Float32Array ? samples : new Float32Array(samples)),
  };
  return detectSilencesInBuffer(buffer, options);
}

export function silenceSegmentsToMarkers(
  segments: SilenceSegment[],
  baseTimeMs: number = 0
): TimelineMarker[] {
  return segments.map((segment, index) => ({
    id: segment.id || `silence-marker-${index}`,
    timeMs: baseTimeMs + segment.startMs,
    endMs: baseTimeMs + segment.endMs,
    durationMs: segment.durationMs,
    label: `Silencio ${(segment.durationMs / 1000).toFixed(2)}s`,
    color: 'amber',
    type: 'silence',
  }));
}

export class SilenceDetector {
  static detect(buffer: AudioLikeBuffer, options?: SilenceDetectionOptions): SilenceSegment[] {
    return detectSilencesInBuffer(buffer, options);
  }

  static detectFromSamples(
    samples: Float32Array | number[],
    sampleRate: number,
    options?: SilenceDetectionOptions
  ): SilenceSegment[] {
    return detectSilencesInSamples(samples, sampleRate, options);
  }

  /** Async wrapper that decodes and analyzes without blocking the UI thread. */
  static async analyzeBuffer(
    buffer: AudioLikeBuffer,
    options?: SilenceDetectionOptions
  ): Promise<SilenceSegment[]> {
    // Yield to the event loop before heavy work.
    await new Promise((resolve) => setTimeout(resolve, 0));
    return detectSilencesInBuffer(buffer, options);
  }

  /** Analyzes all audio (and embedded video) clips in a project. */
  static async analyzeProject(
    project: Project,
    options?: SilenceDetectionOptions
  ): Promise<SilenceAnalysisResult> {
    const segments: SilenceSegment[] = [];
    const markers: TimelineMarker[] = [];
    const audioCtxCtor =
      typeof window !== 'undefined'
        ? window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
        : undefined;

    const tracks = project.timeline?.tracks || [];
    // Yield between clips to keep the UI responsive.
    for (const track of tracks) {
      if (track.type !== 'audio' && track.type !== 'video') continue;
      for (const clip of track.clips) {
        if (clip.isMuted) continue;
        // Resolve binary.
        let blob: Blob | undefined;
        const asset = (project.mediaAssets || []).find((a) => a.id === clip.assetId);
        blob = asset?.fileBlob;
        if (!blob && clip.assetId) {
          try {
            const { getMediaAssetBlob } = await import('../storage/db');
            const stored = await getMediaAssetBlob(clip.assetId);
            blob = stored?.fileBlob;
          } catch {
            blob = undefined;
          }
        }
        if (!blob) continue;

        let buffer: AudioLikeBuffer | null = null;
        if (audioCtxCtor) {
          try {
            const ctx = new audioCtxCtor();
            const arrayBuffer = await blob.arrayBuffer();
            buffer = (await ctx.decodeAudioData(arrayBuffer)) as AudioLikeBuffer;
            ctx.close();
          } catch {
            buffer = null;
          }
        }
        if (!buffer) continue;

        const clipSegments = detectSilencesInBuffer(buffer, options);
        for (const seg of clipSegments) {
          const mapped: SilenceSegment = {
            id: `${clip.id}-${seg.id}`,
            startMs: clip.startMs + seg.startMs,
            endMs: clip.startMs + seg.endMs,
            durationMs: seg.durationMs,
          };
          segments.push(mapped);
        }
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }

    // Build markers from segments.
    for (const seg of segments) {
      markers.push({
        id: seg.id || `silence-${seg.startMs}`,
        timeMs: seg.startMs,
        endMs: seg.endMs,
        durationMs: seg.durationMs,
        label: `Silencio ${(seg.durationMs / 1000).toFixed(2)}s`,
        color: 'amber',
        type: 'silence',
      });
    }

    return { segments, markers };
  }

  /** Applies detected silence markers to a project (replacing prior silence markers). */
  static applyMarkers(project: Project, markers: TimelineMarker[]): Project {
    const updated = { ...project };
    const timeline = updated.timeline ? { ...updated.timeline } : { tracks: [], markers: [] };
    const existing = (timeline.markers || []).filter((m) => m.type !== 'silence');
    timeline.markers = [...existing, ...markers];
    updated.timeline = timeline as Project['timeline'];
    return updated;
  }
}

// Convenience aliases.
export const detectSilences = detectSilencesInBuffer;
export const analyzeSilences = SilenceDetector.analyzeProject;
export type { SilenceSegment as SilenceRange };

// Alias exports for common naming.
export { SilenceDetector as SilenceAnalyzer };
export default SilenceDetector;
