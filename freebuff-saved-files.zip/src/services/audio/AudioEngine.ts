// Core Web Audio Engine for Multitrack Mixing & Video Audio Synchronization (Phase 7D)
import { Project, TimelineClip } from '../../types';
import { AudioTrackConfig, AudioDuckingOptions } from '../../types/audio';
import { getMediaAssetBlob } from '../storage/db';

export interface AudioPreloadResult {
  loadedCount: number;
  failedClipAssetIds: string[];
}

export class AudioEngine {
  private static instance: AudioEngine | null = null;
  private audioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private destinationNode: MediaStreamAudioDestinationNode | null = null;
  private trackGainNodes: Map<string, GainNode> = new Map();
  private effectiveTrackGains: Map<string, number> = new Map();
  private bufferCache: Map<string, AudioBuffer> = new Map();
  private activeSourceNodes: AudioBufferSourceNode[] = [];
  /** Video elements whose embedded audio track is mixed through the graph. */
  private mediaElementNodes: Map<
    string,
    { source: MediaElementAudioSourceNode; gain: GainNode; element: HTMLVideoElement }
  > = new Map();
  private bufferLastUsed: Map<AudioBuffer, number> = new Map();
  private bufferUseCounter = 0;
  private decodedBufferBytes = 0;
  /** Decoded audio is kept under 64 MB so long music tracks cannot exhaust mobile RAM. */
  private readonly maxDecodedBufferBytes = 64 * 1024 * 1024;

  public isPlaying: boolean = false;
  public currentPlayheadMs: number = 0;
  public playbackStartedAt: number = 0;

  private constructor() {}

  public static getInstance(): AudioEngine {
    if (!AudioEngine.instance) {
      AudioEngine.instance = new AudioEngine();
    }
    return AudioEngine.instance;
  }

  /**
   * Initializes or resumes the singleton AudioContext to comply with browser autoplay policies.
   */
  public async initContext(): Promise<AudioContext> {
    if (!this.audioCtx) {
      const AudioCtxClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();

      // Master output gain
      this.masterGain = this.audioCtx.createGain();
      this.masterGain.gain.setValueAtTime(1.0, this.audioCtx.currentTime);

      // Connect master gain to hardware speakers
      this.masterGain.connect(this.audioCtx.destination);

      // MediaStream destination for real-time video export mixing
      this.destinationNode = this.audioCtx.createMediaStreamDestination();
      this.masterGain.connect(this.destinationNode);
    }

    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }

    return this.audioCtx;
  }

  public getContext(): AudioContext | null {
    return this.audioCtx;
  }

  public getDestinationStream(): MediaStream | null {
    return this.destinationNode ? this.destinationNode.stream : null;
  }

  /**
   * Loads and decodes an audio buffer from URL or Blob.
   *
   * `cacheKey` lets callers cache the decoded buffer under the clip's `assetId`
   * while the binary is fetched from the asset URL. Both keys point to the same
   * buffer so timeline clips (which only know `assetId`) can reuse it.
   */
  public async loadBuffer(url: string, fileBlob?: Blob, cacheKey?: string): Promise<AudioBuffer> {
    const primaryKey = cacheKey || url;

    const cachedPrimary = this.bufferCache.get(primaryKey);
    if (cachedPrimary) {
      if (primaryKey !== url) this.bufferCache.set(url, cachedPrimary);
      this.touchBuffer(cachedPrimary);
      return cachedPrimary;
    }

    const cachedByUrl = this.bufferCache.get(url);
    if (cachedByUrl) {
      this.bufferCache.set(primaryKey, cachedByUrl);
      this.touchBuffer(cachedByUrl);
      return cachedByUrl;
    }

    const ctx = await this.initContext();
    let arrayBuffer: ArrayBuffer;

    if (fileBlob) {
      arrayBuffer = await fileBlob.arrayBuffer();
    } else {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Error descargando audio desde ${url} (${response.status})`);
      }
      arrayBuffer = await response.arrayBuffer();
    }

    const decoded = await ctx.decodeAudioData(arrayBuffer);
    this.bufferCache.set(primaryKey, decoded);
    if (primaryKey !== url) {
      this.bufferCache.set(url, decoded);
    }
    this.touchBuffer(decoded);
    this.evictBuffers(decoded);
    return decoded;
  }

  private touchBuffer(buffer: AudioBuffer): void {
    if (!this.bufferLastUsed.has(buffer)) {
      this.decodedBufferBytes += buffer.length * buffer.numberOfChannels * 4;
    }
    this.bufferLastUsed.set(buffer, ++this.bufferUseCounter);
  }

  /**
   * Drops the least recently used decoded buffers until the cache fits the memory
   * budget. Sources already playing keep their own reference, so eviction is safe.
   */
  private evictBuffers(keep?: AudioBuffer): void {
    while (this.decodedBufferBytes > this.maxDecodedBufferBytes) {
      let oldest: AudioBuffer | null = null;
      let oldestUse = Infinity;
      for (const [buffer, use] of this.bufferLastUsed) {
        if (buffer === keep) continue;
        if (use < oldestUse) {
          oldest = buffer;
          oldestUse = use;
        }
      }
      if (!oldest) break;

      this.decodedBufferBytes -= oldest.length * oldest.numberOfChannels * 4;
      this.bufferLastUsed.delete(oldest);
      for (const [key, value] of this.bufferCache) {
        if (value === oldest) this.bufferCache.delete(key);
      }
    }
  }

  /** Frees every decoded buffer (used after an export to release mobile RAM). */
  public releaseDecodedBuffers(): void {
    this.bufferCache.clear();
    this.bufferLastUsed.clear();
    this.decodedBufferBytes = 0;
  }

  public getDecodedBufferBytes(): number {
    return this.decodedBufferBytes;
  }

  /**
   * Routes a video element's own audio track into the mix graph.
   *
   * A media element can only be captured once (`createMediaElementSource`), so
   * the node is cached per asset. Chromium silences the graph output while the
   * element is muted, which is why the element is unmuted here and its level is
   * controlled exclusively by the attached GainNode.
   */
  public attachMediaElement(assetId: string, element: HTMLVideoElement): boolean {
    if (!this.audioCtx || !this.masterGain) return false;
    if (this.mediaElementNodes.has(assetId)) return true;

    try {
      const source = this.audioCtx.createMediaElementSource(element);
      const gain = this.audioCtx.createGain();
      gain.gain.setValueAtTime(0, this.audioCtx.currentTime);
      source.connect(gain);
      gain.connect(this.masterGain);

      element.muted = false;
      element.volume = 1;

      this.mediaElementNodes.set(assetId, { source, gain, element });
      return true;
    } catch {
      return false;
    }
  }

  /** Sets the level of a routed video's embedded audio (0 silences the clip). */
  public setMediaElementGain(assetId: string, gain: number): void {
    const entry = this.mediaElementNodes.get(assetId);
    if (!entry || !this.audioCtx) return;
    const bounded = Math.max(0, Math.min(2, gain));
    const now = this.audioCtx.currentTime;

    entry.gain.gain.cancelScheduledValues(now);
    if (bounded <= 0) {
      // Exact zero, not an exponential approach, and mute the element as well:
      // a silent clip must never leave a residue in the exported mix.
      entry.gain.gain.setValueAtTime(0, now);
      entry.element.muted = true;
      return;
    }

    entry.element.muted = false;
    entry.element.volume = 1;
    entry.gain.gain.setValueAtTime(entry.gain.gain.value, now);
    entry.gain.gain.linearRampToValueAtTime(bounded, now + 0.02);
  }

  public getAttachedMediaAssetIds(): string[] {
    return Array.from(this.mediaElementNodes.keys());
  }

  /** Disconnects every routed video element (after an export or on dispose). */
  public detachMediaElements(): void {
    for (const entry of this.mediaElementNodes.values()) {
      entry.gain.gain.setValueAtTime(0, this.audioCtx?.currentTime ?? 0);
      try {
        entry.source.disconnect();
      } catch {
        /* Node may already be disconnected. */
      }
      try {
        entry.gain.disconnect();
      } catch {
        /* Node may already be disconnected. */
      }
      entry.element.muted = true;
    }
    this.mediaElementNodes.clear();
  }

  /**
   * Loads every audio asset referenced by timeline clips, caching each decoded
   * buffer under its `assetId` (the key the scheduler looks up).
   *
   * Assets without binary (blob) and without a fetchable URL are reported as
   * failures so callers can surface the degradation instead of hiding it. Playback
   * still falls back to the procedural tone for those clips.
   */
  public async preloadProjectAudio(project: Project): Promise<AudioPreloadResult> {
    const audioTracks = (project.timeline?.tracks || []).filter((t) => t.type === 'audio');
    const videoTracks = (project.timeline?.tracks || []).filter((t) => t.type === 'video');
    const assetsById = new Map((project.mediaAssets || []).map((asset) => [asset.id, asset]));
    const failedClipAssetIds: string[] = [];
    let loadedCount = 0;

    for (const track of audioTracks) {
      for (const clip of track.clips) {
        const assetId = clip.assetId;
        if (!assetId || this.bufferCache.has(assetId)) continue;

        const asset = assetsById.get(assetId);
        let blob = asset?.fileBlob;

        if (!blob) {
          try {
            const stored = await getMediaAssetBlob(assetId);
            blob = stored?.fileBlob;
          } catch {
            // IndexedDB may be unavailable (private mode / restricted WebView).
            blob = undefined;
          }
        }

        const url = asset?.url || '';
        const hasFetchableUrl = /^(blob:|data:|https?:)/i.test(url);

        if (!blob && !hasFetchableUrl) {
          failedClipAssetIds.push(assetId);
          continue;
        }

        try {
          await this.loadBuffer(url || assetId, blob, assetId);
          loadedCount++;
        } catch {
          failedClipAssetIds.push(assetId);
        }
      }
    }

    // Video clips only need their own audio decoded when an A/V desync (J/L cut)
    // is requested: otherwise their soundtrack plays through the media element.
    for (const track of videoTracks) {
      if (track.isMuted || !track.isVisible) continue;
      for (const clip of track.clips) {
        if (clip.isMuted || (clip.volume ?? 1) <= 0) continue;
        if ((clip.audioOffset || 0) === 0) continue;
        const assetId = clip.assetId;
        if (!assetId || this.bufferCache.has(assetId)) continue;

        const asset = assetsById.get(assetId);
        let blob = asset?.fileBlob;
        if (!blob) {
          try {
            const stored = await getMediaAssetBlob(assetId);
            blob = stored?.fileBlob;
          } catch {
            blob = undefined;
          }
        }
        const url = asset?.url || '';
        const hasFetchableUrl = /^(blob:|data:|https?:)/i.test(url);
        if (!blob && !hasFetchableUrl) {
          failedClipAssetIds.push(assetId);
          continue;
        }
        try {
          await this.loadBuffer(url || assetId, blob, assetId);
          loadedCount++;
        } catch {
          failedClipAssetIds.push(assetId);
        }
      }
    }

    return { loadedCount, failedClipAssetIds };
  }

  /**
   * Configures gain nodes for all audio tracks in the project.
   */
  public setupTracks(trackConfigs: AudioTrackConfig[]): void {
    if (!this.audioCtx || !this.masterGain) return;

    // Check if any track has 'solo' active
    const hasSolo = trackConfigs.some((t) => t.isSolo);

    trackConfigs.forEach((cfg) => {
      let gainNode = this.trackGainNodes.get(cfg.id);
      if (!gainNode) {
        gainNode = this.audioCtx!.createGain();
        gainNode.connect(this.masterGain!);
        this.trackGainNodes.set(cfg.id, gainNode);
      }

      // Compute effective volume
      let effectiveGain = cfg.volume;
      if (cfg.isMuted) effectiveGain = 0;
      if (hasSolo && !cfg.isSolo) effectiveGain = 0;

      this.effectiveTrackGains.set(cfg.id, effectiveGain);
      gainNode.gain.setValueAtTime(effectiveGain, this.audioCtx!.currentTime);
    });
  }

  /**
   * Returns the gain node of a track (used by meters and diagnostics).
   */
  public getTrackGainNode(trackId: string): GainNode | undefined {
    return this.trackGainNodes.get(trackId);
  }

  /**
   * Plays all audio clips from the project synchronized with the playhead.
   */
  public async play(
    project: Project,
    startFromMs: number = 0,
    ducking?: AudioDuckingOptions
  ): Promise<void> {
    await this.schedulePlayback(project, startFromMs, ducking);
  }

  /**
   * Schedules every audio clip against an absolute AudioContext time and returns
   * it. Export uses this to launch picture and sound on one clock, so preload
   * time can never offset the audio from the first frame.
   */
  public async schedulePlayback(
    project: Project,
    startFromMs: number = 0,
    ducking?: AudioDuckingOptions,
    leadSeconds: number = 0
  ): Promise<{ startTime: number }> {
    await this.initContext();
    this.stop(); // Stop any active playback

    if (!this.audioCtx) return { startTime: 0 };

    // Resolve imported audio binaries before scheduling so timeline clips play
    // their real asset instead of the procedural fallback.
    await this.preloadProjectAudio(project);

    const startTime = this.audioCtx.currentTime + Math.max(0, leadSeconds);
    this.isPlaying = true;
    this.currentPlayheadMs = startFromMs;
    this.playbackStartedAt = startTime;

    const audioTracks = (project.timeline?.tracks || []).filter((t) => t.type === 'audio');

    for (const track of audioTracks) {
      if (!track.isVisible || track.isMuted) continue;

      let trackGain = this.trackGainNodes.get(track.id);
      if (!trackGain) {
        trackGain = this.audioCtx.createGain();
        trackGain.connect(this.masterGain!);
        this.trackGainNodes.set(track.id, trackGain);
        if (!this.effectiveTrackGains.has(track.id)) {
          this.effectiveTrackGains.set(track.id, 1.0);
        }
      }

      for (const clip of track.clips) {
        const audioOffsetMs = clip.audioOffset || 0;
        // Positive audioOffset: audio enters before video (J-cut).
        const clipStartMs = Math.max(0, clip.startMs - audioOffsetMs);
        const clipEndMs = clipStartMs + clip.durationMs;

        // Clip hasn't played yet or is currently active
        if (clipEndMs > startFromMs) {
          const delayUntilPlaySeconds = Math.max(0, (clipStartMs - startFromMs) / 1000);
          const offsetIntoClipSeconds =
            startFromMs > clipStartMs
              ? (startFromMs - clipStartMs + (clip.offsetMs || 0)) / 1000
              : (clip.offsetMs || 0) / 1000;
          const remainingDurationSeconds = Math.max(
            0.1,
            (clipEndMs - Math.max(clipStartMs, startFromMs)) / 1000
          );

          // If the clip references an asset or generated synthetic tone
          await this.scheduleClip(
            clip,
            trackGain,
            delayUntilPlaySeconds,
            offsetIntoClipSeconds,
            remainingDurationSeconds,
            startTime
          );
        }
      }
    }

    // Embedded (video) audio with a J/L desync is scheduled as its own source
    // because the media element cannot offset its soundtrack independently.
    const videoTracks = (project.timeline?.tracks || []).filter((t) => t.type === 'video');
    for (const track of videoTracks) {
      if (!track.isVisible || track.isMuted) continue;
      for (const clip of track.clips) {
        const audioOffsetMs = clip.audioOffset || 0;
        if (audioOffsetMs === 0) continue;
        if (clip.isMuted || (clip.volume ?? 1) <= 0) continue;

        let trackGain = this.trackGainNodes.get(track.id);
        if (!trackGain) {
          trackGain = this.audioCtx.createGain();
          trackGain.connect(this.masterGain!);
          this.trackGainNodes.set(track.id, trackGain);
          if (!this.effectiveTrackGains.has(track.id)) {
            this.effectiveTrackGains.set(track.id, 1.0);
          }
        }

        const clipStartMs = Math.max(0, clip.startMs - audioOffsetMs);
        const clipEndMs = clipStartMs + clip.durationMs;
        if (clipEndMs <= startFromMs) continue;

        const delayUntilPlaySeconds = Math.max(0, (clipStartMs - startFromMs) / 1000);
        const offsetIntoClipSeconds =
          startFromMs > clipStartMs
            ? (startFromMs - clipStartMs + (clip.offsetMs || 0)) / 1000
            : (clip.offsetMs || 0) / 1000;
        const remainingDurationSeconds = Math.max(
          0.1,
          (clipEndMs - Math.max(clipStartMs, startFromMs)) / 1000
        );

        await this.scheduleClip(
          clip,
          trackGain,
          delayUntilPlaySeconds,
          offsetIntoClipSeconds,
          remainingDurationSeconds,
          startTime
        );
      }
    }

    if (ducking?.enabled) {
      this.applyDuckingAutomation(project, startFromMs, ducking, startTime);
    }

    return { startTime };
  }

  /**
   * Attenuates every target track while a narration (trigger) clip is active,
   * using linear gain ramps on the track gain nodes.
   */
  private applyDuckingAutomation(
    project: Project,
    startFromMs: number,
    ducking: AudioDuckingOptions,
    baseTime?: number
  ): void {
    if (!this.audioCtx) return;

    const attackSeconds = Math.max(0, ducking.attackSeconds ?? 0.15);
    const releaseSeconds = Math.max(0, ducking.releaseSeconds ?? 0.3);
    const triggerTrackIds = ducking.triggerTrackIds?.length
      ? ducking.triggerTrackIds
      : ['track-a1'];

    const intervals = this.collectTriggerIntervals(
      project,
      triggerTrackIds,
      startFromMs,
      (attackSeconds + releaseSeconds) * 1000
    );

    if (intervals.length === 0) return;

    const amountByTrackId = ducking.amountByTrackId || {};
    const now = baseTime ?? this.audioCtx.currentTime;

    for (const [trackId, rawAmount] of Object.entries(amountByTrackId)) {
      const amount = Math.max(0, Math.min(1, rawAmount));
      if (amount <= 0) continue;

      const gainNode = this.trackGainNodes.get(trackId);
      if (!gainNode) continue;

      const baseGain = this.effectiveTrackGains.get(trackId) ?? 1.0;
      const duckedGain = baseGain * (1 - amount);

      for (const interval of intervals) {
        const startSec = now + Math.max(0, interval.startMs - startFromMs) / 1000;
        const endSec = now + Math.max(0, interval.endMs - startFromMs) / 1000;
        const attackStartSec = Math.max(now, startSec - attackSeconds);

        gainNode.gain.setValueAtTime(baseGain, attackStartSec);
        if (startSec > attackStartSec) {
          gainNode.gain.linearRampToValueAtTime(duckedGain, startSec);
        } else {
          gainNode.gain.setValueAtTime(duckedGain, startSec);
        }
        gainNode.gain.setValueAtTime(duckedGain, endSec);
        gainNode.gain.linearRampToValueAtTime(baseGain, endSec + releaseSeconds);
      }
    }
  }

  /**
   * Collects and merges the active intervals of the ducking trigger tracks.
   */
  private collectTriggerIntervals(
    project: Project,
    triggerTrackIds: string[],
    fromMs: number,
    mergeGapMs: number
  ): Array<{ startMs: number; endMs: number }> {
    const intervals: Array<{ startMs: number; endMs: number }> = [];

    for (const track of project.timeline?.tracks || []) {
      if (track.type !== 'audio' || !triggerTrackIds.includes(track.id)) continue;
      if (!track.isVisible || track.isMuted) continue;

      for (const clip of track.clips) {
        const endMs = clip.startMs + clip.durationMs;
        if (endMs <= fromMs) continue;
        intervals.push({ startMs: Math.max(fromMs, clip.startMs), endMs });
      }
    }

    intervals.sort((a, b) => a.startMs - b.startMs);

    const merged: Array<{ startMs: number; endMs: number }> = [];
    for (const interval of intervals) {
      const last = merged[merged.length - 1];
      if (last && interval.startMs <= last.endMs + mergeGapMs) {
        last.endMs = Math.max(last.endMs, interval.endMs);
      } else {
        merged.push({ ...interval });
      }
    }

    return merged;
  }

  /**
   * Schedules a buffer source or procedurally synthesized tone for a clip.
   */
  private async scheduleClip(
    clip: TimelineClip,
    targetGain: GainNode,
    delaySeconds: number,
    offsetSeconds: number,
    durationSeconds: number,
    baseTime?: number
  ): Promise<void> {
    if (!this.audioCtx) return;

    const startTime = (baseTime ?? this.audioCtx.currentTime) + delaySeconds;

    const buffer = clip.assetId ? this.bufferCache.get(clip.assetId) : undefined;

    if (buffer) {
      const source = this.audioCtx.createBufferSource();
      source.buffer = buffer;
      source.playbackRate.value = clip.speed || 1.0;

      // Individual clip gain
      const clipGain = this.audioCtx.createGain();
      clipGain.gain.setValueAtTime(clip.volume !== undefined ? clip.volume : 1.0, startTime);
      source.connect(clipGain);
      clipGain.connect(targetGain);

      source.start(startTime, offsetSeconds, durationSeconds);
      this.activeSourceNodes.push(source);
    } else {
      // Procedural harmonic tone generation for clips without explicit binary assets
      const osc = this.audioCtx.createOscillator();
      const oscGain = this.audioCtx.createGain();

      // Pitch based on track type
      osc.type = clip.trackId === 'track-a2' ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(clip.trackId === 'track-a2' ? 110 : 220, startTime);

      const level = (clip.volume || 1.0) * 0.05;
      oscGain.gain.setValueAtTime(0.001, startTime);
      oscGain.gain.linearRampToValueAtTime(level, startTime + 0.05); // Fade in
      oscGain.gain.setValueAtTime(level, startTime + Math.max(0.05, durationSeconds - 0.05));
      oscGain.gain.linearRampToValueAtTime(0.001, startTime + durationSeconds); // Fade out

      osc.connect(oscGain);
      oscGain.connect(targetGain);

      osc.start(startTime);
      osc.stop(startTime + durationSeconds);
      this.activeSourceNodes.push(osc as unknown as AudioBufferSourceNode);
    }
  }

  /**
   * Stops all scheduled sound sources and resets playhead tracking.
   */
  public stop(): void {
    this.activeSourceNodes.forEach((node) => {
      try {
        node.stop();
        node.disconnect();
      } catch (_) {}
    });
    this.activeSourceNodes = [];
    this.isPlaying = false;
  }

  /**
   * Sets master audio output volume (0.0 to 1.5).
   */
  public setMasterVolume(level: number): void {
    if (!this.masterGain || !this.audioCtx) return;
    const bounded = Math.max(0, Math.min(1.5, level));
    this.masterGain.gain.setValueAtTime(bounded, this.audioCtx.currentTime);
  }

  /**
   * Resets and cleans up Web Audio nodes on application unload.
   */
  public dispose(): void {
    this.stop();
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      this.audioCtx.close();
    }
    this.audioCtx = null;
    this.masterGain = null;
    this.destinationNode = null;
    this.trackGainNodes.clear();
    this.effectiveTrackGains.clear();
    this.bufferCache.clear();
    this.mediaElementNodes.clear();
  }
}

export const audioEngine = AudioEngine.getInstance();
