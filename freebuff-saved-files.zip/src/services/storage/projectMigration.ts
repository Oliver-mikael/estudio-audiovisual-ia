// Project Schema Migration
// Normalizes projects loaded from IndexedDB or .eai packages so older documents
// gain the timeline model, clip defaults and valid settings without data loss.
import {
  ClipAnimation,
  ClipTransition,
  MediaAsset,
  MediaFolder,
  NarrativeAngle,
  Project,
  Scene,
  SourceReference,
  TimelineClip,
  TimelineMarker,
  TimelineTrack,
} from '../../types';
import { TimelineEngine } from '../timeline/timelineEngine';

export const PROJECT_SCHEMA_VERSION = 2;

const CAMERA_MOTIONS: Scene['cameraMotion'][] = [
  'Static',
  'Zoom In',
  'Zoom Out',
  'Pan Left',
  'Pan Right',
  'Kinetic Text',
];
const SCENE_TRANSITIONS: Scene['transition'][] = ['Cut', 'Fade', 'Slide', 'Zoom'];
const TONES: Project['script']['tone'][] = [
  'Divulgativo',
  'Riguroso',
  'Dramático',
  'Crítico',
  'Minimalista',
];
const ASPECT_RATIOS: Project['settings']['aspectRatio'][] = ['16:9', '9:16', '1:1', '4:3', '4:5'];
const TRACK_TYPES: TimelineTrack['type'][] = ['video', 'audio', 'text', 'subtitles'];
const CLIP_TYPES: TimelineClip['type'][] = ['video', 'image', 'audio', 'text', 'caption'];

function asString(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value : fallback;
}

function asNumber(value: unknown, fallback: number): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function asPositiveInteger(value: unknown, fallback: number, max = 100_000): number {
  const raw = asNumber(value, fallback);
  const parsed = Math.round(raw > 0 ? raw : fallback);
  return Math.max(1, Math.min(max, parsed));
}

function asArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function normalizeScene(raw: unknown, index: number): Scene {
  const scene = (raw || {}) as Partial<Scene>;
  return {
    id: asString(scene.id, `scene-migrated-${index + 1}`),
    title: asString(scene.title, `Escena ${index + 1}`),
    narrationText: asString(scene.narrationText, ''),
    visualIntent: asString(scene.visualIntent, 'Composición audiovisual'),
    cameraMotion: CAMERA_MOTIONS.includes(scene.cameraMotion as Scene['cameraMotion'])
      ? (scene.cameraMotion as Scene['cameraMotion'])
      : 'Static',
    transition: SCENE_TRANSITIONS.includes(scene.transition as Scene['transition'])
      ? (scene.transition as Scene['transition'])
      : 'Cut',
    durationSeconds: Math.max(0.5, asNumber(scene.durationSeconds, 5)),
    imageUrl: typeof scene.imageUrl === 'string' ? scene.imageUrl : undefined,
    audioUrl: typeof scene.audioUrl === 'string' ? scene.audioUrl : undefined,
    subtitles: Array.isArray(scene.subtitles)
      ? scene.subtitles.filter((line): line is string => typeof line === 'string')
      : undefined,
    notes: typeof scene.notes === 'string' ? scene.notes : undefined,
  };
}

function normalizeMediaAsset(raw: unknown, index: number): MediaAsset {
  const asset = (raw || {}) as Partial<MediaAsset>;
  const type: MediaAsset['type'] =
    asset.type === 'audio' || asset.type === 'video' || asset.type === 'image'
      ? asset.type
      : 'image';

  return {
    id: asString(asset.id, `asset-migrated-${index + 1}`),
    name: asString(asset.name, `Recurso ${index + 1}`),
    type,
    url: asString(asset.url, ''),
    fileBlob: asset.fileBlob instanceof Blob ? asset.fileBlob : undefined,
    mimeType: asString(asset.mimeType, 'application/octet-stream'),
    sizeBytes: Math.max(0, asNumber(asset.sizeBytes, 0)),
    license: asString(asset.license, 'Desconocida'),
    provenance: asString(asset.provenance, 'Desconocida'),
    createdAt: asNumber(asset.createdAt, Date.now()),
    width: typeof asset.width === 'number' ? asset.width : undefined,
    height: typeof asset.height === 'number' ? asset.height : undefined,
    durationSeconds:
      typeof asset.durationSeconds === 'number' ? asset.durationSeconds : undefined,
    aspectRatio: typeof asset.aspectRatio === 'string' ? asset.aspectRatio : undefined,
    thumbnailUrl: typeof asset.thumbnailUrl === 'string' ? asset.thumbnailUrl : undefined,
    sha256: typeof asset.sha256 === 'string' ? asset.sha256 : undefined,
    folderId: typeof asset.folderId === 'string' ? asset.folderId : undefined,
    tags: Array.isArray(asset.tags)
      ? asset.tags.filter((tag): tag is string => typeof tag === 'string')
      : undefined,
    isMissing: asset.isMissing === true ? true : undefined,
  };
}

function normalizeTransition(raw: unknown): ClipTransition | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const transition = raw as Partial<ClipTransition>;
  const type = asString(transition.type, 'fade') as ClipTransition['type'];
  const allowed: ClipTransition['type'][] = [
    'cut',
    'fade',
    'crossfade',
    'slide-left',
    'slide-right',
    'slide-up',
    'slide-down',
    'zoom-in',
    'zoom-out',
    'wipe-left',
    'wipe-right',
    'fade-to-black',
    'fade-from-black',
  ];
  if (!allowed.includes(type)) return undefined;

  return {
    id: asString(transition.id, `transition-${Date.now()}`),
    type,
    durationMs: Math.max(50, asNumber(transition.durationMs, 800)),
    easing: transition.easing,
    fromClipId: transition.fromClipId,
    toClipId: transition.toClipId,
  };
}

function normalizeAnimations(raw: unknown): ClipAnimation[] | undefined {
  if (!Array.isArray(raw)) return undefined;
  const allowed: ClipAnimation['property'][] = [
    'positionX',
    'positionY',
    'scale',
    'rotation',
    'opacity',
  ];

  const animations: ClipAnimation[] = [];
  for (const item of raw) {
    const animation = (item || {}) as Partial<ClipAnimation>;
    if (!allowed.includes(animation.property as ClipAnimation['property'])) continue;
    const keyframes = asArray<ClipAnimation['keyframes'][number]>(animation.keyframes)
      .map((keyframe, index) => ({
        id: asString(keyframe.id, `kf-${index}`),
        timeOffsetMs: Math.max(0, asNumber(keyframe.timeOffsetMs, 0)),
        value: asNumber(keyframe.value, 0),
        easing: keyframe.easing,
      }))
      .sort((a, b) => a.timeOffsetMs - b.timeOffsetMs);
    if (keyframes.length > 0) {
      animations.push({ property: animation.property as ClipAnimation['property'], keyframes });
    }
  }

  return animations.length > 0 ? animations : undefined;
}

function normalizeClip(raw: unknown, trackId: string, index: number): TimelineClip {
  const clip = (raw || {}) as Partial<TimelineClip>;
  const startMs = Math.max(0, Math.round(asNumber(clip.startMs, 0)));
  const durationMs = Math.max(100, Math.round(asNumber(clip.durationMs, 5000)));

  return {
    id: asString(clip.id, `clip-migrated-${trackId}-${index}`),
    name: asString(clip.name, `Clip ${index + 1}`),
    trackId,
    sceneId: typeof clip.sceneId === 'string' ? clip.sceneId : undefined,
    assetId: typeof clip.assetId === 'string' ? clip.assetId : undefined,
    type: CLIP_TYPES.includes(clip.type as TimelineClip['type'])
      ? (clip.type as TimelineClip['type'])
      : 'video',
    startMs,
    durationMs,
    offsetMs: Math.max(0, Math.round(asNumber(clip.offsetMs, 0))),
    audioOffset: Math.max(-2000, Math.min(2000, Math.round(asNumber(clip.audioOffset, 0)))),
    volume: typeof clip.volume === 'number' ? Math.max(0, Math.min(2, clip.volume)) : 1,
    speed: typeof clip.speed === 'number' ? Math.max(0.25, Math.min(4, clip.speed)) : 1,
    opacity: typeof clip.opacity === 'number' ? Math.max(0, Math.min(1, clip.opacity)) : 1,
    transform: {
      x: asNumber(clip.transform?.x, 0),
      y: asNumber(clip.transform?.y, 0),
      scale: asNumber(clip.transform?.scale, 1),
      rotation: asNumber(clip.transform?.rotation, 0),
    },
    colorAdjustments: {
      brightness: asNumber(clip.colorAdjustments?.brightness, 0),
      contrast: asNumber(clip.colorAdjustments?.contrast, 1),
      saturation: asNumber(clip.colorAdjustments?.saturation, 1),
      temperature: asNumber(clip.colorAdjustments?.temperature, 0),
      vignette: asNumber(clip.colorAdjustments?.vignette, 0),
    },
    filterPreset: clip.filterPreset,
    textPayload: typeof clip.textPayload === 'string' ? clip.textPayload : undefined,
    isMuted: clip.isMuted === true ? true : undefined,
    isLocked: clip.isLocked === true ? true : undefined,
    transition: normalizeTransition(clip.transition),
    animations: normalizeAnimations(clip.animations),
  };
}

function normalizeTrack(raw: unknown, index: number): TimelineTrack {
  const track = (raw || {}) as Partial<TimelineTrack>;
  const id = asString(track.id, `track-migrated-${index + 1}`);
  const clips = asArray<unknown>(track.clips)
    .map((clip, clipIndex) => normalizeClip(clip, id, clipIndex))
    .sort((a, b) => a.startMs - b.startMs);

  return {
    id,
    name: asString(track.name, `Pista ${index + 1}`),
    type: TRACK_TYPES.includes(track.type as TimelineTrack['type'])
      ? (track.type as TimelineTrack['type'])
      : 'video',
    order: asNumber(track.order, index),
    isMuted: track.isMuted === true,
    isLocked: track.isLocked === true,
    isVisible: track.isVisible !== false,
    clips,
    transitions: Array.isArray(track.transitions)
      ? track.transitions
          .map(normalizeTransition)
          .filter((value): value is ClipTransition => Boolean(value))
      : undefined,
  };
}

function normalizeMarkers(raw: unknown): TimelineMarker[] {
  return asArray<TimelineMarker>(raw)
    .filter((marker) => marker && typeof marker === 'object')
    .map((marker, index) => ({
      id: asString(marker.id, `marker-${index}`),
      timeMs: Math.max(0, asNumber(marker.timeMs, 0)),
      endMs: typeof marker.endMs === 'number' ? Math.max(0, marker.endMs) : undefined,
      durationMs: typeof marker.durationMs === 'number' ? Math.max(0, marker.durationMs) : undefined,
      label: asString(marker.label, `Marcador ${index + 1}`),
      color: marker.color || 'indigo',
      type: marker.type === 'silence' ? 'silence' : 'marker',
    }));
}

/**
 * Upgrades any stored project document to the current schema. Idempotent, never
 * mutates the input and never discards user data.
 */
export function migrateProject(raw: Project | Record<string, unknown>): Project {
  const input = (raw || {}) as Partial<Project>;
  const now = Date.now();

  const scenes = asArray<unknown>(input.script?.scenes).map(normalizeScene);
  const angles = asArray<NarrativeAngle>(input.angles).filter((angle) => angle && typeof angle === 'object');
  const sources = asArray<SourceReference>(input.sources).filter(
    (source) => source && typeof source === 'object'
  );
  const mediaAssets = asArray<unknown>(input.mediaAssets).map(normalizeMediaAsset);
  const folders = asArray<MediaFolder>(input.folders).filter(
    (folder) => folder && typeof folder === 'object'
  );

  const resolution = input.settings?.resolution;
  const rawWidth = asNumber(resolution?.width, 1280);
  const rawHeight = asNumber(resolution?.height, 720);
  const width = Math.max(16, Math.min(7680, Math.round(rawWidth > 0 ? rawWidth : 1280)));
  const height = Math.max(16, Math.min(4320, Math.round(rawHeight > 0 ? rawHeight : 720)));

  const normalized: Project = {
    id: asString(input.id, `proj-${now}`),
    title: asString(input.title, 'Proyecto sin título'),
    description: asString(input.description, ''),
    createdAt: asNumber(input.createdAt, now),
    updatedAt: asNumber(input.updatedAt, now),
    angles,
    sources,
    script: {
      title: asString(input.script?.title, asString(input.title, 'Proyecto sin título')),
      summary: asString(input.script?.summary, ''),
      targetAudience: asString(input.script?.targetAudience, 'Público general'),
      tone: TONES.includes(input.script?.tone as Project['script']['tone'])
        ? (input.script!.tone as Project['script']['tone'])
        : 'Divulgativo',
      scenes,
    },
    mediaAssets,
    settings: {
      fps: asPositiveInteger(input.settings?.fps, 30, 120),
      resolution: { width, height },
      aspectRatio: ASPECT_RATIOS.includes(input.settings?.aspectRatio as Project['settings']['aspectRatio'])
        ? (input.settings!.aspectRatio as Project['settings']['aspectRatio'])
        : '16:9',
      filmGrain: input.settings?.filmGrain
        ? {
            enabled: input.settings.filmGrain.enabled !== false,
            amount: Math.max(0, Math.min(0.2, asNumber(input.settings.filmGrain.amount, 0.08))),
          }
        : {
            enabled: input.settings?.filmGrainEnabled !== false,
            amount: Math.max(0, Math.min(0.2, asNumber(input.settings?.filmGrainAmount, 0.08))),
          },
      filmGrainEnabled: input.settings?.filmGrainEnabled !== false,
      filmGrainAmount: Math.max(0, Math.min(0.2, asNumber(input.settings?.filmGrainAmount ?? input.settings?.filmGrain?.amount, 0.08))),
    },
    folders: folders.length > 0 ? folders : undefined,
    schemaVersion: PROJECT_SCHEMA_VERSION,
  };

  const sourceTimeline =
    input.timeline && Array.isArray(input.timeline.tracks) && input.timeline.tracks.length > 0
      ? input.timeline
      : TimelineEngine.ensureTimeline(normalized).timeline;

  const tracks = (sourceTimeline?.tracks || [])
    .map(normalizeTrack)
    .sort((a, b) => a.order - b.order);

  normalized.timeline = {
    tracks,
    activeTrackId: asString(sourceTimeline?.activeTrackId, tracks[0]?.id),
    markers: normalizeMarkers(sourceTimeline?.markers),
  };

  return normalized;
}

/**
 * Returns true when the stored document was created by an older schema.
 */
export function needsProjectMigration(raw: unknown): boolean {
  if (!raw || typeof raw !== 'object') return true;
  const candidate = raw as Partial<Project>;
  return (
    candidate.schemaVersion !== PROJECT_SCHEMA_VERSION ||
    !candidate.timeline ||
    !Array.isArray(candidate.timeline.tracks) ||
    candidate.timeline.tracks.length === 0
  );
}
