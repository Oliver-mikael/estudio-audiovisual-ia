// IndexedDB Local Storage Service for Projects and Media Blobs
// Versioned schema with safe transactions, project migration, active-project
// tracking and orphaned binary cleanup.

import { Project, MediaAsset } from '../../types';
import { migrateProject, needsProjectMigration, PROJECT_SCHEMA_VERSION } from './projectMigration';

const DB_NAME = 'EstudioAudiovisualDB';
const DB_VERSION = 2;
const STORE_PROJECTS = 'projects';
const STORE_ASSETS = 'assets';
const STORE_META = 'meta';

const LAST_ACTIVE_PROJECT_KEY = 'lastActiveProjectId';

interface MetaRecord {
  key: string;
  value: unknown;
}

export interface OrphanCleanupResult {
  deletedCount: number;
  freedBytes: number;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB no está disponible en este entorno.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_ASSETS)) {
        db.createObjectStore(STORE_ASSETS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };

    request.onsuccess = () => {
      const db = request.result;
      // Let a future version upgrade in another tab close this connection cleanly.
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () =>
      reject(new Error('La base de datos está bloqueada por otra pestaña. Cierra otras pestañas del estudio.'));
  });
}

/**
 * Runs a request inside a transaction and resolves only when the transaction
 * commits, so a reported save is actually durable.
 */
async function runStoreRequest<T>(
  storeName: string,
  mode: IDBTransactionMode,
  action: (store: IDBObjectStore) => IDBRequest<T> | null
): Promise<T | undefined> {
  const db = await openDB();

  return new Promise<T | undefined>((resolve, reject) => {
    let result: T | undefined;
    let settled = false;

    const tx = db.transaction(storeName, mode);
    const store = tx.objectStore(storeName);

    const request = action(store);
    if (request) {
      request.onsuccess = () => {
        result = request.result;
      };
      request.onerror = () => {
        if (!settled) {
          settled = true;
          reject(request.error);
        }
      };
    }

    tx.oncomplete = () => {
      if (!settled) {
        settled = true;
        resolve(result);
      }
      db.close();
    };
    tx.onerror = () => {
      if (!settled) {
        settled = true;
        reject(tx.error);
      }
      db.close();
    };
    tx.onabort = () => {
      if (!settled) {
        settled = true;
        reject(tx.error || new Error('Transacción de IndexedDB abortada.'));
      }
      db.close();
    };
  });
}

/** Binary blobs live in their own store; project records stay lightweight. */
function stripProjectAssetBlobs(project: Project): Project {
  if (!project.mediaAssets || project.mediaAssets.length === 0) return project;
  return {
    ...project,
    mediaAssets: project.mediaAssets.map(({ fileBlob: _fileBlob, ...asset }) => asset as MediaAsset),
  };
}

export async function saveProjectToStorage(project: Project): Promise<void> {
  const storable = stripProjectAssetBlobs({
    ...project,
    schemaVersion: PROJECT_SCHEMA_VERSION,
    updatedAt: Date.now(),
  });
  await runStoreRequest(STORE_PROJECTS, 'readwrite', (store) => store.put(storable));
}

export async function getProjectFromStorage(id: string): Promise<Project | null> {
  const raw = await runStoreRequest<Project>(STORE_PROJECTS, 'readonly', (store) => store.get(id));
  if (!raw) return null;

  const project = migrateProject(raw);

  if (needsProjectMigration(raw)) {
    try {
      await saveProjectToStorage(project);
    } catch (err) {
      console.warn('No se pudo persistir la migración del proyecto:', err);
    }
  }

  return project;
}

export async function getAllProjectsFromStorage(): Promise<Project[]> {
  const rawProjects = await runStoreRequest<Project[]>(STORE_PROJECTS, 'readonly', (store) =>
    store.getAll()
  );
  return (rawProjects || []).map((raw) => migrateProject(raw));
}

export async function deleteProjectFromStorage(id: string): Promise<void> {
  const project = await runStoreRequest<Project>(STORE_PROJECTS, 'readonly', (store) => store.get(id));
  await runStoreRequest(STORE_PROJECTS, 'readwrite', (store) => store.delete(id));

  if (project?.mediaAssets?.length) {
    try {
      await deleteUnreferencedAssets(project.mediaAssets.map((asset) => asset.id));
    } catch (err) {
      console.warn('No se pudieron limpiar los medios del proyecto eliminado:', err);
    }
  }
}

export async function saveMediaAssetBlob(asset: MediaAsset): Promise<void> {
  await runStoreRequest(STORE_ASSETS, 'readwrite', (store) => store.put(asset));
}

export async function getMediaAssetBlob(id: string): Promise<MediaAsset | null> {
  const result = await runStoreRequest<MediaAsset>(STORE_ASSETS, 'readonly', (store) =>
    store.get(id)
  );
  return result || null;
}

export async function getAllMediaAssets(): Promise<MediaAsset[]> {
  const result = await runStoreRequest<MediaAsset[]>(STORE_ASSETS, 'readonly', (store) =>
    store.getAll()
  );
  return result || [];
}

export async function deleteMediaAssetBlob(id: string): Promise<void> {
  await runStoreRequest(STORE_ASSETS, 'readwrite', (store) => store.delete(id));
}

/**
 * Deletes the given asset blobs only when no stored project references them.
 * Used after deleting a project or an asset so binaries never leak.
 */
export async function deleteUnreferencedAssets(assetIds: string[]): Promise<OrphanCleanupResult> {
  if (assetIds.length === 0) return { deletedCount: 0, freedBytes: 0 };

  const projects = await getAllProjectsFromStorage();
  const referenced = new Set<string>();
  for (const project of projects) {
    for (const asset of project.mediaAssets || []) referenced.add(asset.id);
    for (const track of project.timeline?.tracks || []) {
      for (const clip of track.clips) {
        if (clip.assetId) referenced.add(clip.assetId);
      }
    }
  }

  const uniqueIds = Array.from(new Set(assetIds)).filter((id) => !referenced.has(id));
  if (uniqueIds.length === 0) return { deletedCount: 0, freedBytes: 0 };

  const assets = await getAllMediaAssets();
  const candidateMap = new Map(assets.map((asset) => [asset.id, asset]));

  let deletedCount = 0;
  let freedBytes = 0;

  for (const id of uniqueIds) {
    const asset = candidateMap.get(id);
    try {
      await deleteMediaAssetBlob(id);
      deletedCount++;
      freedBytes += asset?.sizeBytes || 0;
    } catch (err) {
      console.warn(`No se pudo eliminar el binario huérfano ${id}:`, err);
    }
  }

  return { deletedCount, freedBytes };
}

/**
 * Removes binary records no project references anymore (for example, an import
 * interrupted before the project update). Recently created assets are preserved
 * to avoid deleting a just-imported file before it is attached to the project.
 */
export async function cleanupOrphanedAssets(
  maxAgeMs: number = 10 * 60 * 1000
): Promise<OrphanCleanupResult> {
  const [projects, assets] = await Promise.all([getAllProjectsFromStorage(), getAllMediaAssets()]);

  const referenced = new Set<string>();
  for (const project of projects) {
    for (const asset of project.mediaAssets || []) referenced.add(asset.id);
    for (const track of project.timeline?.tracks || []) {
      for (const clip of track.clips) {
        if (clip.assetId) referenced.add(clip.assetId);
      }
    }
  }

  const now = Date.now();
  const orphans = assets.filter(
    (asset) => !referenced.has(asset.id) && now - (asset.createdAt || 0) > maxAgeMs
  );

  let deletedCount = 0;
  let freedBytes = 0;
  for (const asset of orphans) {
    try {
      await deleteMediaAssetBlob(asset.id);
      deletedCount++;
      freedBytes += asset.sizeBytes || 0;
    } catch (err) {
      console.warn(`No se pudo eliminar el medio huérfano ${asset.id}:`, err);
    }
  }

  return { deletedCount, freedBytes };
}

export async function setLastActiveProjectId(projectId: string): Promise<void> {
  const record: MetaRecord = { key: LAST_ACTIVE_PROJECT_KEY, value: projectId };
  await runStoreRequest(STORE_META, 'readwrite', (store) => store.put(record));
}

export async function getLastActiveProjectId(): Promise<string | null> {
  const record = await runStoreRequest<MetaRecord>(STORE_META, 'readonly', (store) =>
    store.get(LAST_ACTIVE_PROJECT_KEY)
  );
  return record && typeof record.value === 'string' ? record.value : null;
}
