// Debounced Project Autosave
// Coalesces rapid edits, retries transient IndexedDB failures and always saves
// the newest project state, so the editor never silently loses work.
import { Project } from '../../types';

export type AutosaveStatus = 'idle' | 'saving' | 'saved' | 'error';

export interface ProjectAutosaverOptions {
  save: (project: Project) => Promise<void>;
  debounceMs?: number;
  maxRetries?: number;
  retryDelayMs?: number;
  onStatus?: (status: AutosaveStatus, error?: unknown) => void;
}

export class ProjectAutosaver {
  private queuedProject: Project | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private running: Promise<void> | null = null;
  private disposed = false;
  private status: AutosaveStatus = 'idle';
  private lastError: unknown = null;

  private readonly debounceMs: number;
  private readonly maxRetries: number;
  private readonly retryDelayMs: number;

  constructor(private readonly options: ProjectAutosaverOptions) {
    this.debounceMs = options.debounceMs ?? 600;
    this.maxRetries = options.maxRetries ?? 2;
    this.retryDelayMs = options.retryDelayMs ?? 400;
  }

  public schedule(project: Project): void {
    if (this.disposed) return;
    this.queuedProject = project;
    this.clearTimer();
    this.timer = setTimeout(() => {
      this.timer = null;
      void this.flush();
    }, this.debounceMs);
  }

  /**
   * Immediately persists the newest queued state and waits for it.
   */
  public flush(): Promise<void> {
    this.clearTimer();
    if (this.running) return this.running;

    this.running = this.drain().finally(() => {
      this.running = null;
    });
    return this.running;
  }

  public getStatus(): AutosaveStatus {
    return this.status;
  }

  public getLastError(): unknown {
    return this.lastError;
  }

  /**
   * Flushes pending work and stops accepting new edits (component unmount).
   */
  public async dispose(): Promise<void> {
    this.clearTimer();
    await this.flush();
    this.disposed = true;
  }

  private clearTimer(): void {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  private async drain(): Promise<void> {
    while (this.queuedProject) {
      const project = this.queuedProject;
      this.queuedProject = null;
      this.setStatus('saving');

      let attempt = 0;
      for (;;) {
        try {
          await this.options.save(project);
          this.lastError = null;
          this.setStatus('saved');
          break;
        } catch (error) {
          attempt += 1;
          if (attempt > this.maxRetries) {
            this.lastError = error;
            this.setStatus('error', error);
            break;
          }
          await this.delay(this.retryDelayMs * Math.pow(2, attempt - 1));
        }
      }
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  private setStatus(status: AutosaveStatus, error?: unknown): void {
    this.status = status;
    this.options.onStatus?.(status, error);
  }
}
