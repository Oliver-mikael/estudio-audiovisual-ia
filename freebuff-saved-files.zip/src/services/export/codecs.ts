// Real Export Capability Detection
// Only formats the running browser can actually record are offered as
// supported. MOV/HEVC/AV1 are listed as experimental and stay disabled unless
// MediaRecorder reports them, so the UI never promises a container the engine
// cannot produce.
export type ContainerId = 'mp4' | 'webm' | 'mov';
export type VideoCodecId = 'h264' | 'hevc' | 'vp9' | 'vp8' | 'av1';
export type AudioCodecId = 'aac' | 'opus';

export interface ExportFormat {
  id: string;
  label: string;
  container: ContainerId;
  extension: 'mp4' | 'webm' | 'mov';
  videoCodec: VideoCodecId;
  audioCodec: AudioCodecId;
  /** Mime type with audio; `videoOnlyMimeType` is used when audio is disabled. */
  mimeType: string;
  videoOnlyMimeType: string;
  /** `preferred` is the publishing default, `alternative` a working fallback. */
  tier: 'preferred' | 'alternative' | 'experimental';
  notes: string;
}

export const EXPORT_FORMATS: ExportFormat[] = [
  {
    id: 'mp4-h264-aac',
    label: 'MP4 · H.264 + AAC',
    container: 'mp4',
    extension: 'mp4',
    videoCodec: 'h264',
    audioCodec: 'aac',
    mimeType: 'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    videoOnlyMimeType: 'video/mp4;codecs=avc1.42E01E',
    tier: 'preferred',
    notes: 'Máxima compatibilidad con reproductores, móviles y plataformas.',
  },
  {
    id: 'webm-vp9-opus',
    label: 'WebM · VP9 + Opus',
    container: 'webm',
    extension: 'webm',
    videoCodec: 'vp9',
    audioCodec: 'opus',
    mimeType: 'video/webm;codecs=vp9,opus',
    videoOnlyMimeType: 'video/webm;codecs=vp9',
    tier: 'alternative',
    notes: 'Alternativa abierta con buena compresión; no se reproduce en algunos iOS.',
  },
  {
    id: 'webm-vp8-opus',
    label: 'WebM · VP8 + Opus',
    container: 'webm',
    extension: 'webm',
    videoCodec: 'vp8',
    audioCodec: 'opus',
    mimeType: 'video/webm;codecs=vp8,opus',
    videoOnlyMimeType: 'video/webm;codecs=vp8',
    tier: 'alternative',
    notes: 'Codificador más ligero en CPU para equipos modestos.',
  },
  {
    id: 'webm-av1-opus',
    label: 'WebM · AV1 + Opus',
    container: 'webm',
    extension: 'webm',
    videoCodec: 'av1',
    audioCodec: 'opus',
    mimeType: 'video/webm;codecs=av01.0.05M.08,opus',
    videoOnlyMimeType: 'video/webm;codecs=av01.0.05M.08',
    tier: 'experimental',
    notes: 'Solo se habilita si el navegador expone un codificador AV1 en MediaRecorder.',
  },
  {
    id: 'mp4-hevc-aac',
    label: 'MP4 · HEVC (H.265) + AAC',
    container: 'mp4',
    extension: 'mp4',
    videoCodec: 'hevc',
    audioCodec: 'aac',
    mimeType: 'video/mp4;codecs=hvc1.1.6.L93.B0,mp4a.40.2',
    videoOnlyMimeType: 'video/mp4;codecs=hvc1.1.6.L93.B0',
    tier: 'experimental',
    notes: 'Depende del soporte HEVC del dispositivo; sin él no aparece como opción.',
  },
  {
    id: 'mov-h264-aac',
    label: 'MOV · H.264 + AAC',
    container: 'mov',
    extension: 'mov',
    videoCodec: 'h264',
    audioCodec: 'aac',
    mimeType: 'video/quicktime;codecs=avc1.42E01E,mp4a.40.2',
    videoOnlyMimeType: 'video/quicktime;codecs=avc1.42E01E',
    tier: 'experimental',
    notes: 'Contenedor QuickTime: casi ningún navegador lo graba; se lista para extensibilidad.',
  },
];

export interface ConstructionProbe {
  ok: boolean;
  /** Mime type the recorder normalized to (may drop or change codecs). */
  actualMime: string;
}

const constructionCache = new Map<string, ConstructionProbe>();

function parseCodecs(mime: string): string[] {
  const match = /codecs=([^;]+)/i.exec(mime);
  if (!match) return [];
  return match[1]
    .toLowerCase()
    .split(',')
    .map((codec) => codec.trim())
    .filter(Boolean);
}

function codecMatches(requested: string, actual: string): boolean {
  if (requested === actual) return true;
  // avc1 profile strings are often shortened/expanded by the platform.
  if (requested.startsWith('avc1') && actual.startsWith('avc1')) return true;
  if (requested.startsWith('hvc1') && actual.startsWith('hvc1')) return true;
  if (requested.startsWith('av01') && actual.startsWith('av01')) return true;
  return false;
}

/**
 * `isTypeSupported` can return true for a codec string that MediaRecorder then
 * refuses to construct, and Chromium may accept `video/mp4` while recording
 * VP9/Opus. This probe builds a disposable recorder over a tiny canvas plus a
 * silent audio track, keeps the normalized mime type and requires the requested
 * codecs to match; otherwise the format is reported as unavailable.
 */
export function probeMediaRecorderConstruction(mime: string): ConstructionProbe {
  const cached = constructionCache.get(mime);
  if (cached) return cached;
  if (typeof document === 'undefined' || typeof MediaRecorder === 'undefined') {
    const unavailable = { ok: false, actualMime: '' };
    constructionCache.set(mime, unavailable);
    return unavailable;
  }

  let stream: MediaStream | null = null;
  let audioContext: AudioContext | null = null;
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 32;
    canvas.height = 32;
    stream = canvas.captureStream(1);

    const Ctor = window.AudioContext;
    if (Ctor) {
      audioContext = new Ctor();
      const destination = audioContext.createMediaStreamDestination();
      const audioTrack = destination.stream.getAudioTracks()[0];
      if (audioTrack) stream.addTrack(audioTrack);
    }

    const recorder = new MediaRecorder(stream, { mimeType: mime });
    const actualMime = recorder.mimeType || mime;
    const requestedContainer = mime.split(';')[0].toLowerCase();
    const actualContainer = actualMime.split(';')[0].toLowerCase();
    const requestedCodecs = parseCodecs(mime);
    const actualCodecs = parseCodecs(actualMime);
    const containerOk = actualContainer === requestedContainer;
    const codecsOk =
      requestedCodecs.length === 0 ||
      requestedCodecs.every((requested) =>
        actualCodecs.some((actual) => codecMatches(requested, actual))
      );

    const result = { ok: containerOk && codecsOk, actualMime };
    constructionCache.set(mime, result);
    return result;
  } catch {
    const failed = { ok: false, actualMime: '' };
    constructionCache.set(mime, failed);
    return failed;
  } finally {
    stream?.getTracks().forEach((track) => track.stop());
    audioContext?.close().catch(() => undefined);
  }
}

export function canConstructMediaRecorder(mime: string): boolean {
  return probeMediaRecorderConstruction(mime).ok;
}

export interface ExportFormatCapability {
  format: ExportFormat;
  /** Either variant can be recorded. */
  supported: boolean;
  /** The mime type including audio really constructs with matching codecs. */
  audioSupported: boolean;
  /** The video-only mime type really constructs with matching codecs. */
  videoOnlySupported: boolean;
}

export interface ExportCapabilities {
  mediaRecorder: boolean;
  canvasCapture: boolean;
  audioContext: boolean;
  formats: ExportFormatCapability[];
  supportedFormatIds: string[];
  preferredFormatId: string | null;
  detectedAt: number;
}

const PREFERENCE_ORDER = ['mp4-h264-aac', 'webm-vp9-opus', 'webm-vp8-opus', 'webm-av1-opus'];

export function listSupportedMimeTypes(isSupported: (mime: string) => boolean): string[] {
  return EXPORT_FORMATS.filter(
    (format) => isSupported(format.mimeType) || isSupported(format.videoOnlyMimeType)
  ).map((format) => format.id);
}

/**
 * Probes MediaRecorder, canvas.captureStream and AudioContext. Every format is
 * verified with `MediaRecorder.isTypeSupported`; nothing is assumed.
 */
export function detectExportCapabilities(
  isTypeSupported?: (mime: string) => boolean
): ExportCapabilities {
  // An explicit probe means the caller is injecting the environment (tests, or a
  // platform adapter); otherwise the real MediaRecorder must exist.
  const hasRecorder = isTypeSupported
    ? true
    : typeof MediaRecorder !== 'undefined' && typeof MediaRecorder.isTypeSupported === 'function';
  const hasCanvasCapture =
    typeof document !== 'undefined' &&
    typeof document.createElement === 'function' &&
    typeof HTMLCanvasElement !== 'undefined' &&
    typeof HTMLCanvasElement.prototype.captureStream === 'function';
  const hasAudioContext =
    typeof AudioContext !== 'undefined' || typeof (globalThis as { webkitAudioContext?: unknown }).webkitAudioContext !== 'undefined';

  const probe =
    isTypeSupported ??
    (hasRecorder
      ? (mime: string) => {
          try {
            return MediaRecorder.isTypeSupported(mime);
          } catch {
            return false;
          }
        }
      : () => false);

  const verify = (mime: string): boolean => {
    if (!probe(mime)) return false;
    // Injected probes (tests/platform adapters) skip the DOM construction probe.
    return isTypeSupported ? true : canConstructMediaRecorder(mime);
  };

  const formats = EXPORT_FORMATS.map((format) => {
    const audioSupported = hasRecorder && verify(format.mimeType);
    const videoOnlySupported = hasRecorder && verify(format.videoOnlyMimeType);
    return {
      format,
      audioSupported,
      videoOnlySupported,
      supported: audioSupported || videoOnlySupported,
    };
  });

  const supportedFormatIds = formats.filter((entry) => entry.supported).map((entry) => entry.format.id);
  // Preferred means "works with the audio mix", which is what exports request.
  const audioFormatIds = formats.filter((entry) => entry.audioSupported).map((entry) => entry.format.id);
  const preferredFormatId =
    PREFERENCE_ORDER.find((id) => audioFormatIds.includes(id)) ??
    PREFERENCE_ORDER.find((id) => supportedFormatIds.includes(id)) ??
    supportedFormatIds[0] ??
    null;

  return {
    mediaRecorder: hasRecorder,
    canvasCapture: hasCanvasCapture,
    audioContext: hasAudioContext,
    formats,
    supportedFormatIds,
    preferredFormatId,
    detectedAt: Date.now(),
  };
}

export interface FormatResolution {
  format: ExportFormat | null;
  requestedContainer: 'auto' | 'mp4' | 'webm';
  fellBack: boolean;
  reason?: string;
}

/**
 * Resolves the container the engine will really produce. A request for MP4 on a
 * browser without an MP4 encoder returns the WebM fallback explicitly (never as
 * if it were MP4), and `fellBack` lets the UI ask before starting.
 */
export function resolveExportFormat(
  preference: 'auto' | 'mp4' | 'webm',
  capabilities: ExportCapabilities,
  includeAudio: boolean
): FormatResolution {
  const usable = capabilities.formats.filter((entry) =>
    includeAudio ? entry.audioSupported : entry.supported
  );
  if (usable.length === 0) {
    return {
      format: null,
      requestedContainer: preference,
      fellBack: false,
      reason: 'Este navegador no expone ningún codificador de video utilizable.',
    };
  }


  if (preference === 'auto') {
    const best =
      usable.find((entry) => entry.format.id === capabilities.preferredFormatId) ?? usable[0];
    return { format: best.format, requestedContainer: 'auto', fellBack: false };
  }

  const exact = usable.find((entry) => entry.format.container === preference);
  if (exact) {
    return { format: exact.format, requestedContainer: preference, fellBack: false };
  }

  const fallback =
    usable.find((entry) => entry.format.id === capabilities.preferredFormatId) ?? usable[0];
  return {
    format: fallback.format,
    requestedContainer: preference,
    fellBack: true,
    reason: `Este navegador no puede grabar ${preference.toUpperCase()}. Se usará ${
      fallback.format.label
    }.`,
  };
}

export function getExportFormat(id: string): ExportFormat | null {
  return EXPORT_FORMATS.find((format) => format.id === id) ?? null;
}

export function getMimeTypeForFormat(format: ExportFormat, includeAudio: boolean): string {
  return includeAudio ? format.mimeType : format.videoOnlyMimeType;
}

/**
 * Real frame-rate probe: asks a canvas capture stream which frame rate the
 * platform actually grants. Returns false when the browser cannot tell.
 */
export function probeFrameRateSupport(width: number, height: number, fps: number): boolean {
  if (typeof document === 'undefined' || typeof HTMLCanvasElement === 'undefined') return false;
  if (typeof HTMLCanvasElement.prototype.captureStream !== 'function') return false;
  try {
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(16, Math.round(width));
    canvas.height = Math.max(16, Math.round(height));
    const stream = canvas.captureStream(fps);
    const track = stream.getVideoTracks()[0];
    const settings = track?.getSettings?.() ?? {};
    stream.getTracks().forEach((videoTrack) => videoTrack.stop());
    const granted = Number(settings.frameRate);
    if (!Number.isFinite(granted) || granted <= 0) return false;
    return Math.abs(granted - fps) <= Math.max(1, fps * 0.1);
  } catch {
    return false;
  }
}

export async function getAvailableStorageBytes(): Promise<number | null> {
  if (typeof navigator === 'undefined' || !navigator.storage?.estimate) return null;
  try {
    const estimate = await navigator.storage.estimate();
    if (!estimate.quota) return null;
    return Math.max(0, estimate.quota - (estimate.usage ?? 0));
  } catch {
    return null;
  }
}

export function getDeviceMemoryGb(): number | null {
  const memory = (navigator as unknown as { deviceMemory?: number })?.deviceMemory;
  return typeof memory === 'number' && memory > 0 ? memory : null;
}
