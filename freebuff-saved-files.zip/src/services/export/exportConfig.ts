// Export Configuration Domain
// Resolution tiers, aspect ratios, frame rates, quality/bitrate policy, size
// estimation and risk assessment for a real client-side export. Pure functions
// only: no DOM access, so they can be unit-tested and reused by the UI.
import { Project, ProjectAspectRatio, VideoFitMode } from '../../types';

/** Aspect ratios the editor can render. `4:5` is kept for legacy projects. */
export const EXPORT_ASPECT_RATIOS: ProjectAspectRatio[] = ['16:9', '9:16', '1:1', '4:3', '4:5'];

export const ASPECT_RATIO_LABELS: Record<ProjectAspectRatio, string> = {
  '16:9': '16:9 Horizontal',
  '9:16': '9:16 Vertical',
  '1:1': '1:1 Cuadrado',
  '4:3': '4:3 Clásico',
  '4:5': '4:5 Retrato',
};

export const ASPECT_RATIO_VALUES: Record<ProjectAspectRatio, number> = {
  '16:9': 16 / 9,
  '9:16': 9 / 16,
  '1:1': 1,
  '4:3': 4 / 3,
  '4:5': 4 / 5,
};

export const FIT_MODE_LABELS: Record<VideoFitMode, string> = {
  fit: 'Ajustar (barras)',
  fill: 'Rellenar (recorta bordes)',
  crop: 'Recortar al encuadre',
  stretch: 'Estirar (deforma)',
};

export interface ResolutionTierDefinition {
  id: ResolutionTier;
  label: string;
  /** Short side in pixels; the long side follows the aspect ratio. */
  shortSide: number;
}

export type ResolutionTier = '360p' | '480p' | '720p' | '1080p' | '1440p' | '2160p';

export const RESOLUTION_TIERS: ResolutionTierDefinition[] = [
  { id: '360p', label: '360p (SD ligero)', shortSide: 360 },
  { id: '480p', label: '480p (SD)', shortSide: 480 },
  { id: '720p', label: '720p (HD)', shortSide: 720 },
  { id: '1080p', label: '1080p (Full HD)', shortSide: 1080 },
  { id: '1440p', label: '1440p (QHD)', shortSide: 1440 },
  { id: '2160p', label: '2160p (4K UHD)', shortSide: 2160 },
];

export function getResolutionTier(tier: ResolutionTier): ResolutionTierDefinition {
  return RESOLUTION_TIERS.find((entry) => entry.id === tier) ?? RESOLUTION_TIERS[2];
}

/** Video encoders need even dimensions; keep both sides positive and even. */
function evenDimension(value: number): number {
  return Math.max(2, Math.round(value / 2) * 2);
}

/**
 * Frame size for a tier and aspect ratio. The tier is the short side, so a 9:16
 * 1080p export is 1080x1920 instead of pretending to be 1920x1080.
 */
export function computeResolution(
  tier: ResolutionTier,
  aspectRatio: ProjectAspectRatio
): { width: number; height: number } {
  const shortSide = getResolutionTier(tier).shortSide;
  const ratio = ASPECT_RATIO_VALUES[aspectRatio] ?? 16 / 9;

  if (ratio > 1.0001) {
    return { width: evenDimension(shortSide * ratio), height: evenDimension(shortSide) };
  }
  if (ratio < 0.9999) {
    return { width: evenDimension(shortSide), height: evenDimension(shortSide / ratio) };
  }
  return { width: evenDimension(shortSide), height: evenDimension(shortSide) };
}

export const FPS_OPTIONS = [24, 25, 30, 50, 60] as const;

export type SupportedFps = (typeof FPS_OPTIONS)[number];

export function isKnownFps(fps: number): boolean {
  return (FPS_OPTIONS as readonly number[]).includes(fps);
}

export type ExportQuality = 'economic' | 'standard' | 'high' | 'maximum';

export interface QualityPreset {
  id: ExportQuality;
  label: string;
  /** Bits per pixel per frame; converted to a bitrate for the target frame size. */
  bitsPerPixelPerFrame: number;
  description: string;
}

export const QUALITY_PRESETS: QualityPreset[] = [
  {
    id: 'economic',
    label: 'Económica',
    bitsPerPixelPerFrame: 0.05,
    description: 'Archivos pequeños para borradores y revisiones rápidas.',
  },
  {
    id: 'standard',
    label: 'Estándar',
    bitsPerPixelPerFrame: 0.085,
    description: 'Equilibrio entre tamaño, memoria y calidad para redes sociales.',
  },
  {
    id: 'high',
    label: 'Alta',
    bitsPerPixelPerFrame: 0.13,
    description: 'Calidad de publicación para YouTube y presentaciones.',
  },
  {
    id: 'maximum',
    label: 'Máxima',
    bitsPerPixelPerFrame: 0.2,
    description: 'Máximo detalle; el archivo y la memoria crecen rápido.',
  },
];

/** Hard encoder limits: below this the picture breaks up, above it is wasteful. */
export const MIN_VIDEO_BITRATE_BPS = 250_000;
export const MAX_VIDEO_BITRATE_BPS = 80_000_000;

export function getQualityPreset(quality: ExportQuality): QualityPreset {
  return QUALITY_PRESETS.find((preset) => preset.id === quality) ?? QUALITY_PRESETS[1];
}

/** Automatic video bitrate for a frame size, frame rate and quality preset. */
export function estimateVideoBitrateBps(params: {
  width: number;
  height: number;
  fps: number;
  quality: ExportQuality;
}): number {
  const { width, height, fps, quality } = params;
  const safeFps = Math.max(1, Math.round(fps));
  const pixelsPerSecond = Math.max(1, width) * Math.max(1, height) * safeFps;
  const raw = pixelsPerSecond * getQualityPreset(quality).bitsPerPixelPerFrame;
  return Math.round(Math.max(MIN_VIDEO_BITRATE_BPS, Math.min(MAX_VIDEO_BITRATE_BPS, raw)));
}

export function clampCustomBitrate(bitrateBps: number): number {
  return Math.round(
    Math.max(MIN_VIDEO_BITRATE_BPS, Math.min(MAX_VIDEO_BITRATE_BPS, bitrateBps))
  );
}

export type AudioQualityId = 'low' | 'standard' | 'high' | 'maximum';

export interface AudioQualityPreset {
  id: AudioQualityId;
  label: string;
  bitrateBps: number;
}

export const AUDIO_QUALITY_PRESETS: AudioQualityPreset[] = [
  { id: 'low', label: 'Baja · 96 kbps', bitrateBps: 96_000 },
  { id: 'standard', label: 'Estándar · 128 kbps', bitrateBps: 128_000 },
  { id: 'high', label: 'Alta · 192 kbps', bitrateBps: 192_000 },
  { id: 'maximum', label: 'Máxima · 256 kbps', bitrateBps: 256_000 },
];

export function getAudioQualityPreset(quality: AudioQualityId): AudioQualityPreset {
  return AUDIO_QUALITY_PRESETS.find((preset) => preset.id === quality) ?? AUDIO_QUALITY_PRESETS[1];
}

/** Container overhead (headers, cluster/index metadata) as a fraction of payload. */
const CONTAINER_OVERHEAD_RATIO = 0.02;

export function estimateExportBytes(params: {
  durationSeconds: number;
  videoBitrateBps: number;
  audioBitrateBps: number;
}): number {
  const duration = Math.max(0, params.durationSeconds);
  const payload = ((params.videoBitrateBps + Math.max(0, params.audioBitrateBps)) * duration) / 8;
  return Math.round(payload * (1 + CONTAINER_OVERHEAD_RATIO));
}

export interface ExportWarning {
  level: 'info' | 'warning' | 'danger';
  code: string;
  message: string;
}

export interface ExportRiskInput {
  estimatedBytes: number;
  durationSeconds: number;
  width: number;
  height: number;
  fps: number;
  /** Bytes available for the export, when the browser can report them. */
  availableBytes?: number | null;
  /** navigator.deviceMemory, when available. */
  deviceMemoryGb?: number | null;
}

/** Threshold above which a single Blob in RAM is risky on mobile WebViews. */
export const LARGE_ESTIMATE_BYTES = 400 * 1024 * 1024;
/** Recording happens in memory, so keep a safety margin over the estimate. */
const SPACE_SAFETY_FACTOR = 1.25;

/**
 * Honest pre-flight risks: memory, free space, resolution and duration. These
 * are the conditions that make an export fail halfway and lose the render.
 */
export function assessExportRisk(input: ExportRiskInput): ExportWarning[] {
  const warnings: ExportWarning[] = [];
  const megapixels = (input.width * input.height) / 1_000_000;

  if (input.estimatedBytes > LARGE_ESTIMATE_BYTES) {
    warnings.push({
      level: 'danger',
      code: 'large-estimate',
      message: `La estimación (~${formatBytes(input.estimatedBytes)}) supera ${formatBytes(
        LARGE_ESTIMATE_BYTES
      )}. El archivo se graba en memoria: en móviles puede cerrar la app.`,
    });
  } else if (input.estimatedBytes > 150 * 1024 * 1024) {
    warnings.push({
      level: 'warning',
      code: 'big-estimate',
      message: `La estimación (~${formatBytes(input.estimatedBytes)}) es grande para grabarse en RAM.`,
    });
  }

  if (input.availableBytes !== null && input.availableBytes !== undefined) {
    const needed = input.estimatedBytes * SPACE_SAFETY_FACTOR;
    if (input.availableBytes < needed) {
      warnings.push({
        level: 'danger',
        code: 'insufficient-space',
        message: `Espacio insuficiente: hay ${formatBytes(
          input.availableBytes
        )} disponibles y el render necesita ~${formatBytes(needed)}.`,
      });
    } else if (input.availableBytes < needed * 1.5) {
      warnings.push({
        level: 'warning',
        code: 'tight-space',
        message: `Quedará poco espacio: ${formatBytes(input.availableBytes)} disponibles para ~${formatBytes(
          needed
        )}.`,
      });
    }
  }

  if (megapixels >= 8.2 && (input.deviceMemoryGb ?? 8) <= 4) {
    warnings.push({
      level: 'warning',
      code: 'low-memory-4k',
      message: '4K con poca memoria del dispositivo: reduce a 1080p/1440p si la exportación falla.',
    });
  }

  if (input.fps > 30) {
    warnings.push({
      level: 'info',
      code: 'high-fps',
      message: `${input.fps} FPS duplica el trabajo de render por segundo; la exportación tardará más.`,
    });
  }

  if (input.durationSeconds > 600) {
    warnings.push({
      level: 'warning',
      code: 'long-export',
      message: `Duración larga (${(input.durationSeconds / 60).toFixed(
        1
      )} min): mantén la app abierta; el sistema puede suspender el proceso.`,
    });
  }

  return warnings;
}

export function hasBlockingWarning(warnings: ExportWarning[]): boolean {
  return warnings.some((warning) => warning.level === 'danger');
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  const decimals = value >= 100 || unit === 0 ? 0 : value >= 10 ? 1 : 2;
  return `${value.toFixed(decimals)} ${units[unit]}`;
}

export interface ProjectFormat {
  resolution: { width: number; height: number };
  fps: number;
  aspectRatio: ProjectAspectRatio;
}

export function getProjectFormat(project: Project): ProjectFormat {
  return {
    resolution: { ...project.settings.resolution },
    fps: Math.max(1, Math.round(project.settings.fps || 30)),
    aspectRatio: project.settings.aspectRatio ?? '16:9',
  };
}

/**
 * Changes the project's format without touching the edit: the timeline, clip
 * offsets, keyframes and assets are kept byte-for-byte (only settings change),
 * so switching 16:9 <-> 9:16 never re-cuts the work.
 */
export function changeProjectFormat(project: Project, format: ProjectFormat): Project {
  const width = Math.max(16, Math.round(format.resolution.width));
  const height = Math.max(16, Math.round(format.resolution.height));
  const fps = Math.max(1, Math.min(120, Math.round(format.fps)));
  const aspectRatio = EXPORT_ASPECT_RATIOS.includes(format.aspectRatio)
    ? format.aspectRatio
    : project.settings.aspectRatio;

  return {
    ...project,
    settings: {
      ...project.settings,
      fps,
      resolution: { width, height },
      aspectRatio,
    },
    updatedAt: Date.now(),
  };
}

/**
 * Infers the closest resolution tier and aspect for a project format, used to
 * seed the export dialog from the project without forcing its exact size.
 */
export function inferExportAspect(project: Project): ProjectAspectRatio {
  const ratio = project.settings.resolution.width / Math.max(1, project.settings.resolution.height);
  let best: ProjectAspectRatio = '16:9';
  let bestDelta = Number.POSITIVE_INFINITY;
  for (const aspect of EXPORT_ASPECT_RATIOS) {
    const delta = Math.abs(ASPECT_RATIO_VALUES[aspect] - ratio);
    if (delta < bestDelta) {
      bestDelta = delta;
      best = aspect;
    }
  }
  return best;
}

export function inferResolutionTier(project: Project): ResolutionTier {
  const shortSide = Math.min(project.settings.resolution.width, project.settings.resolution.height);
  let best: ResolutionTier = '720p';
  let bestDelta = Number.POSITIVE_INFINITY;
  for (const tier of RESOLUTION_TIERS) {
    const delta = Math.abs(tier.shortSide - shortSide);
    if (delta < bestDelta) {
      bestDelta = delta;
      best = tier.id;
    }
  }
  return best;
}
