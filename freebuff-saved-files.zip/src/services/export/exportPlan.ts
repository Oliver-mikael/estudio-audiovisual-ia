// Export Plan Builder
// Turns user-facing export settings plus detected capabilities into the exact
// numbers the exporter will use: frame size, fps, bitrates, container/mime,
// composition (fit mode + framing) and pre-flight warnings.
import { Project, ProjectAspectRatio, VideoFitMode } from '../../types';
import {
  assessExportRisk,
  computeResolution,
  estimateExportBytes,
  estimateVideoBitrateBps,
  clampCustomBitrate,
  getAudioQualityPreset,
  inferExportAspect,
  inferResolutionTier,
  type AudioQualityId,
  type ExportQuality,
  type ExportWarning,
  type ResolutionTier,
} from './exportConfig';
import {
  getMimeTypeForFormat,
  resolveExportFormat,
  type ExportCapabilities,
  type ExportFormat,
} from './codecs';

export interface ExportSettings {
  resolutionTier: ResolutionTier;
  aspectRatio: ProjectAspectRatio;
  fps: number;
  formatPreference: 'auto' | 'mp4' | 'webm';
  quality: ExportQuality;
  /** When set and valid, overrides the automatic bitrate. */
  customBitrateBps?: number | null;
  audioQuality: AudioQualityId;
  includeAudio: boolean;
  fitMode: VideoFitMode;
  /** 0..1 focus point used to reframe the picture (0.5 = center). */
  framing: { x: number; y: number };
}

export function createExportSettingsFromProject(project: Project): ExportSettings {
  return {
    resolutionTier: inferResolutionTier(project),
    aspectRatio: inferExportAspect(project),
    fps: project.settings.fps || 30,
    formatPreference: 'auto',
    quality: 'standard',
    customBitrateBps: null,
    audioQuality: 'standard',
    includeAudio: true,
    fitMode: 'fill',
    framing: { x: 0.5, y: 0.5 },
  };
}

export interface ExportPlan {
  width: number;
  height: number;
  fps: number;
  videoBitrateBps: number;
  audioBitrateBps: number;
  estimatedBytes: number;
  format: ExportFormat;
  mimeType: string;
  extension: 'mp4' | 'webm' | 'mov';
  composition: { fitMode: VideoFitMode; framing: { x: number; y: number } };
  warnings: ExportWarning[];
  formatFellBack: boolean;
  formatNote?: string;
}

export interface BuildExportPlanParams {
  settings: ExportSettings;
  durationSeconds: number;
  capabilities: ExportCapabilities;
  availableBytes?: number | null;
  deviceMemoryGb?: number | null;
}

export type ExportPlanResult = { ok: true; plan: ExportPlan } | { ok: false; error: string };

function clampFraming(value: number): number {
  if (!Number.isFinite(value)) return 0.5;
  return Math.min(1, Math.max(0, value));
}

/**
 * Builds the export plan or explains why it cannot run. A requested container
 * that the browser cannot record is reported as a fallback (`formatFellBack`),
 * and the UI must surface it before starting.
 */
export function buildExportPlan(params: BuildExportPlanParams): ExportPlanResult {
  const { settings, durationSeconds, capabilities } = params;

  if (durationSeconds <= 0) {
    return { ok: false, error: 'El timeline está vacío: agrega clips antes de exportar.' };
  }

  if (!capabilities.supportedFormatIds.length) {
    return {
      ok: false,
      error:
        'Este navegador no puede grabar video (MediaRecorder sin codificadores). Usa Chrome, Edge o Firefox actualizados.',
    };
  }

  const resolution = computeResolution(settings.resolutionTier, settings.aspectRatio);
  const fps = Math.max(1, Math.min(120, Math.round(settings.fps)));

  const resolutionFormat = resolveExportFormat(
    settings.formatPreference,
    capabilities,
    settings.includeAudio
  );
  if (!resolutionFormat.format) {
    return { ok: false, error: resolutionFormat.reason ?? 'No hay formato de salida disponible.' };
  }

  const autoBitrate = estimateVideoBitrateBps({
    width: resolution.width,
    height: resolution.height,
    fps,
    quality: settings.quality,
  });
  const videoBitrateBps =
    settings.customBitrateBps && settings.customBitrateBps > 0
      ? clampCustomBitrate(settings.customBitrateBps)
      : autoBitrate;

  const audioBitrateBps = settings.includeAudio
    ? getAudioQualityPreset(settings.audioQuality).bitrateBps
    : 0;

  const estimatedBytes = estimateExportBytes({
    durationSeconds,
    videoBitrateBps,
    audioBitrateBps,
  });

  const warnings = assessExportRisk({
    estimatedBytes,
    durationSeconds,
    width: resolution.width,
    height: resolution.height,
    fps,
    availableBytes: params.availableBytes,
    deviceMemoryGb: params.deviceMemoryGb,
  });

  if (resolutionFormat.fellBack && resolutionFormat.reason) {
    warnings.push({
      level: 'warning',
      code: 'container-fallback',
      message: resolutionFormat.reason,
    });
  }

  if (fps > 30) {
    const heavy = resolution.width >= 2560 || resolution.height >= 2560;
    if (heavy) {
      warnings.push({
        level: 'warning',
        code: 'heavy-combination',
        message: `${resolution.width}x${resolution.height} a ${fps} FPS exige mucha CPU; el render puede ir por debajo del tiempo real.`,
      });
    }
  }

  return {
    ok: true,
    plan: {
      width: resolution.width,
      height: resolution.height,
      fps,
      videoBitrateBps,
      audioBitrateBps,
      estimatedBytes,
      format: resolutionFormat.format,
      mimeType: getMimeTypeForFormat(resolutionFormat.format, settings.includeAudio),
      extension: resolutionFormat.format.extension,
      composition: {
        fitMode: settings.fitMode,
        framing: { x: clampFraming(settings.framing.x), y: clampFraming(settings.framing.y) },
      },
      warnings,
      formatFellBack: resolutionFormat.fellBack,
      formatNote: resolutionFormat.reason,
    },
  };
}

/** Short human summary shown before and after the export. */
export function describeExportPlan(plan: ExportPlan): string {
  return `${plan.width}x${plan.height} · ${plan.fps} FPS · ${plan.format.label}`;
}
