// Cloud Settings (non-secret configuration only)
// Provider selection, Google OAuth client ID and WebDAV endpoint/account are
// stored locally. Tokens and passwords are never written to project files,
// never logged, and never sent anywhere except the provider's own API.

export type CloudProviderChoice = 'none' | 'google-drive' | 'webdav';

export interface GoogleDriveConfig {
  clientId: string;
  folderName: string;
}

export interface WebDavConfig {
  baseUrl: string;
  username: string;
  folderName: string;
}

const PROVIDER_KEY = 'estudio_cloud_provider';
const GDRIVE_KEY = 'estudio_gdrive_client_id';
const GDRIVE_FOLDER_KEY = 'estudio_gdrive_folder';
const WEBDAV_URL_KEY = 'estudio_webdav_url';
const WEBDAV_USER_KEY = 'estudio_webdav_user';

function read(key: string): string {
  try {
    if (typeof localStorage === 'undefined') return '';
    return localStorage.getItem(key) ?? '';
  } catch {
    return '';
  }
}

function write(key: string, value: string): void {
  try {
    if (typeof localStorage === 'undefined') return;
    if (value) localStorage.setItem(key, value);
    else localStorage.removeItem(key);
  } catch {
    /* Private mode: configuration stays in memory for this session. */
  }
}

export function getCloudProviderChoice(): CloudProviderChoice {
  const value = read(PROVIDER_KEY);
  return value === 'google-drive' || value === 'webdav' ? value : 'none';
}

export function setCloudProviderChoice(choice: CloudProviderChoice): void {
  write(PROVIDER_KEY, choice === 'none' ? '' : choice);
}

export function getGoogleDriveConfig(): GoogleDriveConfig {
  return {
    clientId: read(GDRIVE_KEY),
    folderName: read(GDRIVE_FOLDER_KEY) || 'Estudio Audiovisual',
  };
}

export function setGoogleDriveConfig(config: Partial<GoogleDriveConfig>): void {
  if (config.clientId !== undefined) write(GDRIVE_KEY, config.clientId.trim());
  if (config.folderName !== undefined) write(GDRIVE_FOLDER_KEY, config.folderName.trim());
}

export function getWebDavConfig(): WebDavConfig {
  return {
    baseUrl: read(WEBDAV_URL_KEY),
    username: read(WEBDAV_USER_KEY),
    folderName: 'EstudioAudiovisual',
  };
}

export function setWebDavConfig(config: Partial<WebDavConfig>): void {
  if (config.baseUrl !== undefined) write(WEBDAV_URL_KEY, config.baseUrl.trim());
  if (config.username !== undefined) write(WEBDAV_USER_KEY, config.username.trim());
}

/**
 * The WebDAV password is kept in sessionStorage only: it disappears when the
 * tab closes instead of staying in the WebView's persistent storage.
 */
const WEBDAV_PASSWORD_KEY = 'estudio_webdav_password';

export function getWebDavPassword(): string {
  try {
    return sessionStorage.getItem(WEBDAV_PASSWORD_KEY) ?? '';
  } catch {
    return '';
  }
}

export function setWebDavPassword(password: string): void {
  try {
    if (password) sessionStorage.setItem(WEBDAV_PASSWORD_KEY, password);
    else sessionStorage.removeItem(WEBDAV_PASSWORD_KEY);
  } catch {
    /* Session storage unavailable. */
  }
}
