// Cloud Provider Contracts
// Local-first backups are uploaded through a provider that must expose real
// quota, integrity and (when supported) resumable uploads. Nothing here pretends
// a feature the provider does not offer: `supportsResume` and `limitations`
// are part of the contract and are shown in the UI.
export type CloudProviderId = 'google-drive' | 'webdav';

export interface CloudQuota {
  usedBytes: number;
  /** null when the provider does not report a total (WebDAV without RFC 4331). */
  totalBytes: number | null;
}

export interface CloudStatus {
  providerId: CloudProviderId;
  configured: boolean;
  connected: boolean;
  accountLabel?: string;
  quota?: CloudQuota;
  detail?: string;
  lastError?: string;
}

export interface RemoteFile {
  id: string;
  name: string;
  sizeBytes: number;
  modifiedAt: number;
  /** MD5 reported by the provider, used to verify uploaded content. */
  checksum?: string;
}

export interface UploadSession {
  sessionUri: string;
  sentBytes: number;
  totalBytes: number;
}

export interface UploadRequest {
  name: string;
  data: Blob;
  folderId?: string;
  signal?: AbortSignal;
  onProgress?: (sentBytes: number, totalBytes: number) => void;
  /** Called after each chunk so the caller can persist a resumable session. */
  onSession?: (session: UploadSession) => void;
  /** Continue a previously started upload. */
  session?: UploadSession;
}

export interface CloudProvider {
  readonly id: CloudProviderId;
  readonly label: string;
  /** Human-readable limits, verified against the provider documentation. */
  readonly limitations: string[];
  readonly supportsResume: boolean;

  isConfigured(): boolean;
  connect(): Promise<CloudStatus>;
  disconnect(): void;
  getStatus(): Promise<CloudStatus>;

  ensureFolder(name: string): Promise<string>;
  list(folderId: string): Promise<RemoteFile[]>;
  upload(request: UploadRequest): Promise<RemoteFile>;
  download(fileId: string): Promise<Blob>;
  remove(fileId: string): Promise<void>;
}

/** Thrown when the user must visit an authorization URL before continuing. */
export class CloudAuthRequiredError extends Error {
  constructor(
    message: string,
    public readonly authorizationUrl: string | null
  ) {
    super(message);
    this.name = 'CloudAuthRequiredError';
  }
}

export function isAbortError(error: unknown): boolean {
  return (
    (error instanceof DOMException && error.name === 'AbortError') ||
    (error instanceof Error && error.name === 'AbortError')
  );
}
