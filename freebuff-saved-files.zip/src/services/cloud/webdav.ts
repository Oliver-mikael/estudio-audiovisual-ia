// Generic WebDAV Provider
// Works with free hosting the user already has (Nextcloud, Koofr, HiDrive,
// Yandex Disk WebDAV, a NAS...) so cloud backup does not require a paid API.
// Quotas are read through RFC 4331 properties when the server exposes them.
//
// Limitations (documented, not simulated): plain WebDAV PUT cannot resume a
// partial transfer, so an interrupted asset is uploaded again from the start.
import {
  CloudAuthRequiredError,
  type CloudProvider,
  type CloudStatus,
  type RemoteFile,
  type UploadRequest,
} from './types';
import { getWebDavConfig, getWebDavPassword } from './settings';

function normalizeBase(baseUrl: string): string {
  return baseUrl.replace(/\/+$/, '');
}

function encodeBasicAuth(username: string, password: string): string {
  const bytes = new TextEncoder().encode(`${username}:${password}`);
  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return `Basic ${btoa(binary)}`;
}

function parseXml(text: string): Document | null {
  if (typeof DOMParser === 'undefined') return null;
  try {
    const doc = new DOMParser().parseFromString(text, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length > 0) return null;
    return doc;
  } catch {
    return null;
  }
}

function textOf(parent: Element, localName: string): string | null {
  const nodes = parent.getElementsByTagNameNS('*', localName);
  if (nodes.length > 0) return nodes[0].textContent;
  const fallback = parent.getElementsByTagName(localName);
  return fallback.length > 0 ? fallback[0].textContent : null;
}

export class WebDavProvider implements CloudProvider {
  public readonly id = 'webdav' as const;
  public readonly label = 'WebDAV (nube propia o gratuita)';
  public readonly supportsResume = false;
  public readonly limitations = [
    'No hay cuota gratuita universal: depende del proveedor WebDAV que ya uses.',
    'La cuota solo se muestra si el servidor implementa RFC 4331 (quota-available-bytes).',
    'La subida no se puede reanudar a mitad de archivo; se reintenta desde el inicio.',
    'La contraseña se guarda solo en la sesión del navegador (se borra al cerrar la pestaña).',
  ];

  public isConfigured(): boolean {
    return getWebDavConfig().baseUrl.length > 0;
  }

  private authHeader(): string {
    const config = getWebDavConfig();
    const password = getWebDavPassword();
    if (!config.baseUrl) {
      throw new CloudAuthRequiredError('Configura la URL de tu servidor WebDAV.', null);
    }
    if (!config.username || !password) {
      throw new CloudAuthRequiredError(
        'Introduce usuario y contraseña (o contraseña de aplicación) de WebDAV.',
        null
      );
    }
    return encodeBasicAuth(config.username, password);
  }

  private async request(
    url: string,
    init: RequestInit & { headers?: Record<string, string> } = {}
  ): Promise<Response> {
    const response = await fetch(url, {
      ...init,
      headers: {
        Authorization: this.authHeader(),
        ...(init.headers || {}),
      },
    });
    if (response.status === 401 || response.status === 403) {
      throw new CloudAuthRequiredError(
        'WebDAV rechazó las credenciales. Revisa usuario y contraseña de aplicación.',
        null
      );
    }
    return response;
  }

  private folderUrl(): string {
    const config = getWebDavConfig();
    return `${normalizeBase(config.baseUrl)}/${encodeURIComponent(config.folderName)}/`;
  }

  public async connect(): Promise<CloudStatus> {
    const status = await this.getStatus();
    if (!status.connected) {
      throw new CloudAuthRequiredError(
        status.lastError || 'No se pudo conectar al servidor WebDAV.',
        null
      );
    }
    return status;
  }

  public disconnect(): void {
    /* Credentials live in the caller's session storage; nothing to revoke. */
  }

  public async getStatus(): Promise<CloudStatus> {
    const config = getWebDavConfig();
    if (!config.baseUrl) {
      return {
        providerId: this.id,
        configured: false,
        connected: false,
        detail: 'Falta la URL del servidor WebDAV.',
      };
    }

    try {
      const rootResponse = await this.request(`${normalizeBase(config.baseUrl)}/`, {
        method: 'PROPFIND',
        headers: { Depth: '0', 'Content-Type': 'application/xml' },
        body: '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:quota-used-bytes/><d:quota-available-bytes/></d:prop></d:propfind>',
      });
      if (!rootResponse.ok && rootResponse.status !== 207) {
        throw new Error(`El servidor WebDAV respondió ${rootResponse.status}.`);
      }

      const xml = parseXml(await rootResponse.text().catch(() => ''));
      let usedBytes = 0;
      let totalBytes: number | null = null;

      if (xml) {
        const used = xml.getElementsByTagNameNS('*', 'quota-used-bytes')[0]?.textContent;
        const available = xml.getElementsByTagNameNS('*', 'quota-available-bytes')[0]?.textContent;
        const parsedUsed = Number(used ?? 0);
        const parsedAvailable = Number(available ?? NaN);
        if (Number.isFinite(parsedUsed)) usedBytes = parsedUsed;
        if (Number.isFinite(parsedAvailable) && parsedAvailable > 0) {
          totalBytes = usedBytes + parsedAvailable;
        }
      }

      return {
        providerId: this.id,
        configured: true,
        connected: true,
        accountLabel: config.username || new URL(config.baseUrl).host,
        quota: totalBytes === null ? undefined : { usedBytes, totalBytes },
        detail:
          totalBytes === null
            ? 'El servidor no informa cuota disponible (sin RFC 4331).'
            : undefined,
      };
    } catch (error) {
      return {
        providerId: this.id,
        configured: true,
        connected: false,
        lastError: error instanceof Error ? error.message : String(error),
      };
    }
  }

  public async ensureFolder(_name: string): Promise<string> {
    const url = this.folderUrl();
    // PROPFIND first: MKCOL on an existing collection returns 405.
    const probe = await this.request(url, { method: 'PROPFIND', headers: { Depth: '0' } });
    if (probe.status === 207 || probe.ok) return url;

    const created = await this.request(url, { method: 'MKCOL' });
    if (created.status !== 201 && created.status !== 405 && !created.ok) {
      throw new Error(`No se pudo crear la carpeta WebDAV (${created.status}).`);
    }
    return url;
  }

  public async list(folderUrl: string): Promise<RemoteFile[]> {
    const response = await this.request(folderUrl, {
      method: 'PROPFIND',
      headers: { Depth: '1', 'Content-Type': 'application/xml' },
      body: '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:getcontentlength/><d:getlastmodified/><d:getetag/><d:resourcetype/></d:prop></d:propfind>',
    });
    if (!response.ok && response.status !== 207) {
      throw new Error(`No se pudo listar la carpeta WebDAV (${response.status}).`);
    }

    const xml = parseXml(await response.text());
    if (!xml) return [];

    const files: RemoteFile[] = [];
    const responses = Array.from(xml.getElementsByTagNameNS('*', 'response'));
    for (const node of responses) {
      const href = textOf(node, 'href');
      if (!href) continue;
      const isCollection = node.getElementsByTagNameNS('*', 'collection').length > 0;
      if (isCollection) continue;

      const name = decodeURIComponent(href.replace(/\/$/, '').split('/').pop() || '');
      const size = Number(textOf(node, 'getcontentlength') ?? 0);
      const modified = Date.parse(textOf(node, 'getlastmodified') ?? '');
      const etag = textOf(node, 'getetag') ?? undefined;

      files.push({
        id: href,
        name,
        sizeBytes: Number.isFinite(size) ? size : 0,
        modifiedAt: Number.isFinite(modified) ? modified : 0,
        checksum: etag?.replace(/"/g, '').replace(/^W\//, ''),
      });
    }
    return files;
  }

  public async upload(request: UploadRequest): Promise<RemoteFile> {
    const folderUrl = request.folderId ?? (await this.ensureFolder(''));
    const url = `${folderUrl.replace(/\/?$/, '/')}${encodeURIComponent(request.name)}`;

    request.onProgress?.(0, request.data.size);
    const response = await this.request(url, {
      method: 'PUT',
      headers: { 'Content-Type': request.data.type || 'application/octet-stream' },
      body: request.data,
      signal: request.signal,
    });

    if (!response.ok) {
      throw new Error(`La subida WebDAV falló (${response.status}).`);
    }

    request.onProgress?.(request.data.size, request.data.size);
    const etag = response.headers.get('ETag')?.replace(/"/g, '').replace(/^W\//, '');
    return {
      id: url,
      name: request.name,
      sizeBytes: request.data.size,
      modifiedAt: Date.now(),
      checksum: etag,
    };
  }

  public async download(fileId: string): Promise<Blob> {
    const response = await this.request(fileId, { method: 'GET' });
    if (!response.ok) throw new Error(`No se pudo descargar el archivo (${response.status}).`);
    return response.blob();
  }

  public async remove(fileId: string): Promise<void> {
    const response = await this.request(fileId, { method: 'DELETE' });
    if (!response.ok && response.status !== 404) {
      throw new Error(`No se pudo borrar el archivo remoto (${response.status}).`);
    }
  }
}

export const webDavProvider = new WebDavProvider();
