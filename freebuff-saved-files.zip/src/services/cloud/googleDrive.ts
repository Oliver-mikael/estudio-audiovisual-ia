// Google Drive Provider (Drive API v3, browser-only OAuth)
//
// Free tier: Google accounts include 15 GB shared across Drive, Gmail and Photos
// (https://support.google.com/drive/answer/6374270). The real quota is read at
// runtime from `about?fields=storageQuota`; the app never assumes a number.
//
// OAuth: implicit token flow (`response_type=token`) with the non-sensitive
// `drive.file` scope, which only grants access to files this app created. A
// client ID is required from the user's own Google Cloud project; no secret is
// used or stored. The access token lives in sessionStorage (cleared when the tab
// closes) and is never logged.
import {
  CloudAuthRequiredError,
  type CloudProvider,
  type CloudStatus,
  type RemoteFile,
  type UploadRequest,
  type UploadSession,
} from './types';
import { getGoogleDriveConfig } from './settings';

const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
const DRIVE_API = 'https://www.googleapis.com/drive/v3';
const DRIVE_UPLOAD = 'https://www.googleapis.com/upload/drive/v3';
const SCOPE = 'https://www.googleapis.com/auth/drive.file';
const FOLDER_MIME = 'application/vnd.google-apps.folder';
const TOKEN_KEY = 'estudio_gdrive_token';
/** Drive requires resumable chunks to be multiples of 256 KB. */
const CHUNK_SIZE = 8 * 1024 * 1024;

interface StoredToken {
  accessToken: string;
  expiresAt: number;
}

interface DriveFile {
  id: string;
  name?: string;
  size?: string;
  modifiedTime?: string;
  md5Checksum?: string;
}

function readToken(): StoredToken | null {
  try {
    const raw = sessionStorage.getItem(TOKEN_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredToken;
    if (!parsed.accessToken) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeToken(token: StoredToken | null): void {
  try {
    if (token) sessionStorage.setItem(TOKEN_KEY, JSON.stringify(token));
    else sessionStorage.removeItem(TOKEN_KEY);
  } catch {
    /* Session storage unavailable: the token is used from memory only. */
  }
}

function currentRedirectUri(): string {
  if (typeof window === 'undefined') return '';
  return `${window.location.origin}${window.location.pathname}`;
}

export function buildGoogleDriveAuthUrl(clientId: string): string {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: currentRedirectUri(),
    response_type: 'token',
    scope: SCOPE,
    include_granted_scopes: 'true',
    prompt: 'select_account',
  });
  return `${AUTH_ENDPOINT}?${params.toString()}`;
}

/**
 * Consumes `#access_token=...` after Google redirects back. Returns true when a
 * token was stored. The fragment is removed so the token never stays in the URL
 * bar, history or screenshots.
 */
export function completeGoogleDriveRedirect(): boolean {
  if (typeof window === 'undefined') return false;
  const hash = window.location.hash.replace(/^#/, '');
  if (!hash) return false;
  const params = new URLSearchParams(hash);
  const accessToken = params.get('access_token');
  if (!accessToken) return false;

  const expiresIn = Number(params.get('expires_in') ?? '0');
  const expiresAt = Date.now() + Math.max(60, expiresIn) * 1000 - 30_000;
  writeToken({ accessToken, expiresAt });

  try {
    const clean = `${window.location.origin}${window.location.pathname}${window.location.search}`;
    window.history.replaceState(null, document.title, clean);
  } catch {
    /* History may be unavailable in some WebViews. */
  }
  return true;
}

function parseDriveFile(file: DriveFile): RemoteFile {
  return {
    id: file.id,
    name: file.name ?? '(sin nombre)',
    sizeBytes: Number(file.size ?? 0),
    modifiedAt: file.modifiedTime ? new Date(file.modifiedTime).getTime() : Date.now(),
    checksum: file.md5Checksum?.toLowerCase(),
  };
}

export class GoogleDriveProvider implements CloudProvider {
  public readonly id = 'google-drive' as const;
  public readonly label = 'Google Drive';
  public readonly supportsResume = true;
  public readonly limitations = [
    'Cuota gratuita de 15 GB compartida entre Drive, Gmail y Fotos; el límite real se consulta a la API.',
    'Requiere un Client ID OAuth de un proyecto propio de Google Cloud con la API de Drive activada.',
    'El alcance drive.file solo permite ver y modificar archivos creados por esta aplicación.',
    'Los tokens de acceso duran ~1 hora; al caducar hay que autorizar de nuevo.',
  ];

  private folderId: string | null = null;

  public isConfigured(): boolean {
    return getGoogleDriveConfig().clientId.length > 0;
  }

  public disconnect(): void {
    writeToken(null);
    this.folderId = null;
  }

  private getValidToken(): StoredToken | null {
    const token = readToken();
    if (!token) return null;
    if (token.expiresAt <= Date.now()) {
      writeToken(null);
      return null;
    }
    return token;
  }

  private requireToken(): StoredToken {
    const token = this.getValidToken();
    if (token) return token;

    const config = getGoogleDriveConfig();
    if (!config.clientId) {
      throw new CloudAuthRequiredError(
        'Configura un Client ID de Google Drive para conectar la nube.',
        null
      );
    }
    throw new CloudAuthRequiredError(
      'Autoriza el acceso a Google Drive para respaldar y restaurar proyectos.',
      buildGoogleDriveAuthUrl(config.clientId)
    );
  }

  private async request(path: string, init: RequestInit = {}, allowRetry = true): Promise<Response> {
    const token = this.requireToken();
    const response = await fetch(path, {
      ...init,
      headers: {
        ...(init.headers || {}),
        Authorization: `Bearer ${token.accessToken}`,
      },
    });

    if (response.status === 401 && allowRetry) {
      writeToken(null);
      return this.request(path, init, false);
    }
    if (!response.ok && response.status !== 308) {
      const detail = await response.text().catch(() => '');
      throw new Error(
        `Google Drive respondió ${response.status}${detail ? `: ${detail.slice(0, 200)}` : ''}`
      );
    }
    return response;
  }

  public async connect(): Promise<CloudStatus> {
    this.requireToken();
    return this.getStatus();
  }

  public async getStatus(): Promise<CloudStatus> {
    if (!this.isConfigured()) {
      return {
        providerId: this.id,
        configured: false,
        connected: false,
        detail: 'Falta el Client ID OAuth de Google Drive.',
      };
    }

    const token = this.getValidToken();
    if (!token) {
      return {
        providerId: this.id,
        configured: true,
        connected: false,
        detail: 'Sin sesión: autoriza el acceso para sincronizar.',
      };
    }

    try {
      const response = await this.request(
        `${DRIVE_API}/about?fields=user(displayName,emailAddress),storageQuota(limit,usage,usageInDrive)`,
        { method: 'GET' }
      );
      const data = (await response.json()) as {
        user?: { displayName?: string; emailAddress?: string };
        storageQuota?: { limit?: string; usage?: string; usageInDrive?: string };
      };
      const limit = Number(data.storageQuota?.limit ?? 0);
      const used = Number(data.storageQuota?.usage ?? data.storageQuota?.usageInDrive ?? 0);

      return {
        providerId: this.id,
        configured: true,
        connected: true,
        accountLabel: data.user?.emailAddress || data.user?.displayName || 'Cuenta de Google',
        quota: { usedBytes: used, totalBytes: limit > 0 ? limit : null },
      };
    } catch (error) {
      return {
        providerId: this.id,
        configured: true,
        connected: false,
        lastError: error instanceof Error ? error.message : String(error),
      };
    }
  }

  public async ensureFolder(name: string): Promise<string> {
    if (this.folderId) return this.folderId;

    const safeName = name.replace(/'/g, "\\'");
    const query = encodeURIComponent(
      `name='${safeName}' and mimeType='${FOLDER_MIME}' and trashed=false`
    );
    const search = await this.request(
      `${DRIVE_API}/files?q=${query}&fields=files(id,name)&spaces=drive&pageSize=10`,
      { method: 'GET' }
    );
    const found = (await search.json()) as { files?: Array<{ id: string }> };
    if (found.files && found.files.length > 0) {
      this.folderId = found.files[0].id;
      return this.folderId;
    }

    const created = await this.request(`${DRIVE_API}/files?fields=id`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, mimeType: FOLDER_MIME }),
    });
    const file = (await created.json()) as { id: string };
    this.folderId = file.id;
    return file.id;
  }

  public async list(folderId: string): Promise<RemoteFile[]> {
    const query = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
    const response = await this.request(
      `${DRIVE_API}/files?q=${query}&fields=files(id,name,size,modifiedTime,md5Checksum)&pageSize=1000&orderBy=name`,
      { method: 'GET' }
    );
    const data = (await response.json()) as { files?: DriveFile[] };
    return (data.files ?? []).map(parseDriveFile);
  }

  private async resolveResumeOffset(session: UploadSession): Promise<number> {
    const response = await this.request(session.sessionUri, {
      method: 'PUT',
      headers: {
        'Content-Range': `bytes */${session.totalBytes}`,
        'Content-Length': '0',
      },
    });
    if (response.status === 308) {
      const range = response.headers.get('Range');
      const received = range ? Number(range.split('-')[1]) + 1 : 0;
      return Number.isFinite(received) ? received : 0;
    }
    // 200/201 means the upload already completed; nothing left to send.
    return session.totalBytes;
  }

  public async upload(request: UploadRequest): Promise<RemoteFile> {
    const { data, signal, onProgress, onSession, session } = request;
    const folderId = request.folderId ?? (await this.ensureFolder(getGoogleDriveConfig().folderName));

    let sessionUri = session?.sessionUri;
    let offset = 0;

    if (sessionUri && session) {
      offset = await this.resolveResumeOffset(session);
      if (offset >= data.size) {
        throw new Error(
          'La sesión de subida ya estaba completa; vuelve a iniciar el respaldo para verificarla.'
        );
      }
    } else {
      const init = await this.request(`${DRIVE_UPLOAD}/files?uploadType=resumable&fields=id,name,size,modifiedTime,md5Checksum`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
          'X-Upload-Content-Type': data.type || 'application/octet-stream',
          'X-Upload-Content-Length': String(data.size),
        },
        body: JSON.stringify({ name: request.name, parents: folderId ? [folderId] : undefined }),
        signal,
      });
      const location = init.headers.get('Location');
      if (!location) throw new Error('Google Drive no devolvió una URL de subida reanudable.');
      sessionUri = location;
    }

    onSession?.({ sessionUri, sentBytes: offset, totalBytes: data.size });

    while (offset < data.size) {
      if (signal?.aborted) throw new DOMException('Subida cancelada.', 'AbortError');
      const end = Math.min(offset + CHUNK_SIZE, data.size);
      const chunk = data.slice(offset, end);
      const response = await fetch(sessionUri, {
        method: 'PUT',
        headers: {
          'Content-Range': `bytes ${offset}-${end - 1}/${data.size}`,
        },
        body: chunk,
        signal,
      });

      if (response.status === 308) {
        const range = response.headers.get('Range');
        offset = range ? Number(range.split('-')[1]) + 1 : end;
        onProgress?.(offset, data.size);
        onSession?.({ sessionUri, sentBytes: offset, totalBytes: data.size });
        continue;
      }

      if (!response.ok) {
        const detail = await response.text().catch(() => '');
        throw new Error(
          `La subida a Drive falló (${response.status})${detail ? `: ${detail.slice(0, 200)}` : ''}`
        );
      }

      const file = (await response.json()) as DriveFile;
      onProgress?.(data.size, data.size);
      return parseDriveFile(file);
    }

    throw new Error('La subida terminó sin respuesta de Google Drive.');
  }

  public async download(fileId: string): Promise<Blob> {
    const response = await this.request(`${DRIVE_API}/files/${encodeURIComponent(fileId)}?alt=media`, {
      method: 'GET',
    });
    return response.blob();
  }

  public async remove(fileId: string): Promise<void> {
    await this.request(`${DRIVE_API}/files/${encodeURIComponent(fileId)}`, { method: 'DELETE' });
  }
}

export const googleDriveProvider = new GoogleDriveProvider();
