// Integrity hashing for backups: SHA-256 via Web Crypto and a dependency-free
// MD5 implementation (Google Drive reports md5Checksum for uploaded files, so
// verification needs MD5 without adding a package).
import { computeSHA256 } from '../storage/projectBackup';

export async function sha256Blob(blob: Blob): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const buffer = await blob.arrayBuffer();
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return Array.from(new Uint8Array(digest))
      .map((byte) => byte.toString(16).padStart(2, '0'))
      .join('');
  }

  // Test/legacy fallback: hash the bytes with the shared text checksum so the
  // value is still deterministic, and mark it as non-cryptographic.
  const text = await blob.text();
  return `sha256-unavailable:${await computeSHA256(text)}`;
}

/** Compact MD5 (RFC 1321) over raw bytes. */
export function md5Hex(bytes: Uint8Array): string {
  const s = [
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9,
    14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15,
    21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
  ];
  const k = new Uint32Array(64);
  for (let i = 0; i < 64; i += 1) {
    k[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 0x100000000) >>> 0;
  }

  const length = bytes.length;
  const bitLength = length * 8;
  const paddedLength = (((length + 8) >> 6) + 1) * 64;
  const message = new Uint8Array(paddedLength);
  message.set(bytes);
  message[length] = 0x80;
  const view = new DataView(message.buffer);
  view.setUint32(paddedLength - 8, bitLength >>> 0, true);
  view.setUint32(paddedLength - 4, Math.floor(bitLength / 0x100000000), true);

  let a0 = 0x67452301;
  let b0 = 0xefcdab89;
  let c0 = 0x98badcfe;
  let d0 = 0x10325476;

  const words = new Uint32Array(16);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let i = 0; i < 16; i += 1) words[i] = view.getUint32(offset + i * 4, true);

    let a = a0;
    let b = b0;
    let c = c0;
    let d = d0;

    for (let i = 0; i < 64; i += 1) {
      let f: number;
      let g: number;
      if (i < 16) {
        f = (b & c) | (~b & d);
        g = i;
      } else if (i < 32) {
        f = (d & b) | (~d & c);
        g = (5 * i + 1) % 16;
      } else if (i < 48) {
        f = b ^ c ^ d;
        g = (3 * i + 5) % 16;
      } else {
        f = c ^ (b | ~d);
        g = (7 * i) % 16;
      }
      const temp = d;
      d = c;
      c = b;
      const rotated = (a + f + k[i] + words[g]) >>> 0;
      b = (b + ((rotated << s[i]) | (rotated >>> (32 - s[i])))) >>> 0;
      a = temp;
    }

    a0 = (a0 + a) >>> 0;
    b0 = (b0 + b) >>> 0;
    c0 = (c0 + c) >>> 0;
    d0 = (d0 + d) >>> 0;
  }

  const toLittleEndianHex = (value: number): string => {
    return [0, 8, 16, 24]
      .map((shift) => ((value >>> shift) & 0xff).toString(16).padStart(2, '0'))
      .join('');
  };

  return [a0, b0, c0, d0].map(toLittleEndianHex).join('');
}

export async function md5Blob(blob: Blob): Promise<string> {
  const buffer = await blob.arrayBuffer();
  return md5Hex(new Uint8Array(buffer));
}
