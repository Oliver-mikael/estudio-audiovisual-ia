// Provider registry: resolves the configured cloud backend without hiding which
// one is active, and exposes the verified limitations of each.
import { googleDriveProvider, completeGoogleDriveRedirect } from './googleDrive';
import { webDavProvider } from './webdav';
import { getCloudProviderChoice } from './settings';
import type { CloudProvider, CloudProviderId, CloudStatus } from './types';

export const CLOUD_PROVIDERS: Record<CloudProviderId, CloudProvider> = {
  'google-drive': googleDriveProvider,
  webdav: webDavProvider,
};

export function getCloudProvider(id: CloudProviderId): CloudProvider {
  return CLOUD_PROVIDERS[id];
}

export function getActiveCloudProvider(): CloudProvider | null {
  const choice = getCloudProviderChoice();
  if (choice === 'none') return null;
  return CLOUD_PROVIDERS[choice];
}

export async function getActiveCloudStatus(): Promise<CloudStatus | null> {
  const provider = getActiveCloudProvider();
  if (!provider) return null;
  return provider.getStatus();
}

/** Finishes the OAuth redirect (if any) before the app renders. */
export function initializeCloudAuth(): boolean {
  return completeGoogleDriveRedirect();
}
