// Local-first Cloud Backup Engine
// Builds a content-addressed manifest of every project and media binary, uploads
// only what the remote does not already have (MD5 dedupe), verifies integrity,
// resumes interrupted uploads when the provider supports sessions, and restores
// projects without silently overwriting newer local work.
import { MediaAsset, Project } from '../../types';
import {
  getAllMediaAssets,
  getAllProjectsFromStorage,
  getMediaAssetBlob,
  getProjectFromStorage,
  saveMediaAssetBlob,
  saveProjectToStorage,
} from '../storage/db';

import { md5Blob, sha256Blob } from './hash';
import type { CloudProvider, CloudProviderId, RemoteFile } from './types';
import { isAbortError } from './types';

export const BACKUP_MANIFEST_NAME = 'estudio-backup-manifest.json';
export const BACKUP_MANIFEST_FORMAT = 'ESTUDIO_AUDIOVISUAL_BACKUP';
export const BACKUP_MANIFEST_VERSION = 1;
const JOURNAL_KEY = 'estudio_backup_journal_v1';

export interface BackupEntry {
  /** Stable key used by the journal and remote lookup. */
  key: string;
  kind: 'project' | 'asset';
  id: string;
  name: string;
  sizeBytes: number;
  sha256: string;
  md5: string;
  updatedAt: number;
  /** Media kind for asset entries, so a restore recreates the right asset type. */
  mediaType?: MediaAsset['type'];
  /** Asset referenced by a project but absent from IndexedDB. */
  missing?: boolean;
}

export interface BackupManifest {
  format: typeof BACKUP_MANIFEST_FORMAT;
  version: number;
  createdAt: number;
  providerId: CloudProviderId;
  entries: BackupEntry[];
  totals: { projectBytes: number; assetBytes: number };
}

export interface BackupJournal {
  id: string;
  providerId: CloudProviderId;
  startedAt: number;
  updatedAt: number;
  manifest: BackupManifest;
  folderId?: string;
  completed: Record<string, { remoteId: string; verified: boolean }>;
  session?: { key: string; sessionUri: string; sentBytes: number; totalBytes: number };
  lastError?: string;
}

export interface BackupProgress {
  phase: 'scanning' | 'uploading' | 'verifying' | 'done';
  completed: number;
  total: number;
  message: string;
}

export interface BackupResult {
  manifest: BackupManifest;
  uploadedCount: number;
  dedupedCount: number;
  missingCount: number;
  verifiedCount: number;
  unverifiedCount: number;
  manifestRemoteId: string;
  bytesUploaded: number;
  journalId: string;
}

export interface RestoreConflict {
  projectId: string;
  title: string;
  localUpdatedAt: number;
  remoteUpdatedAt: number;
  resolution: 'kept-local' | 'used-remote' | 'imported-copy';
  copyId?: string;
}

export interface RestoreResult {
  projectsRestored: number;
  assetsRestored: number;
  conflicts: RestoreConflict[];
  missingAssets: number;
  manifestCreatedAt: number;
}

export type RestoreConflictStrategy = 'keep-both' | 'prefer-local' | 'prefer-remote';

function readJournal(): BackupJournal | null {
  try {
    if (typeof localStorage === 'undefined') return null;
    const raw = localStorage.getItem(JOURNAL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as BackupJournal;
    if (parsed?.manifest?.format !== BACKUP_MANIFEST_FORMAT) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeJournal(journal: BackupJournal | null): void {
  try {
    if (typeof localStorage === 'undefined') return;
    if (journal) localStorage.setItem(JOURNAL_KEY, JSON.stringify(journal));
    else localStorage.removeItem(JOURNAL_KEY);
  } catch {
    /* Quota exceeded: the in-memory run still completes. */
  }
}

export function loadBackupJournal(): BackupJournal | null {
  return readJournal();
}

export function clearBackupJournal(): void {
  writeJournal(null);
}

function projectBlob(project: Project): Blob {
  return new Blob([JSON.stringify(project)], { type: 'application/json' });
}

function projectFileName(project: Project): string {
  const clean = project.title.toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/-+/g, '-');
  return `proyecto-${clean || 'sin-titulo'}-${project.id}.json`;
}

function assetFileName(asset: MediaAsset): string {
  const clean = asset.name.toLowerCase().replace(/[^a-z0-9._-]+/g, '-');
  return `medio-${asset.id}-${clean || 'recurso'}`;
}

async function hashEntry(entry: Omit<BackupEntry, 'sha256' | 'md5'>, blob: Blob): Promise<BackupEntry> {
  return {
    ...entry,
    sha256: await sha256Blob(blob),
    md5: await md5Blob(blob),
  };
}

/**
 * Reads every stored project and asset, hashing their payload for dedupe and
 * integrity. Missing binaries are recorded instead of aborting the backup.
 */
export async function buildBackupManifest(providerId: CloudProviderId): Promise<BackupManifest> {
  const [projects, assets] = await Promise.all([
    getAllProjectsFromStorage(),
    getAllMediaAssets(),
  ]);

  const entries: BackupEntry[] = [];
  let projectBytes = 0;
  let assetBytes = 0;

  for (const project of projects) {
    const blob = projectBlob(project);
    const entry = await hashEntry(
      {
        key: `project:${project.id}`,
        kind: 'project',
        id: project.id,
        name: projectFileName(project),
        sizeBytes: blob.size,
        updatedAt: project.updatedAt,
      },
      blob
    );
    projectBytes += blob.size;
    entries.push(entry);
  }

  // Assets referenced by a project but absent from the binary store are still
  // part of the backup inventory, so a restore can report them as missing.
  const inventory = new Map<string, MediaAsset>();
  for (const asset of assets) inventory.set(asset.id, asset);
  for (const project of projects) {
    for (const asset of project.mediaAssets || []) {
      if (!inventory.has(asset.id)) inventory.set(asset.id, asset);
    }
  }

  for (const asset of inventory.values()) {
    const stored = asset.fileBlob ? asset : await getMediaAssetBlob(asset.id);
    const blob = stored?.fileBlob;
    if (!blob) {
      entries.push({
        key: `asset:${asset.id}`,
        kind: 'asset',
        id: asset.id,
        name: asset.name,
        sizeBytes: 0,
        sha256: '',
        md5: '',
        updatedAt: asset.createdAt,
        mediaType: asset.type,
        missing: true,
      });
      continue;
    }

    const entry = await hashEntry(
      {
        key: `asset:${asset.id}`,
        kind: 'asset',
        id: asset.id,
        name: assetFileName(asset),
        sizeBytes: blob.size,
        updatedAt: asset.createdAt,
        mediaType: asset.type,
      },
      blob
    );
    assetBytes += blob.size;
    entries.push(entry);
  }

  return {
    format: BACKUP_MANIFEST_FORMAT,
    version: BACKUP_MANIFEST_VERSION,
    createdAt: Date.now(),
    providerId,
    entries,
    totals: { projectBytes, assetBytes },
  };
}

export interface BackupUploadPlan {
  /** Entries the remote does not have yet. */
  uploads: BackupEntry[];
  /** Entries already present remotely, matched by MD5. */
  deduped: Array<{ entry: BackupEntry; remoteId: string }>;
  missing: BackupEntry[];
}

/**
 * Content-addressed upload plan: an asset whose MD5 already exists remotely is
 * not uploaded again, even if its name or project changed.
 */
export function planBackupUploads(
  manifest: BackupManifest,
  remoteFiles: RemoteFile[]
): BackupUploadPlan {
  const remoteByChecksum = new Map<string, RemoteFile>();
  for (const file of remoteFiles) {
    if (file.checksum) remoteByChecksum.set(file.checksum.toLowerCase(), file);
  }

  const uploads: BackupEntry[] = [];
  const deduped: Array<{ entry: BackupEntry; remoteId: string }> = [];
  const missing: BackupEntry[] = [];

  for (const entry of manifest.entries) {
    if (entry.missing) {
      missing.push(entry);
      continue;
    }
    const remote = entry.md5 ? remoteByChecksum.get(entry.md5) : undefined;
    if (remote) deduped.push({ entry, remoteId: remote.id });
    else uploads.push(entry);
  }

  return { uploads, deduped, missing };
}

async function loadEntryBlob(entry: BackupEntry): Promise<Blob | null> {
  if (entry.kind === 'project') {
    // Use the same canonical (migrated, not re-saved) project the manifest
    // hashed. getProjectFromStorage can re-save a migration, which would change
    // updatedAt and make the uploaded bytes differ from the manifest checksum.
    const projects = await getAllProjectsFromStorage();
    const project = projects.find((candidate) => candidate.id === entry.id);
    return project ? projectBlob(project) : null;
  }
  const asset = await getMediaAssetBlob(entry.id);
  return asset?.fileBlob ?? null;
}

/**
 * Runs (or resumes) a backup. The journal is written after every file, so a
 * closed app resumes from the last completed entry; providers with resumable
 * sessions continue the interrupted file instead of restarting it.
 */
export async function runBackup(params: {
  provider: CloudProvider;
  signal?: AbortSignal;
  onProgress?: (progress: BackupProgress) => void;
  /** Rebuild the manifest even when a journal exists. */
  fresh?: boolean;
}): Promise<BackupResult> {
  const { provider, signal } = params;
  const existing = params.fresh ? null : readJournal();
  const resuming = Boolean(existing && existing.providerId === provider.id);

  params.onProgress?.({
    phase: 'scanning',
    completed: 0,
    total: 0,
    message: resuming ? 'Reanudando el respaldo pendiente...' : 'Analizando proyectos y medios...',
  });

  const manifest =
    resuming && existing ? existing.manifest : await buildBackupManifest(provider.id);

  const journal: BackupJournal =
    resuming && existing
      ? existing
      : {
          id: `backup_${Date.now()}`,
          providerId: provider.id,
          startedAt: Date.now(),
          updatedAt: Date.now(),
          manifest,
          completed: {},
        };
  journal.manifest = manifest;
  journal.lastError = undefined;
  writeJournal(journal);

  const folderId = journal.folderId ?? (await provider.ensureFolder('Estudio Audiovisual'));
  journal.folderId = folderId;
  writeJournal(journal);

  const remoteFiles = await provider.list(folderId);
  const plan = planBackupUploads(manifest, remoteFiles);

  for (const deduped of plan.deduped) {
    journal.completed[deduped.entry.key] = { remoteId: deduped.remoteId, verified: true };
  }

  const total = plan.uploads.length;
  let completed = 0;
  let bytesUploaded = 0;
  let verifiedCount = 0;
  let unverifiedCount = 0;

  for (const entry of plan.uploads) {
    if (signal?.aborted) throw new DOMException('Respaldo cancelado.', 'AbortError');

    params.onProgress?.({
      phase: 'uploading',
      completed,
      total,
      message: `Subiendo ${entry.kind === 'project' ? 'proyecto' : 'medio'} ${entry.name}...`,
    });

    const blob = await loadEntryBlob(entry);
    if (!blob) {
      journal.completed[entry.key] = { remoteId: '', verified: false };
      journal.lastError = `No se encontró el contenido de ${entry.name}.`;
      writeJournal(journal);
      completed += 1;
      continue;
    }

    const session =
      journal.session && journal.session.key === entry.key
        ? {
            sessionUri: journal.session.sessionUri,
            sentBytes: journal.session.sentBytes,
            totalBytes: journal.session.totalBytes,
          }
        : undefined;

    try {
      const remote = await provider.upload({
        name: entry.name,
        data: blob,
        folderId,
        signal,
        session,
        onSession: (next) => {
          journal.session = { key: entry.key, ...next };
          journal.updatedAt = Date.now();
          writeJournal(journal);
        },
        onProgress: (sent, totalBytes) => {
          const fraction = totalBytes > 0 ? sent / totalBytes : 0;
          params.onProgress?.({
            phase: 'uploading',
            completed: completed + fraction,
            total,
            message: `Subiendo ${entry.name} (${Math.round(fraction * 100)}%)...`,
          });
        },
      });

      // Integrity: compare the provider checksum with the local MD5 when the
      // provider reports one; otherwise at least require the size to match.
      const checksumMatches =
        remote.checksum !== undefined &&
        remote.checksum.length > 0 &&
        remote.checksum.toLowerCase() === entry.md5;
      const sizeMatches = remote.sizeBytes === entry.sizeBytes || remote.sizeBytes === 0;

      journal.completed[entry.key] = {
        remoteId: remote.id,
        verified: checksumMatches,
      };
      journal.session = undefined;
      journal.updatedAt = Date.now();
      writeJournal(journal);

      if (checksumMatches) verifiedCount += 1;
      else if (!sizeMatches) {
        throw new Error(
          `El archivo ${entry.name} llegó incompleto (${remote.sizeBytes} B de ${entry.sizeBytes} B).`
        );
      } else {
        unverifiedCount += 1;
      }

      bytesUploaded += blob.size;
      completed += 1;
    } catch (error) {
      if (isAbortError(error)) {
        journal.updatedAt = Date.now();
        writeJournal(journal);
        throw error;
      }
      journal.lastError = error instanceof Error ? error.message : String(error);
      journal.updatedAt = Date.now();
      writeJournal(journal);
      throw error;
    }
  }

  params.onProgress?.({
    phase: 'verifying',
    completed: total,
    total,
    message: 'Subiendo y verificando el manifiesto del respaldo...',
  });

  const manifestBlob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
  const manifestRemote = await provider.upload({
    name: BACKUP_MANIFEST_NAME,
    data: manifestBlob,
    folderId,
    signal,
  });

  const manifestMd5 = await md5Blob(manifestBlob);
  if (manifestRemote.checksum && manifestRemote.checksum.toLowerCase() !== manifestMd5) {
    throw new Error('El manifiesto subido no coincide con el local; el respaldo no es confiable.');
  }

  writeJournal(null);
  params.onProgress?.({
    phase: 'done',
    completed: total,
    total,
    message: 'Respaldo completado y verificado.',
  });

  return {
    manifest,
    uploadedCount: plan.uploads.length,
    dedupedCount: plan.deduped.length,
    missingCount: plan.missing.length,
    verifiedCount,
    unverifiedCount,
    manifestRemoteId: manifestRemote.id,
    bytesUploaded,
    journalId: journal.id,
  };
}

/** Conflict decision for a project present both locally and in the backup. */
export function resolveProjectConflict(
  local: Project,
  remoteUpdatedAt: number,
  strategy: RestoreConflictStrategy
): 'kept-local' | 'used-remote' | 'imported-copy' {
  if (remoteUpdatedAt > local.updatedAt) {
    // The backup is newer: only `prefer-local` refuses to update.
    return strategy === 'prefer-local' ? 'kept-local' : 'used-remote';
  }
  if (remoteUpdatedAt < local.updatedAt) {
    // Local work is newer and is never overwritten silently.
    if (strategy === 'prefer-remote') return 'used-remote';
    return strategy === 'keep-both' ? 'imported-copy' : 'kept-local';
  }
  return strategy === 'prefer-remote' ? 'used-remote' : 'kept-local';
}

function findManifestFile(files: RemoteFile[]): RemoteFile | null {
  return files.find((file) => file.name === BACKUP_MANIFEST_NAME) ?? null;
}

/**
 * Restores a backup. Projects newer locally are never overwritten silently:
 * `keep-both` imports the remote version as a copy, and the conflict is
 * reported back to the UI.
 */
export async function restoreFromBackup(params: {
  provider: CloudProvider;
  strategy?: RestoreConflictStrategy;
  signal?: AbortSignal;
  onProgress?: (progress: BackupProgress) => void;
}): Promise<RestoreResult> {
  const { provider, signal } = params;
  const strategy = params.strategy ?? 'keep-both';

  const folderId = await provider.ensureFolder('Estudio Audiovisual');
  const files = await provider.list(folderId);
  const manifestFile = findManifestFile(files);
  if (!manifestFile) {
    throw new Error('No se encontró un respaldo de Estudio Audiovisual en la nube.');
  }

  const manifestBlob = await provider.download(manifestFile.id);
  const manifest = JSON.parse(await manifestBlob.text()) as BackupManifest;
  if (
    manifest.format !== BACKUP_MANIFEST_FORMAT ||
    !Array.isArray(manifest.entries)
  ) {
    throw new Error('El manifiesto remoto no es un respaldo válido de Estudio Audiovisual.');
  }

  const byName = new Map(files.map((file) => [file.name, file] as const));
  const conflicts: RestoreConflict[] = [];
  let projectsRestored = 0;
  let assetsRestored = 0;
  let missingAssets = 0;
  const total = manifest.entries.length;
  let completed = 0;

  for (const entry of manifest.entries) {
    if (signal?.aborted) throw new DOMException('Restauración cancelada.', 'AbortError');
    completed += 1;
    params.onProgress?.({
      phase: 'uploading',
      completed,
      total,
      message: `Restaurando ${entry.name}...`,
    });

    if (entry.missing) {
      missingAssets += 1;
      continue;
    }

    const remoteFile = byName.get(entry.name);
    if (!remoteFile) {
      if (entry.kind === 'asset') missingAssets += 1;
      continue;
    }

    let blob: Blob;
    try {
      blob = await provider.download(remoteFile.id);
    } catch {
      if (entry.kind === 'asset') missingAssets += 1;
      continue;
    }

    // Integrity: SHA-256 is computed locally and compared to the manifest.
    const digest = await sha256Blob(blob);
    if (entry.sha256 && digest !== entry.sha256) {
      throw new Error(`El archivo ${entry.name} no pasó la verificación de integridad.`);
    }

    if (entry.kind === 'project') {
      const remoteProject = JSON.parse(await blob.text()) as Project;
      const local = await getProjectFromStorage(remoteProject.id);

      if (!local) {
        await saveProjectToStorage(remoteProject);
        projectsRestored += 1;
        continue;
      }

      const resolution = resolveProjectConflict(local, entry.updatedAt, strategy);
      if (resolution === 'used-remote') {
        await saveProjectToStorage({ ...remoteProject, updatedAt: Math.max(remoteProject.updatedAt, Date.now()) });
        projectsRestored += 1;
      } else if (resolution === 'imported-copy') {
        const copy: Project = {
          ...remoteProject,
          id: `proj-cloud-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          title: `${remoteProject.title} (versión en la nube)`,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        await saveProjectToStorage(copy);
        projectsRestored += 1;
        conflicts.push({
          projectId: local.id,
          title: local.title,
          localUpdatedAt: local.updatedAt,
          remoteUpdatedAt: entry.updatedAt,
          resolution,
          copyId: copy.id,
        });
        continue;
      } else {
        conflicts.push({
          projectId: local.id,
          title: local.title,
          localUpdatedAt: local.updatedAt,
          remoteUpdatedAt: entry.updatedAt,
          resolution,
        });
        continue;
      }

      conflicts.push({
        projectId: local.id,
        title: local.title,
        localUpdatedAt: local.updatedAt,
        remoteUpdatedAt: entry.updatedAt,
        resolution: 'used-remote',
      });
      continue;
    }

    // Assets are never overwritten with different bytes; conflicts are reported.
    const existing = await getMediaAssetBlob(entry.id);
    if (existing?.fileBlob) {
      const existingDigest = await sha256Blob(existing.fileBlob);
      if (existingDigest !== (entry.sha256 || existingDigest)) {
        const copyId = `${entry.id}-cloud`;
        const exists = await getMediaAssetBlob(copyId);
        if (!exists) {
          await saveMediaAssetBlob({
            ...existing,
            id: copyId,
            name: `${existing.name} (nube)`,
            fileBlob: blob,
            createdAt: Date.now(),
          });
          assetsRestored += 1;
        }
      }
      continue;
    }

    await saveMediaAssetBlob({
      id: entry.id,
      name: entry.name,
      type: entry.mediaType ?? 'video',
      url: '',
      fileBlob: blob,
      mimeType: blob.type || 'application/octet-stream',
      sizeBytes: blob.size,
      license: 'Restaurado desde la nube',
      provenance: 'Respaldo en la nube',
      createdAt: entry.updatedAt || Date.now(),
    });
    assetsRestored += 1;
  }

  params.onProgress?.({
    phase: 'done',
    completed: total,
    total,
    message: 'Restauración completada.',
  });

  return {
    projectsRestored,
    assetsRestored,
    conflicts,
    missingAssets,
    manifestCreatedAt: manifest.createdAt,
  };
}

