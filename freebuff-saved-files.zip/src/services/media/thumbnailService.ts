// Media thumbnail and metadata repair
// Rebuilds thumbnails for assets imported before thumbnails existed (or whose
// object URL died with the previous session), using the binary stored in IndexedDB.
import { MediaAsset, Project } from '../../types';
import { getMediaAssetBlob, saveMediaAssetBlob } from '../storage/db';
import { MetadataExtractor } from './metadataExtractor';

const CONCURRENCY = 3;
const inFlight = new Set<string>();

export interface ThumbnailRefreshResult {
  project: Project;
  updatedAssetIds: string[];
  failedAssetIds: string[];
}

function isRealBlob(value: unknown): value is Blob {
  return typeof Blob !== 'undefined' && value instanceof Blob;
}

/**
 * URL usable by the UI across sessions: persisted thumbnails first, remote URLs
 * next. Object URLs created in a previous session are dead and must be ignored.
 */
export function getAssetDisplayUrl(asset: MediaAsset): string | undefined {
  if (asset.thumbnailUrl) return asset.thumbnailUrl;
  if (asset.url && !asset.url.startsWith('blob:')) return asset.url;
  return undefined;
}

async function loadAssetBlob(asset: MediaAsset): Promise<Blob | null> {
  if (isRealBlob(asset.fileBlob)) return asset.fileBlob;
  try {
    const stored = await getMediaAssetBlob(asset.id);
    return isRealBlob(stored?.fileBlob) ? stored!.fileBlob! : null;
  } catch {
    return null;
  }
}

async function repairAsset(asset: MediaAsset): Promise<Partial<MediaAsset> | null> {
  const blob = await loadAssetBlob(asset);
  if (!blob) return null;

  const meta =
    asset.type === 'video'
      ? await MetadataExtractor.extractVideoMetadata(blob)
      : await MetadataExtractor.extractImageMetadata(blob);

  const patch: Partial<MediaAsset> = {};
  if (!asset.thumbnailUrl && meta.thumbnailUrl) patch.thumbnailUrl = meta.thumbnailUrl;
  if (!asset.width && meta.width) patch.width = meta.width;
  if (!asset.height && meta.height) patch.height = meta.height;
  if (!asset.durationSeconds && meta.durationSeconds) patch.durationSeconds = meta.durationSeconds;
  if (!asset.aspectRatio && meta.aspectRatio) patch.aspectRatio = meta.aspectRatio;

  return Object.keys(patch).length > 0 ? patch : null;
}

/**
 * Generates missing thumbnails and technical metadata for image/video assets that
 * still have their binary. Returns the same project object when nothing changed so
 * callers can avoid an unnecessary autosave.
 */
export async function refreshMissingAssetMetadata(project: Project): Promise<ThumbnailRefreshResult> {
  const assets = project.mediaAssets || [];
  const candidates = assets.filter(
    (asset) =>
      (asset.type === 'image' || asset.type === 'video') &&
      !asset.thumbnailUrl &&
      !inFlight.has(asset.id)
  );

  if (candidates.length === 0) {
    return { project, updatedAssetIds: [], failedAssetIds: [] };
  }

  const patches = new Map<string, Partial<MediaAsset>>();
  const failedAssetIds: string[] = [];
  let cursor = 0;

  const worker = async () => {
    while (cursor < candidates.length) {
      const asset = candidates[cursor++];
      inFlight.add(asset.id);
      try {
        const patch = await repairAsset(asset);
        if (patch) patches.set(asset.id, patch);
        else failedAssetIds.push(asset.id);
      } catch {
        failedAssetIds.push(asset.id);
      } finally {
        inFlight.delete(asset.id);
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(CONCURRENCY, candidates.length) }, () => worker())
  );

  if (patches.size === 0) {
    return { project, updatedAssetIds: [], failedAssetIds };
  }

  const updatedAssets = assets.map((asset) =>
    patches.has(asset.id) ? { ...asset, ...patches.get(asset.id) } : asset
  );

  // Keep the binary record in sync so later sessions and .eai exports carry the
  // regenerated thumbnail even before the project is saved again.
  for (const asset of updatedAssets) {
    const patch = patches.get(asset.id);
    if (!patch) continue;
    try {
      const stored = await getMediaAssetBlob(asset.id);
      if (stored && isRealBlob(stored.fileBlob)) {
        await saveMediaAssetBlob({ ...stored, ...patch, fileBlob: stored.fileBlob });
      }
    } catch {
      /* The project copy is still updated below. */
    }
  }

  return {
    project: { ...project, mediaAssets: updatedAssets },
    updatedAssetIds: Array.from(patches.keys()),
    failedAssetIds,
  };
}
