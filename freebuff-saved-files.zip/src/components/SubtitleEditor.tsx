import React, { useMemo, useRef, useState } from 'react';
import { Download, Plus, Trash2, Upload } from 'lucide-react';
import { Project } from '../types';
import {
  addSubtitleCue,
  applyCuesToProject,
  formatSrtTimestamp,
  getCaptionTrackCues,
  getNextCueStartMs,
  getProjectSubtitleCues,
  getSceneNarrationCues,
  parseSrtDetailed,
  removeSubtitleCue,
  serializeSrt,
  updateSubtitleCue,
} from '../services/subtitles/subtitleService';

interface SubtitleEditorProps {
  project: Project;
  playheadMs: number;
  onApply: (project: Project) => void;
}

export const SubtitleEditor: React.FC<SubtitleEditorProps> = ({
  project,
  playheadMs,
  onApply,
}) => {
  const cues = useMemo(() => getCaptionTrackCues(project), [project]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleImport = async (file: File) => {
    try {
      const raw = await file.text();
      const { cues: parsed, skippedBlocks } = parseSrtDetailed(raw);

      if (parsed.length === 0) {
        setFeedback('No se encontraron subtítulos válidos en el archivo.');
        return;
      }

      if (cues.length > 0 && !window.confirm(`Se reemplazarán ${cues.length} subtítulos actuales por ${parsed.length} del archivo. ¿Continuar?`)) {
        return;
      }

      onApply(applyCuesToProject(project, parsed));
      setFeedback(
        `SRT importado: ${parsed.length} subtítulos${
          skippedBlocks > 0 ? ` (${skippedBlocks} bloques inválidos omitidos)` : ''
        }.`
      );
    } catch (error) {
      setFeedback('No se pudo leer el archivo SRT.');
      console.error('Error importando SRT:', error);
    }
  };

  const handleExport = () => {
    const exportCues = getProjectSubtitleCues(project);
    if (exportCues.length === 0) {
      setFeedback('No hay subtítulos para exportar.');
      return;
    }

    const blob = new Blob([serializeSrt(exportCues)], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const safeTitle = (project.title || 'subtitulos').replace(/[^\w\d-]+/g, '-');
    link.href = url;
    link.download = `${safeTitle}.srt`;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setFeedback(
      `SRT exportado con ${exportCues.length} subtítulos${
        cues.length === 0 ? ' (desde la narración de las escenas)' : ''
      }.`
    );
  };

  const handleFromScenes = () => {
    const sceneCues = getSceneNarrationCues(project);
    if (sceneCues.length === 0) {
      setFeedback('El guion no tiene narración para convertir en subtítulos.');
      return;
    }
    if (cues.length > 0 && !window.confirm('Se reemplazarán los subtítulos actuales por la narración de las escenas. ¿Continuar?')) {
      return;
    }
    onApply(applyCuesToProject(project, sceneCues));
    setFeedback(`Subtítulos generados desde ${sceneCues.length} escenas.`);
  };

  const handleAddCue = () => {
    const startMs = Math.max(playheadMs, getNextCueStartMs(project));
    onApply(addSubtitleCue(project, startMs, 2500, 'Nuevo subtítulo').project);
    setFeedback(`Subtítulo añadido en ${formatSrtTimestamp(startMs)}.`);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
        <h3 className="font-semibold text-slate-200">Subtítulos Sincronizados</h3>
        <span className="text-[10px] font-mono text-indigo-400">{cues.length} cues</span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center justify-center gap-1.5 p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium"
        >
          <Upload size={14} /> Importar SRT
        </button>
        <button
          onClick={handleExport}
          className="flex items-center justify-center gap-1.5 p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium"
        >
          <Download size={14} /> Exportar SRT
        </button>
        <button
          onClick={handleAddCue}
          className="flex items-center justify-center gap-1.5 p-2 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg text-xs"
        >
          <Plus size={14} /> Añadir en playhead
        </button>
        <button
          onClick={handleFromScenes}
          className="p-2 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg text-xs"
        >
          Desde escenas
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".srt,text/plain"
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = '';
          if (file) void handleImport(file);
        }}
      />

      {feedback && (
        <p className="text-[11px] text-indigo-300 bg-indigo-950/40 border border-indigo-900 rounded-lg px-2 py-1.5">
          {feedback}
        </p>
      )}

      {cues.length === 0 && (
        <p className="text-[11px] text-slate-400">
          Importa un .srt, genera subtítulos desde las escenas o añade un cue en la posición actual.
        </p>
      )}

      <div className="space-y-2 max-h-[46vh] overflow-y-auto pr-1">
        {cues.map((cue, index) => (
          <div key={cue.id} className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] font-mono text-indigo-400">#{index + 1}</span>
              <div className="flex items-center gap-1">
                <input
                  key={`${cue.id}-start-${cue.startMs}`}
                  type="number"
                  min={0}
                  step={0.1}
                  defaultValue={(cue.startMs / 1000).toFixed(2)}
                  onBlur={(event) => {
                    const seconds = Number(event.target.value);
                    if (Number.isFinite(seconds) && seconds >= 0) {
                      onApply(updateSubtitleCue(project, cue.id, { startMs: Math.round(seconds * 1000) }));
                    }
                  }}
                  className="w-16 bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-[11px] text-slate-200"
                  title="Inicio (segundos)"
                />
                <span className="text-slate-600 text-[10px]">→</span>
                <input
                  key={`${cue.id}-end-${cue.endMs}`}
                  type="number"
                  min={0}
                  step={0.1}
                  defaultValue={(cue.endMs / 1000).toFixed(2)}
                  onBlur={(event) => {
                    const seconds = Number(event.target.value);
                    if (Number.isFinite(seconds) && seconds >= 0) {
                      onApply(updateSubtitleCue(project, cue.id, { endMs: Math.round(seconds * 1000) }));
                    }
                  }}
                  className="w-16 bg-slate-900 border border-slate-800 rounded px-1.5 py-1 text-[11px] text-slate-200"
                  title="Fin (segundos)"
                />
                <button
                  onClick={() => onApply(removeSubtitleCue(project, cue.id))}
                  className="p-1.5 text-slate-500 hover:text-red-400"
                  title="Eliminar subtítulo"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
            <textarea
              key={`${cue.id}-text`}
              rows={2}
              defaultValue={cue.text}
              onBlur={(event) => {
                const text = event.target.value;
                if (text !== cue.text) {
                  onApply(updateSubtitleCue(project, cue.id, { text }));
                }
              }}
              className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-indigo-500"
            />
          </div>
        ))}
      </div>

      <p className="text-[10px] text-slate-500">
        Los subtítulos se guardan en la pista T1, se renderizan sobre el video y se incluyen en la exportación y el autoguardado.
      </p>
    </div>
  );
};
