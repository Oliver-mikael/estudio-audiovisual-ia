// Export Configuration Modal
// Real output settings for the client-side engine: resolution tier, aspect
// ratio and framing, frame rate, verified container/codec, quality, audio,
// estimated size, free space and pre-flight warnings.
import React, { useEffect, useMemo, useState } from 'react';
import { Project, ExportProfile, VideoFitMode } from '../types';
import { Download, X, AlertTriangle, CheckCircle2, Info, HardDrive } from 'lucide-react';
import { getProjectDurationMs } from '../engine/mediaComposition';
import {
  EXPORT_ASPECT_RATIOS,
  ASPECT_RATIO_LABELS,
  FIT_MODE_LABELS,
  FPS_OPTIONS,
  QUALITY_PRESETS,
  AUDIO_QUALITY_PRESETS,
  RESOLUTION_TIERS,
  computeResolution,
  formatBytes,
  getQualityPreset,
  hasBlockingWarning,
  changeProjectFormat,
  inferExportAspect,
  inferResolutionTier,
  type ResolutionTier,
} from '../services/export/exportConfig';
import {
  detectExportCapabilities,
  getAvailableStorageBytes,
  getDeviceMemoryGb,
  probeFrameRateSupport,
  type ExportCapabilities,
} from '../services/export/codecs';
import {
  buildExportPlan,
  createExportSettingsFromProject,
  describeExportPlan,
  type ExportSettings,
} from '../services/export/exportPlan';

/**
 * Named presets kept for compatibility with the existing editor entry points.
 * They seed the full configuration instead of being the only output options.
 */
export const EXPORT_PROFILES: ExportProfile[] = [
  {
    id: 'hd-1080p-16-9',
    name: 'Full HD Horizontal (1080p)',
    format: 'webm',
    aspectRatio: '16:9',
    resolution: { width: 1920, height: 1080 },
    fps: 30,
    bitrateBps: 5000000,
    includeAudio: true,
    description: 'Máxima nitidez para YouTube, televisión y presentaciones profesionales.',
  },
  {
    id: 'standard-720p-16-9',
    name: 'HD Estándar (720p)',
    format: 'webm',
    aspectRatio: '16:9',
    resolution: { width: 1280, height: 720 },
    fps: 30,
    bitrateBps: 2500000,
    includeAudio: true,
    description: 'Equilibrio entre velocidad de renderizado, peso ligero y calidad fluida.',
  },
  {
    id: 'vertical-1080p-9-16',
    name: 'Vertical Móvil (TikTok / Reels / Shorts)',
    format: 'webm',
    aspectRatio: '9:16',
    resolution: { width: 1080, height: 1920 },
    fps: 30,
    bitrateBps: 3500000,
    includeAudio: true,
    description: 'Encuadre vertical optimizado para teléfonos y plataformas de video corto.',
  },
  {
    id: 'mp4-1080p-16-9',
    name: 'MP4 Full HD (1080p)',
    format: 'mp4',
    aspectRatio: '16:9',
    resolution: { width: 1920, height: 1080 },
    fps: 30,
    bitrateBps: 5000000,
    includeAudio: true,
    description: 'Contenedor MP4 cuando el navegador lo soporta; si no, se entrega WebM.',
  },
  {
    id: 'square-720p-1-1',
    name: 'Cuadrado 1:1 (Redes Sociales)',
    format: 'webm',
    aspectRatio: '1:1',
    resolution: { width: 720, height: 720 },
    fps: 30,
    bitrateBps: 1800000,
    includeAudio: true,
    description: 'Formato compacto para feeds de redes sociales y previsualizaciones rápidas.',
  },
];

interface ExportProfilesModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onStartExport: (settings: ExportSettings) => void;
  isExporting: boolean;
  /** Applies a canvas/fps change to the project without touching the edit. */
  onUpdateProject?: (project: Project) => void;
}

const FOCUS_POINTS: Array<{ label: string; x: number; y: number }> = [
  { label: '↖', x: 0, y: 0 },
  { label: '↑', x: 0.5, y: 0 },
  { label: '↗', x: 1, y: 0 },
  { label: '←', x: 0, y: 0.5 },
  { label: '•', x: 0.5, y: 0.5 },
  { label: '→', x: 1, y: 0.5 },
  { label: '↙', x: 0, y: 1 },
  { label: '↓', x: 0.5, y: 1 },
  { label: '↘', x: 1, y: 1 },
];

function warningStyles(level: 'info' | 'warning' | 'danger'): string {
  if (level === 'danger') return 'text-rose-300 border-rose-900/70 bg-rose-950/40';
  if (level === 'warning') return 'text-amber-300 border-amber-900/70 bg-amber-950/30';
  return 'text-sky-300 border-sky-900/70 bg-sky-950/30';
}

export const ExportProfilesModal: React.FC<ExportProfilesModalProps> = ({
  isOpen,
  onClose,
  project,
  onStartExport,
  isExporting,
  onUpdateProject,
}) => {
  const [settings, setSettings] = useState<ExportSettings>(() =>
    createExportSettingsFromProject(project)
  );
  const [projectTier, setProjectTier] = useState<ResolutionTier>(() => inferResolutionTier(project));
  const [projectAspect, setProjectAspect] = useState(() => inferExportAspect(project));
  const [projectFps, setProjectFps] = useState(() => project.settings.fps || 30);
  const [filmGrainEnabled, setFilmGrainEnabled] = useState(
    () => project.settings.filmGrainEnabled ?? project.settings.filmGrain?.enabled ?? true
  );
  const [filmGrainAmount, setFilmGrainAmount] = useState(
    () => project.settings.filmGrainAmount ?? project.settings.filmGrain?.amount ?? 0.08
  );
  const [formatNotice, setFormatNotice] = useState<string | null>(null);
  const [availableBytes, setAvailableBytes] = useState<number | null>(null);
  const [spaceChecked, setSpaceChecked] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setSettings(createExportSettingsFromProject(project));
    setProjectTier(inferResolutionTier(project));
    setProjectAspect(inferExportAspect(project));
    setProjectFps(project.settings.fps || 30);
    setFilmGrainEnabled(project.settings.filmGrainEnabled ?? project.settings.filmGrain?.enabled ?? true);
    setFilmGrainAmount(project.settings.filmGrainAmount ?? project.settings.filmGrain?.amount ?? 0.08);
    setFormatNotice(null);
  }, [isOpen, project.id]);

  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    setSpaceChecked(false);
    getAvailableStorageBytes().then((bytes) => {
      if (cancelled) return;
      setAvailableBytes(bytes);
      setSpaceChecked(true);
    });
    return () => {
      cancelled = true;
    };
  }, [isOpen]);

  const capabilities: ExportCapabilities = useMemo(() => detectExportCapabilities(), [isOpen]);
  const durationMs = getProjectDurationMs(project);
  const durationSeconds = durationMs / 1000;

  const planResult = useMemo(
    () =>
      buildExportPlan({
        settings,
        durationSeconds,
        capabilities,
        availableBytes,
        deviceMemoryGb: getDeviceMemoryGb(),
      }),
    [settings, durationSeconds, availableBytes, capabilities]
  );

  const resolution = computeResolution(settings.resolutionTier, settings.aspectRatio);

  const fpsConfirmed = useMemo(() => {
    if (!isOpen) return true;
    return probeFrameRateSupport(resolution.width, resolution.height, settings.fps);
  }, [isOpen, resolution.width, resolution.height, settings.fps]);

  const update = (patch: Partial<ExportSettings>) =>
    setSettings((previous) => ({ ...previous, ...patch }));

  if (!isOpen) return null;

  const plan = planResult.ok ? planResult.plan : null;
  const blocking = plan ? hasBlockingWarning(plan.warnings) : true;

  const handleStart = () => {
    if (!planResult.ok) return;
    if (!planResult.plan) return;
    if (hasBlockingWarning(planResult.plan.warnings)) {
      const proceed = window.confirm(
        `${planResult.plan.warnings
          .filter((warning) => warning.level === 'danger')
          .map((warning) => warning.message)
          .join('\n')}\n\n¿Exportar de todos modos?`
      );
      if (!proceed) return;
    }
    onStartExport(settings);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-start sm:items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-4 sm:p-5 space-y-4 shadow-2xl my-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">Configuración de Exportación</h3>
              <p className="text-[11px] text-slate-400">
                Proyecto {project.settings.resolution.width}x{project.settings.resolution.height} ·{' '}
                {project.settings.fps} FPS. La salida se configura aquí sin modificar el original.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg text-xs font-mono"
            aria-label="Cerrar"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {/* Resolution */}
          <section className="space-y-1.5">
            <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
              Resolución
            </h4>
            <div className="grid grid-cols-2 gap-1.5">
              {RESOLUTION_TIERS.map((tier) => {
                const size = computeResolution(tier.id, settings.aspectRatio);
                const selected = settings.resolutionTier === tier.id;
                return (
                  <button
                    key={tier.id}
                    onClick={() => update({ resolutionTier: tier.id })}
                    className={`text-left px-2 py-1.5 rounded-lg border text-[11px] transition-colors ${
                      selected
                        ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span className="block font-semibold">{tier.label}</span>
                    <span className="font-mono text-[10px] text-slate-500">
                      {size.width}x{size.height}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Aspect + FPS */}
          <section className="space-y-3">
            <div className="space-y-1.5">
              <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                Relación de aspecto
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {EXPORT_ASPECT_RATIOS.map((aspect) => (
                  <button
                    key={aspect}
                    onClick={() => update({ aspectRatio: aspect })}
                    className={`px-2 py-1 rounded-lg border text-[11px] ${
                      settings.aspectRatio === aspect
                        ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                    title={ASPECT_RATIO_LABELS[aspect]}
                  >
                    {aspect}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
                Cuadros por segundo
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {FPS_OPTIONS.map((fps) => (
                  <button
                    key={fps}
                    onClick={() => update({ fps })}
                    className={`px-2 py-1 rounded-lg border text-[11px] font-mono ${
                      settings.fps === fps
                        ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {fps}
                  </button>
                ))}
              </div>
              {!fpsConfirmed && (
                <p className="text-[10px] text-amber-400/90">
                  El navegador no confirmó {settings.fps} FPS para este tamaño; el grabador puede
                  ajustar la tasa real.
                </p>
              )}
            </div>
          </section>

          {/* Fit mode + framing */}
          <section className="space-y-1.5">
            <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
              Encuadre del material
            </h4>
            <div className="grid grid-cols-2 gap-1.5">
              {(['fill', 'fit', 'crop', 'stretch'] as VideoFitMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => update({ fitMode: mode })}
                  className={`px-2 py-1.5 rounded-lg border text-[11px] ${
                    settings.fitMode === mode
                      ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  {FIT_MODE_LABELS[mode]}
                </button>
              ))}
            </div>
            {settings.fitMode !== 'fit' && settings.fitMode !== 'stretch' && (
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[10px] text-slate-500">Reencuadrar:</span>
                <div className="grid grid-cols-3 gap-0.5">
                  {FOCUS_POINTS.map((point) => {
                    const active =
                      settings.framing.x === point.x && settings.framing.y === point.y;
                    return (
                      <button
                        key={point.label}
                        onClick={() => update({ framing: { x: point.x, y: point.y } })}
                        className={`w-5 h-5 rounded border text-[9px] flex items-center justify-center ${
                          active
                            ? 'border-indigo-500 bg-indigo-600 text-white'
                            : 'border-slate-800 bg-slate-950 text-slate-500'
                        }`}
                        aria-label={`Enfocar ${point.label}`}
                      >
                        {point.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </section>

          {/* Quality + bitrate */}
          <section className="space-y-1.5">
            <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
              Calidad de video
            </h4>
            <div className="grid grid-cols-2 gap-1.5">
              {QUALITY_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() =>
                    update({ quality: preset.id, customBitrateBps: null })
                  }
                  className={`text-left px-2 py-1.5 rounded-lg border text-[11px] ${
                    settings.quality === preset.id && !settings.customBitrateBps
                      ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                      : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                  title={preset.description}
                >
                  {preset.label}
                </button>
              ))}
            </div>
            <label className="block text-[10px] text-slate-500">
              Bitrate personalizado (kbps, vacío = automático)
              <input
                type="number"
                min={250}
                max={80000}
                step={250}
                value={settings.customBitrateBps ? Math.round(settings.customBitrateBps / 1000) : ''}
                onChange={(event) => {
                  const value = Number(event.target.value);
                  update({ customBitrateBps: value > 0 ? value * 1000 : null });
                }}
                className="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-200 font-mono"
                placeholder={`Auto: ${
                  plan ? Math.round(plan.videoBitrateBps / 1000) : '—'
                } kbps`}
              />
            </label>
          </section>
        </div>

        {/* Format */}
        <section className="space-y-1.5">
          <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">
            Formato y códec (detectado en este navegador)
          </h4>
          <div className="space-y-1">
            {capabilities.formats.map((entry) => {
              const { format } = entry;
              const supported = settings.includeAudio
                ? entry.audioSupported
                : entry.supported;
              const selected = plan?.format.id === format.id;
              const isRequested = settings.formatPreference !== 'auto' && format.container === settings.formatPreference;
              return (
                <button
                  key={format.id}
                  disabled={!supported}
                  onClick={() => update({ formatPreference: format.container === 'mp4' ? 'mp4' : 'webm' })}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg border text-[11px] flex items-center justify-between gap-2 ${
                    !supported
                      ? 'border-slate-850 bg-slate-950/60 text-slate-600 cursor-not-allowed'
                      : selected || isRequested
                        ? 'border-indigo-500 bg-indigo-950/60 text-slate-100'
                        : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span>
                    <span className="font-semibold">{format.label}</span>
                    <span className="block text-[10px] text-slate-500">{format.notes}</span>
                  </span>
                  <span className="text-[10px] font-mono shrink-0">
                    {supported ? 'disponible' : 'no disponible'}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-500">
            <button
              onClick={() => update({ formatPreference: 'auto' })}
              className={`px-2 py-1 rounded border ${
                settings.formatPreference === 'auto'
                  ? 'border-indigo-500 text-slate-200'
                  : 'border-slate-800 text-slate-500'
              }`}
            >
              Automático (mejor disponible)
            </button>
            {!capabilities.mediaRecorder && (
              <span className="text-rose-400">MediaRecorder no disponible en este navegador.</span>
            )}
          </div>
        </section>

        {/* Audio */}
        <section className="space-y-1.5">
          <h4 className="text-[11px] font-semibold text-slate-300 uppercase tracking-wide">Audio</h4>
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1.5 text-[11px] text-slate-300">
              <input
                type="checkbox"
                checked={settings.includeAudio}
                onChange={(event) => update({ includeAudio: event.target.checked })}
              />
              Incluir audio
            </label>
            <select
              value={settings.audioQuality}
              disabled={!settings.includeAudio}
              onChange={(event) =>
                update({ audioQuality: event.target.value as ExportSettings['audioQuality'] })
              }
              className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[11px] text-slate-200 disabled:opacity-50"
            >
              {AUDIO_QUALITY_PRESETS.map((preset) => (
                <option key={preset.id} value={preset.id}>
                  {preset.label}
                </option>
              ))}
            </select>
            {!capabilities.audioContext && settings.includeAudio && (
              <span className="text-[10px] text-amber-400">
                AudioContext no disponible: el archivo saldrá sin mezcla.
              </span>
            )}
          </div>
        </section>

        {/* Project format: independent from the export size */}
        {onUpdateProject && (
          <details className="bg-slate-950/60 border border-slate-800 rounded-xl p-2.5 text-[11px]">
            <summary className="cursor-pointer text-slate-300 font-semibold">
              Formato del proyecto (independiente de la exportación)
            </summary>
            <div className="mt-2 grid gap-2 sm:grid-cols-3">
              <label className="text-[10px] text-slate-500">
                Lienzo
                <select
                  value={projectTier}
                  onChange={(event) => setProjectTier(event.target.value as ResolutionTier)}
                  className="mt-1 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                >
                  {RESOLUTION_TIERS.map((tier) => (
                    <option key={tier.id} value={tier.id}>
                      {tier.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-[10px] text-slate-500">
                Aspecto
                <select
                  value={projectAspect}
                  onChange={(event) =>
                    setProjectAspect(event.target.value as ExportSettings['aspectRatio'])
                  }
                  className="mt-1 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                >
                  {EXPORT_ASPECT_RATIOS.map((aspect) => (
                    <option key={aspect} value={aspect}>
                      {ASPECT_RATIO_LABELS[aspect]}
                    </option>
                  ))}
                </select>
              </label>
              <label className="text-[10px] text-slate-500">
                FPS del proyecto
                <select
                  value={projectFps}
                  onChange={(event) => setProjectFps(Number(event.target.value))}
                  className="mt-1 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                >
                  {FPS_OPTIONS.map((fps) => (
                    <option key={fps} value={fps}>
                      {fps}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            <div className="flex items-center justify-between gap-2 mt-2">
              <p className="text-[10px] text-slate-500 leading-relaxed">
                Cambia solo el lienzo y la tasa: clips, offsets, animaciones y medios se conservan.
                La exportación usa su propia configuración.
              </p>
              <button
                onClick={() => {
                  const next = changeProjectFormat(project, {
                    resolution: computeResolution(projectTier, projectAspect),
                    fps: projectFps,
                    aspectRatio: projectAspect,
                  });
                  onUpdateProject(next);
                  setFormatNotice(
                    `Proyecto actualizado a ${next.settings.resolution.width}x${next.settings.resolution.height} · ${next.settings.fps} FPS.`
                  );
                }}
                className="shrink-0 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px]"
              >
                Aplicar al proyecto
              </button>
            </div>
            {formatNotice && <p className="text-[10px] text-emerald-400 mt-1">{formatNotice}</p>}
            <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-400">
              <label className="flex items-center gap-1.5">
                <input
                  type="checkbox"
                  checked={filmGrainEnabled}
                  onChange={(e) => setFilmGrainEnabled(e.target.checked)}
                />
                Grano de película
              </label>
              <input
                type="range"
                min={0}
                max={0.2}
                step={0.01}
                value={filmGrainAmount}
                disabled={!filmGrainEnabled}
                onChange={(e) => setFilmGrainAmount(Number(e.target.value))}
                className="w-24"
              />
              <span className="font-mono">{Math.round(filmGrainAmount * 100)}%</span>
              {onUpdateProject && (
                <button
                  onClick={() => {
                    const next = {
                      ...project,
                      settings: {
                        ...project.settings,
                        filmGrain: { enabled: filmGrainEnabled, amount: filmGrainAmount },
                        filmGrainEnabled,
                        filmGrainAmount,
                      },
                      updatedAt: Date.now(),
                    };
                    onUpdateProject(next);
                    setFormatNotice('Configuración de grano aplicada al proyecto.');
                  }}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[10px]"
                >
                  Aplicar grano
                </button>
              )}
            </div>
          </details>
        )}

        {/* Summary */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-[11px] font-mono text-slate-300 space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-400">Duración del timeline:</span>
            <span>{durationSeconds.toFixed(1)} s</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Salida:</span>
            <span className={planResult.ok ? 'text-indigo-300' : 'text-rose-400'}>
              {planResult.ok ? describeExportPlan(planResult.plan) : planResult.error}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Bitrate de video:</span>
            <span>{plan ? `${Math.round(plan.videoBitrateBps / 1000)} kbps` : '—'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Peso estimado:</span>
            <span className="text-emerald-400 font-bold">
              {plan ? `~${formatBytes(plan.estimatedBytes)}` : '—'}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400 flex items-center gap-1">
              <HardDrive className="w-3 h-3" /> Espacio disponible:
            </span>
            <span className={availableBytes === null ? 'text-slate-500' : 'text-slate-200'}>
              {!spaceChecked
                ? 'consultando...'
                : availableBytes === null
                  ? 'no reportado por el navegador'
                  : formatBytes(availableBytes)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Calidad / audio:</span>
            <span>
              {getQualityPreset(settings.quality).label} ·{' '}
              {settings.includeAudio
                ? AUDIO_QUALITY_PRESETS.find((preset) => preset.id === settings.audioQuality)?.label
                : 'sin audio'}
            </span>
          </div>
          <p className="text-[10px] text-slate-500 leading-relaxed">
            El video se graba en memoria y luego se descarga. La ventana debe permanecer abierta
            durante el render; si se cierra, el trabajo se pierde.
          </p>
        </div>

        {/* Warnings */}
        {plan && plan.warnings.length > 0 && (
          <div className="space-y-1.5">
            {plan.warnings.map((warning) => (
              <div
                key={warning.code}
                className={`flex items-start gap-1.5 border rounded-lg px-2.5 py-1.5 text-[11px] ${warningStyles(warning.level)}`}
              >
                {warning.level === 'danger' ? (
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                ) : warning.level === 'warning' ? (
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                ) : (
                  <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                )}
                <span>{warning.message}</span>
              </div>
            ))}
          </div>
        )}

        {plan && !blocking && plan.warnings.length === 0 && (
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
            <CheckCircle2 className="w-3.5 h-3.5" /> Configuración viable en este navegador.
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleStart}
            disabled={isExporting || !planResult.ok}
            title={planResult.ok ? 'Iniciar renderizado local' : 'Configuración no válida'}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg shadow-md transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Renderizando...' : 'Iniciar Renderizado'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export type { ExportSettings };
