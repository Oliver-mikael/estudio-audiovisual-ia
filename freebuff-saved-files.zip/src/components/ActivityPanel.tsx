// Activity Panel
// One place for background work and cloud state: queue (queued, running,
// paused, completed, failed, interrupted), progress, elapsed time, cancel /
// pause / retry, cloud quota, backup and restore.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Project } from '../types';
import {
  X,
  Activity,
  Pause,
  Play,
  RotateCcw,
  Ban,
  Cloud,
  UploadCloud,
  DownloadCloud,
  HardDrive,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  Bell,
  Save,
  Trash2,
} from 'lucide-react';
import {
  backgroundTaskManager,
  type BackgroundTask,
  type BackgroundTaskStatus,
} from '../services/jobs/taskManager';
import { formatBytes } from '../services/export/exportConfig';
import { formatDurationMs } from '../engine/mediaComposition';
import { runBackup, restoreFromBackup, loadBackupJournal, clearBackupJournal } from '../services/cloud/backupEngine';
import { getProjectFromStorage } from '../services/storage/db';
import { getActiveCloudProvider } from '../services/cloud/providers';
import { CloudAuthRequiredError, type CloudStatus } from '../services/cloud/types';
import {
  getCloudProviderChoice,
  setCloudProviderChoice,
  getGoogleDriveConfig,
  setGoogleDriveConfig,
  getWebDavConfig,
  setWebDavConfig,
  getWebDavPassword,
  setWebDavPassword,
  type CloudProviderChoice,
} from '../services/cloud/settings';

interface ActivityPanelProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  onProjectRestored: (project: Project) => void;
  onSaveNow: () => void;
}

const STATUS_LABELS: Record<BackgroundTaskStatus, string> = {
  queued: 'En cola',
  running: 'En ejecución',
  paused: 'Pausada',
  completed: 'Completada',
  failed: 'Fallida',
  cancelled: 'Cancelada',
  interrupted: 'Interrumpida',
};

function statusColor(status: BackgroundTaskStatus): string {
  switch (status) {
    case 'running':
      return 'text-sky-300 border-sky-900/70 bg-sky-950/40';
    case 'completed':
      return 'text-emerald-300 border-emerald-900/70 bg-emerald-950/40';
    case 'failed':
      return 'text-rose-300 border-rose-900/70 bg-rose-950/40';
    case 'interrupted':
      return 'text-amber-300 border-amber-900/70 bg-amber-950/40';
    case 'paused':
      return 'text-slate-300 border-slate-700 bg-slate-900';
    case 'cancelled':
      return 'text-slate-400 border-slate-800 bg-slate-950';
    default:
      return 'text-indigo-300 border-indigo-900/70 bg-indigo-950/40';
  }
}

function elapsedLabel(task: BackgroundTask): string {
  if (!task.startedAt) return '';
  const end = task.finishedAt ?? Date.now();
  return formatDurationMs(Math.max(0, end - task.startedAt));
}

export const ActivityPanel: React.FC<ActivityPanelProps> = ({
  isOpen,
  onClose,
  project,
  onProjectRestored,
  onSaveNow,
}) => {
  const [tasks, setTasks] = useState<BackgroundTask[]>(() => backgroundTaskManager.getTasks());
  const [providerChoice, setProviderChoice] = useState<CloudProviderChoice>(() =>
    getCloudProviderChoice()
  );
  const [drive, setDrive] = useState(() => getGoogleDriveConfig());
  const [webdav, setWebdav] = useState(() => {
    const config = getWebDavConfig();
    return { baseUrl: config.baseUrl, username: config.username, password: getWebDavPassword() };
  });
  const [cloudStatus, setCloudStatus] = useState<CloudStatus | null>(null);
  const [cloudBusy, setCloudBusy] = useState(false);
  const [cloudError, setCloudError] = useState<string | null>(null);
  const [restoreStrategy, setRestoreStrategy] = useState<'keep-both' | 'prefer-local' | 'prefer-remote'>(
    'keep-both'
  );
  const [restoreSummary, setRestoreSummary] = useState<string | null>(null);
  const [notificationsOn, setNotificationsOn] = useState(false);
  const [journalPending, setJournalPending] = useState(() => loadBackupJournal());
  const projectIdRef = useRef(project.id);
  projectIdRef.current = project.id;

  useEffect(() => {
    const unsubscribe = backgroundTaskManager.subscribe(setTasks);
    return unsubscribe;
  }, []);

  // Tick once a second so "elapsed" stays live while a task runs.
  useEffect(() => {
    if (!isOpen) return;
    const timer = setInterval(() => setTasks(backgroundTaskManager.getTasks()), 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  const refreshCloudStatus = async () => {
    const provider = getActiveCloudProvider();
    if (!provider) {
      setCloudStatus(null);
      return;
    }
    setCloudBusy(true);
    setCloudError(null);
    try {
      setCloudStatus(await provider.getStatus());
    } catch (error) {
      setCloudError(error instanceof Error ? error.message : String(error));
    } finally {
      setCloudBusy(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    void refreshCloudStatus();
    setJournalPending(loadBackupJournal());
  }, [isOpen, providerChoice]);

  // Backup handler: one implementation serves BACKUP and SYNC tasks.
  useEffect(() => {
    const handler = async (
      task: BackgroundTask,
      ctx: { signal: AbortSignal; update: (patch: { progress?: number; message?: string }) => void }
    ) => {
      const provider = getActiveCloudProvider();
      if (!provider) {
        throw new Error('Configura Google Drive o WebDAV antes de respaldar.');
      }
      const result = await runBackup({
        provider,
        signal: ctx.signal,
        fresh: task.metadata?.fresh === true,
        onProgress: (progress) => {
          const percent = progress.total > 0 ? (progress.completed / progress.total) * 100 : 5;
          ctx.update({ progress: percent, message: progress.message });
        },
      });
      ctx.update({
        progress: 100,
        message: `${result.uploadedCount} archivo(s) subido(s), ${result.dedupedCount} ya existían, ${result.missingCount} sin binario local. ${
          result.unverifiedCount > 0
            ? `${result.unverifiedCount} sin hash del proveedor (verificados por tamaño).`
            : 'Integridad MD5 verificada.'
        }`,
      });
      await refreshCloudStatus();
      setJournalPending(loadBackupJournal());
    };

    backgroundTaskManager.registerHandler('BACKUP', handler);
    backgroundTaskManager.registerHandler('SYNC', handler);

    backgroundTaskManager.registerHandler('RESTORE', async (task, ctx) => {
      const provider = getActiveCloudProvider();
      if (!provider) throw new Error('Configura Google Drive o WebDAV antes de restaurar.');
      const strategy =
        (task.metadata?.strategy as 'keep-both' | 'prefer-local' | 'prefer-remote' | undefined) ??
        'keep-both';
      const result = await restoreFromBackup({
        provider,
        strategy,
        signal: ctx.signal,
        onProgress: (progress) => {
          ctx.update({
            progress: progress.total > 0 ? (progress.completed / progress.total) * 100 : 5,
            message: progress.message,
          });
        },
      });

      const restoredCurrent = await getProjectFromStorage(projectIdRef.current);
      if (restoredCurrent) onProjectRestored(restoredCurrent);

      const conflictText =
        result.conflicts.length > 0
          ? ` ${result.conflicts.length} conflicto(s) resueltos sin sobrescribir trabajo reciente.`
          : '';
      setRestoreSummary(
        `${result.projectsRestored} proyecto(s) y ${result.assetsRestored} medio(s) restaurados.${conflictText}${
          result.missingAssets > 0 ? ` ${result.missingAssets} medio(s) no encontrados en la nube.` : ''
        }`
      );
      ctx.update({ progress: 100, message: 'Restauración completada.' });
    });
  }, [onProjectRestored]);

  const pendingCount = useMemo(
    () => tasks.filter((task) => task.status === 'queued' || task.status === 'running').length,
    [tasks]
  );

  const handleConnect = async () => {
    const provider = getActiveCloudProvider();
    if (!provider) {
      setCloudError('Selecciona primero un proveedor de nube.');
      return;
    }
    setCloudBusy(true);
    setCloudError(null);
    try {
      const status = await provider.connect();
      setCloudStatus(status);
    } catch (error) {
      if (error instanceof CloudAuthRequiredError) {
        if (error.authorizationUrl) {
          // Full redirect: the implicit flow returns with the token in the URL
          // fragment, which is consumed on the next load.
          window.location.assign(error.authorizationUrl);
          return;
        }
        setCloudError(error.message);
      } else {
        setCloudError(error instanceof Error ? error.message : String(error));
      }
      await refreshCloudStatus();
    } finally {
      setCloudBusy(false);
    }
  };

  const startBackup = (fresh: boolean) => {
    const provider = getActiveCloudProvider();
    if (!provider) {
      setCloudError('Configura y conecta un proveedor de nube para respaldar.');
      return;
    }
    backgroundTaskManager.enqueue({
      kind: 'BACKUP',
      label: `Respaldo en ${provider.label}`,
      metadata: { fresh },
      maxAttempts: 2,
    });
  };

  const startRestore = () => {
    const provider = getActiveCloudProvider();
    if (!provider) {
      setCloudError('Configura y conecta un proveedor de nube para restaurar.');
      return;
    }
    setRestoreSummary(null);
    backgroundTaskManager.enqueue({
      kind: 'RESTORE',
      label: `Restaurar desde ${provider.label}`,
      metadata: { strategy: restoreStrategy },
      maxAttempts: 1,
    });
  };

  if (!isOpen) return null;

  const quota = cloudStatus?.quota;
  const quotaPercent =
    quota && quota.totalBytes ? Math.min(100, (quota.usedBytes / quota.totalBytes) * 100) : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex justify-end" role="dialog" aria-label="Actividad y nube">
      <div className="bg-slate-900 border-l border-slate-800 w-full sm:max-w-md h-full overflow-y-auto">
        <div className="sticky top-0 bg-slate-900/95 backdrop-blur border-b border-slate-800 px-4 py-3 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-indigo-400" />
            <div>
              <h3 className="text-sm font-bold text-slate-100">Actividad y Nube</h3>
              <p className="text-[10px] text-slate-500">
                {pendingCount > 0 ? `${pendingCount} tarea(s) activa(s)` : 'Sin tareas pendientes'}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1" aria-label="Cerrar">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-5">
          {/* Quick actions */}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={onSaveNow}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded-lg flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" /> Guardar ahora
            </button>
            <button
              onClick={() => startBackup(true)}
              className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] rounded-lg flex items-center gap-1.5"
            >
              <UploadCloud className="w-3.5 h-3.5" /> Respaldar ahora
            </button>
            <button
              onClick={startRestore}
              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded-lg flex items-center gap-1.5"
            >
              <DownloadCloud className="w-3.5 h-3.5" /> Restaurar
            </button>
            <select
              value={restoreStrategy}
              onChange={(event) =>
                setRestoreStrategy(event.target.value as 'keep-both' | 'prefer-local' | 'prefer-remote')
              }
              className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-[10px] text-slate-300"
              title="Resolución de conflictos al restaurar"
            >
              <option value="keep-both">Conflicto: conservar ambos</option>
              <option value="prefer-local">Conflicto: priorizar local</option>
              <option value="prefer-remote">Conflicto: priorizar nube</option>
            </select>
            <button
              onClick={async () => {
                const granted = await backgroundTaskManager.enableNotifications();
                setNotificationsOn(granted);
              }}
              className={`px-2.5 py-1.5 text-[11px] rounded-lg flex items-center gap-1.5 ${
                notificationsOn
                  ? 'bg-emerald-900/50 text-emerald-300'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              <Bell className="w-3.5 h-3.5" /> {notificationsOn ? 'Avisos activos' : 'Activar avisos'}
            </button>
          </div>

          {journalPending && (
            <div className="text-[10px] text-amber-300 bg-amber-950/30 border border-amber-900/70 rounded-lg px-2.5 py-2 space-y-1">
              <p>
                Hay un respaldo sin terminar ({new Date(journalPending.updatedAt).toLocaleString()}).
                Al respaldar se reanudará desde el último archivo completado.
              </p>
              <button
                onClick={() => {
                  clearBackupJournal();
                  setJournalPending(null);
                }}
                className="text-amber-200 underline flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" /> Descartar progreso del respaldo
              </button>
            </div>
          )}

          {restoreSummary && (
            <div className="text-[11px] text-emerald-300 bg-emerald-950/40 border border-emerald-900/70 rounded-lg px-2.5 py-2 flex gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {restoreSummary}
            </div>
          )}

          {/* Cloud configuration */}
          <section className="space-y-2">
            <h4 className="text-[11px] font-semibold uppercase tracking-wide text-slate-300 flex items-center gap-1.5">
              <Cloud className="w-3.5 h-3.5 text-sky-400" /> Almacenamiento en la nube
            </h4>
            <select
              value={providerChoice}
              onChange={(event) => {
                const choice = event.target.value as CloudProviderChoice;
                setProviderChoice(choice);
                setCloudProviderChoice(choice);
                setCloudError(null);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-[11px] text-slate-200"
            >
              <option value="none">Solo local (sin nube)</option>
              <option value="google-drive">Google Drive (OAuth, 15 GB gratuitos compartidos)</option>
              <option value="webdav">WebDAV (Nextcloud, Koofr, NAS...)</option>
            </select>

            {providerChoice === 'google-drive' && (
              <div className="space-y-1.5 bg-slate-950 border border-slate-800 rounded-lg p-2.5">
                <label className="block text-[10px] text-slate-500">
                  Client ID OAuth (Google Cloud → Credenciales → ID de cliente web)
                  <input
                    value={drive.clientId}
                    onChange={(event) => setDrive({ ...drive, clientId: event.target.value })}
                    onBlur={() => setGoogleDriveConfig({ clientId: drive.clientId })}
                    placeholder="xxxxx.apps.googleusercontent.com"
                    className="mt-1 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] font-mono text-slate-200"
                  />
                </label>
                <label className="block text-[10px] text-slate-500">
                  Carpeta en Drive
                  <input
                    value={drive.folderName}
                    onChange={(event) => setDrive({ ...drive, folderName: event.target.value })}
                    onBlur={() => setGoogleDriveConfig({ folderName: drive.folderName })}
                    className="mt-1 w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                  />
                </label>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  Añade este origen como URI de redirección autorizado:{' '}
                  <code className="text-slate-400">{window.location.origin + window.location.pathname}</code>
                  . Alcance usado: <code>drive.file</code> (solo archivos creados por esta app).
                </p>
              </div>
            )}

            {providerChoice === 'webdav' && (
              <div className="space-y-1.5 bg-slate-950 border border-slate-800 rounded-lg p-2.5">
                <input
                  value={webdav.baseUrl}
                  onChange={(event) => setWebdav({ ...webdav, baseUrl: event.target.value })}
                  onBlur={() => setWebDavConfig({ baseUrl: webdav.baseUrl })}
                  placeholder="https://mi-nube.com/remote.php/dav/files/usuario"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] font-mono text-slate-200"
                />
                <div className="grid grid-cols-2 gap-1.5">
                  <input
                    value={webdav.username}
                    onChange={(event) => setWebdav({ ...webdav, username: event.target.value })}
                    onBlur={() => setWebDavConfig({ username: webdav.username })}
                    placeholder="usuario"
                    className="bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                  />
                  <input
                    type="password"
                    value={webdav.password}
                    onChange={(event) => setWebdav({ ...webdav, password: event.target.value })}
                    onBlur={() => setWebDavPassword(webdav.password)}
                    placeholder="contraseña de aplicación"
                    className="bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200"
                  />
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  La contraseña solo se guarda en esta sesión del navegador. La reanudación de una
                  subida a medias no está soportada por WebDAV: se reintenta desde el inicio.
                </p>
              </div>
            )}

            {providerChoice !== 'none' && (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleConnect}
                  disabled={cloudBusy}
                  className="px-2.5 py-1.5 bg-sky-700 hover:bg-sky-600 text-white text-[11px] rounded-lg flex items-center gap-1.5 disabled:opacity-50"
                >
                  {cloudBusy ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Cloud className="w-3.5 h-3.5" />
                  )}
                  {cloudStatus?.connected ? 'Reconectar / actualizar' : 'Conectar'}
                </button>
                <button
                  onClick={refreshCloudStatus}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] rounded-lg"
                >
                  Actualizar estado
                </button>
              </div>
            )}

            {cloudStatus && (
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-[11px] space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Estado</span>
                  <span className={cloudStatus.connected ? 'text-emerald-400' : 'text-amber-400'}>
                    {cloudStatus.connected ? 'Conectado' : 'Sin conexión'}
                  </span>
                </div>
                {cloudStatus.accountLabel && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Cuenta</span>
                    <span className="text-slate-200 truncate max-w-[190px]">
                      {cloudStatus.accountLabel}
                    </span>
                  </div>
                )}
                {quota && (
                  <>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1">
                        <HardDrive className="w-3 h-3" /> Cuota
                      </span>
                      <span className="text-slate-200 font-mono">
                        {formatBytes(quota.usedBytes)}
                        {quota.totalBytes ? ` / ${formatBytes(quota.totalBytes)}` : ' usados'}
                      </span>
                    </div>
                    {quotaPercent !== null && (
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${quotaPercent > 90 ? 'bg-rose-500' : 'bg-sky-500'}`}
                          style={{ width: `${quotaPercent}%` }}
                        />
                      </div>
                    )}
                  </>
                )}
                {cloudStatus.detail && (
                  <p className="text-[10px] text-slate-500">{cloudStatus.detail}</p>
                )}
                {cloudStatus.lastError && (
                  <p className="text-[10px] text-rose-400">{cloudStatus.lastError}</p>
                )}
              </div>
            )}

            {cloudError && (
              <div className="text-[10px] text-rose-300 bg-rose-950/40 border border-rose-900/70 rounded-lg px-2.5 py-2 flex gap-1.5">
                <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" /> {cloudError}
              </div>
            )}

            {/* Documented limitations, not marketing copy. */}
            <details className="text-[10px] text-slate-500">
              <summary className="cursor-pointer text-slate-400">Límites del proveedor</summary>
              <ul className="mt-1 space-y-1 list-disc pl-4">
                {providerChoice === 'google-drive' ? (
                  <>
                    <li>15 GB gratuitos compartidos entre Drive, Gmail y Fotos; se consulta a la API.</li>
                    <li>Requiere Client ID propio; el token dura ~1 hora y no se guarda en disco.</li>
                    <li>La app solo accede a los archivos que ella misma crea (drive.file).</li>
                  </>
                ) : providerChoice === 'webdav' ? (
                  <>
                    <li>La cuota depende del servidor; solo se muestra si soporta RFC 4331.</li>
                    <li>Sin reanudación a mitad de archivo.</li>
                    <li>Usa contraseña de aplicación, no la contraseña principal.</li>
                  </>
                ) : (
                  <li>La nube es opcional: todo funciona y se guarda en IndexedDB.</li>
                )}
              </ul>
            </details>
          </section>

          {/* Task queue */}
          <section className="space-y-2">
            <h4 className="text-[11px] font-semibold uppercase tracking-wide text-slate-300 flex items-center justify-between">
              <span>Cola de trabajos</span>
              <button
                onClick={() => backgroundTaskManager.clearFinished()}
                className="text-[10px] text-slate-500 hover:text-slate-300 normal-case font-normal"
              >
                Limpiar terminadas
              </button>
            </h4>

            {tasks.length === 0 && (
              <p className="text-[11px] text-slate-500">
                Sin trabajos todavía. Exportaciones, respaldos y restauraciones aparecen aquí.
              </p>
            )}

            <div className="space-y-1.5">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  className={`border rounded-lg px-2.5 py-2 text-[11px] space-y-1.5 ${statusColor(task.status)}`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-semibold leading-tight">{task.label}</span>
                    <span className="font-mono text-[10px] shrink-0">{STATUS_LABELS[task.status]}</span>
                  </div>

                  {(task.status === 'running' || task.status === 'queued') && (
                    <div className="w-full bg-slate-950/70 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-sky-400 h-full transition-all"
                        style={{ width: `${task.progress}%` }}
                      />
                    </div>
                  )}

                  <div className="flex items-center justify-between gap-2 text-[10px] text-slate-400">
                    <span className="truncate">
                      {task.message || `${task.progress}%`}
                      {task.error ? ` · ${task.error}` : ''}
                    </span>
                    <span className="font-mono shrink-0">{elapsedLabel(task)}</span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] text-slate-500">
                      {task.requiresAppOpen
                        ? 'Requiere la app abierta'
                        : 'Puede continuar en segundo plano'}
                      {task.attempts > 1 ? ` · intento ${task.attempts}/${task.maxAttempts}` : ''}
                    </span>
                    <div className="flex items-center gap-1">
                      {task.status === 'running' && (
                        <>
                          <button
                            onClick={() => backgroundTaskManager.pause(task.id)}
                            title="Pausar"
                            className="p-1 rounded bg-slate-800/80 text-slate-300"
                          >
                            <Pause className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => backgroundTaskManager.cancel(task.id)}
                            title="Cancelar"
                            className="p-1 rounded bg-slate-800/80 text-rose-300"
                          >
                            <Ban className="w-3 h-3" />
                          </button>
                        </>
                      )}
                      {task.status === 'queued' && (
                        <button
                          onClick={() => backgroundTaskManager.cancel(task.id)}
                          title="Cancelar"
                          className="p-1 rounded bg-slate-800/80 text-rose-300"
                        >
                          <Ban className="w-3 h-3" />
                        </button>
                      )}
                      {(task.status === 'paused' ||
                        task.status === 'interrupted' ||
                        task.status === 'cancelled') && (
                        <button
                          onClick={() => backgroundTaskManager.resume(task.id)}
                          title="Reanudar"
                          className="p-1 rounded bg-slate-800/80 text-emerald-300"
                        >
                          <Play className="w-3 h-3" />
                        </button>
                      )}
                      {task.status === 'failed' && (
                        <button
                          onClick={() => backgroundTaskManager.retry(task.id)}
                          title="Reintentar"
                          className="p-1 rounded bg-slate-800/80 text-amber-300"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <p className="text-[10px] text-slate-500 leading-relaxed border-t border-slate-800 pt-3">
            La exportación y el respaldo corren en esta pestaña: si el sistema suspende la app, el
            trabajo se marca como interrumpido y se puede reanudar al volver. No se promete
            ejecución permanente en segundo plano sin un Worker o servicio nativo.
          </p>
        </div>
      </div>
    </div>
  );
};
