import 'fake-indexeddb/auto';
import { IDBFactory } from 'fake-indexeddb';
import { beforeEach } from 'vitest';

// Provide a fresh, isolated IndexedDB instance before every test so that
// data written by one test cannot leak into another.
beforeEach(() => {
  globalThis.indexedDB = new IDBFactory() as unknown as IDBFactory;
});