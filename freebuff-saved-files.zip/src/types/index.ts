// Domain Core Types for Estudio Audiovisual Inteligente

export type ProjectId = string;

export interface SourceReference {
  id: string;
  title: string;
  url?: string;
  author?: string;
  license: 'CC-BY' | 'CC-BY-SA' | 'Public Domain' | 'Fair Use' | 'Custom / Owned' | 'Unverified';
  evidenceType: 'Fact' | 'Interpretation' | 'Hypothesis' | 'Debunked';
  notes: string;
  verified: boolean;
}

export interface NarrativeAngle {
  id: string;
  title: string;
  hook: string;
  perspective: string;
  criticalQuestions: string[];
  alternativeApproach: string;
}

export interface Scene {
  id: string;
  title: string;
  narrationText: string;
  visualIntent: string; // E.g. "Mostrar gráfico comparativo de datos"
  cameraMotion: 'Static' | 'Zoom In' | 'Zoom Out' | 'Pan Left' | 'Pan Right' | 'Kinetic Text';
  transition: 'Cut' | 'Fade' | 'Slide' | 'Zoom';
  durationSeconds: number;
  imageUrl?: string;
  audioUrl?: string;
  subtitles?: string[];
  notes?: string;
}

export interface MediaFolder {
  id: string;
  name: string;
  parentId?: string;
  createdAt: number;
}

export interface MissingMediaRef {
  assetId: string;
  expectedName: string;
  expectedType: 'image' | 'audio' | 'video';
  affectedClipsCount: number;
  expectedSizeBytes?: number;
  expectedDurationSeconds?: number;
}

export interface MediaAsset {
  id: string;
  name: string;
  type: 'image' | 'audio' | 'video';
  url: string;
  fileBlob?: Blob;
  mimeType: string;
  sizeBytes: number;
  license: string;
  provenance: string;
  createdAt: number;
  // Phase 7E - Technical metadata and organization
  width?: number;
  height?: number;
  durationSeconds?: number;
  aspectRatio?: string;
  thumbnailUrl?: string;
  sha256?: string;
  folderId?: string;
  tags?: string[];
  isMissing?: boolean;
}

export interface ScriptModel {
  title: string;
  summary: string;
  targetAudience: string;
  tone: 'Divulgativo' | 'Riguroso' | 'Dramático' | 'Crítico' | 'Minimalista';
  scenes: Scene[];
}

export type ProjectAspectRatio = '16:9' | '9:16' | '1:1' | '4:5' | '4:3';

/** Visual film grain configuration persisted with the project. */
export interface FilmGrainSettings {
  enabled: boolean;
  /** 0..0.2 (0%..20%). */
  amount: number;
}

export interface SilenceSegment {
  id?: string;
  startMs: number;
  endMs: number;
  durationMs: number;
}

/** How a clip's picture is mapped onto the output frame. */
export type VideoFitMode = 'fit' | 'fill' | 'crop' | 'stretch';

export interface Project {
  id: ProjectId;
  title: string;
  description: string;
  createdAt: number;
  updatedAt: number;
  angles: NarrativeAngle[];
  sources: SourceReference[];
  script: ScriptModel;
  mediaAssets: MediaAsset[];
  settings: {
    fps: number;
    resolution: {
      width: number;
      height: number;
    };
    aspectRatio: ProjectAspectRatio;
    /** Film grain configuration (defaults to enabled at 8%). */
    filmGrain?: FilmGrainSettings;
    /** Flat alias kept for compatibility. */
    filmGrainEnabled?: boolean;
    /** Flat alias kept for compatibility (0..0.2). */
    filmGrainAmount?: number;
  };
  // Phase 7B - Multi-track timeline & professional color/audio extensions
  timeline?: {
    tracks: TimelineTrack[];
    activeTrackId?: string;
    markers?: TimelineMarker[];
  };
  // Phase 7E - Media library folders
  folders?: MediaFolder[];
  // Persistent document schema version (managed by the storage layer)
  schemaVersion?: number;
}

export type TrackType = 'video' | 'audio' | 'text' | 'subtitles';

export interface TimelineClip {
  id: string;
  name: string;
  trackId: string;
  sceneId?: string; // Links to documentary scene if applicable
  assetId?: string; // Links to MediaAsset in IndexedDB
  type: 'video' | 'image' | 'audio' | 'text' | 'caption';
  startMs: number;
  durationMs: number;
  offsetMs: number; // In-point offset within media
  /** Audio/video desync in ms. Positive = J-cut (audio enters first). */
  audioOffset?: number; // -2000..2000
  volume?: number; // 0.0 to 2.0
  speed?: number; // 0.25 to 4.0
  opacity?: number; // 0.0 to 1.0
  transform?: {
    x: number;
    y: number;
    scale: number;
    rotation: number;
  };
  colorAdjustments?: {
    brightness: number; // -1.0 to 1.0
    contrast: number; // 0.0 to 2.0
    saturation: number; // 0.0 to 2.0
    temperature: number; // -100 to 100
    vignette: number; // 0.0 to 1.0
  };
  filterPreset?: 'none' | 'cinematic' | 'documentary-warm' | 'noir' | 'vintage' | 'vivid';
  textPayload?: string;
  isMuted?: boolean;
  isLocked?: boolean;
  // Phase 7F - Transition and Keyframe Animations
  transition?: ClipTransition;
  animations?: ClipAnimation[];
}

// Phase 7F - Transitions & Keyframe Animations System Types
export type TransitionType =
  | 'cut'
  | 'fade'
  | 'crossfade'
  | 'slide-left'
  | 'slide-right'
  | 'slide-up'
  | 'slide-down'
  | 'zoom-in'
  | 'zoom-out'
  | 'wipe-left'
  | 'wipe-right'
  | 'fade-to-black'
  | 'fade-from-black';

export type EasingCurve = 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';

export interface ClipTransition {
  id: string;
  type: TransitionType;
  durationMs: number;
  easing?: EasingCurve;
  fromClipId?: string;
  toClipId?: string;
}

export type KeyframeProperty = 'positionX' | 'positionY' | 'scale' | 'rotation' | 'opacity';

export interface AnimationKeyframe {
  id: string;
  timeOffsetMs: number;
  value: number;
  easing?: EasingCurve;
}

export interface ClipAnimation {
  property: KeyframeProperty;
  keyframes: AnimationKeyframe[];
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: TrackType;
  order: number;
  isMuted: boolean;
  isLocked: boolean;
  isVisible: boolean;
  clips: TimelineClip[];
  transitions?: ClipTransition[];
}

export interface TimelineMarker {
  id: string;
  timeMs: number;
  /** End time for range markers such as detected silences. */
  endMs?: number;
  /** Duration in ms for range markers. */
  durationMs?: number;
  label: string;
  color: 'indigo' | 'emerald' | 'amber' | 'rose' | 'purple';
  /** Marker kind. */
  type?: 'marker' | 'silence';
}

export interface SubtitleCue {
  id: string;
  startMs: number;
  endMs: number;
  text: string;
  speaker?: string;
  isVerified?: boolean;
}

export interface ExportProfile {
  id: string;
  name: string;
  format: 'webm' | 'mp4';
  aspectRatio: ProjectAspectRatio;
  resolution: { width: number; height: number };
  fps: number;
  bitrateBps: number;
  includeAudio: boolean;
  description: string;
}
