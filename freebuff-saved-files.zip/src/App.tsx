// Main Application Shell for Estudio Audiovisual Inteligente
import React, { useState, useEffect, useRef } from 'react';
import { Project } from './types';
import { DEMO_PROJECT } from './data/demoProject';
import {
  saveProjectToStorage,
  getProjectFromStorage,
  getLastActiveProjectId,
  setLastActiveProjectId,
  cleanupOrphanedAssets,
} from './services/storage/db';
import { ProjectAutosaver } from './services/storage/autosave';
import { VideoExporter, ExportResult } from './engine/exporter';
import type { ExportSettings } from './services/export/exportPlan';
import { formatBytes } from './services/export/exportConfig';
import { backgroundTaskManager, type BackgroundTask } from './services/jobs/taskManager';
import { ActivityPanel } from './components/ActivityPanel';
import { initializeCloudAuth } from './services/cloud/providers';
import { IdeaLab } from './modules/IdeaLab';
import { ResearchModule } from './modules/ResearchModule';
import { ScriptWorkshop } from './modules/ScriptWorkshop';
import { StoryboardModule } from './modules/StoryboardModule';
import { MediaLibraryModule } from './modules/MediaLibraryModule';
import { HomeDashboard } from './modules/HomeDashboard';
import { ProductionStudio } from './modules/ProductionStudio';
import { GlobalStatusBar } from './components/GlobalStatusBar';
import { ExportProfilesModal } from './components/ExportProfilesModal';
import { downloadProjectEAI } from './services/storage/projectBackup';
import { refreshMissingAssetMetadata } from './services/media/thumbnailService';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import {
  Home,
  Lightbulb,
  Search,
  FileText,
  Film,
  FolderOpen,
  Download,
  Cpu,
  RefreshCw,
  Smartphone,
  DownloadCloud,
  Sparkles,
  Clapperboard,
  Activity,
} from 'lucide-react';

export const App: React.FC = () => {
  const [project, setProject] = useState<Project>(DEMO_PROJECT);
  const autosaverRef = useRef<ProjectAutosaver | null>(null);
  const lastActiveIdRef = useRef<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    'home' | 'ideas' | 'research' | 'script' | 'storyboard' | 'production' | 'media'
  >('production');
  const [isAIDrawerOpen, setIsAIDrawerOpen] = useState(false);
  const [activeAssistantSceneId, setActiveAssistantSceneId] = useState<string | undefined>(undefined);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isActivityOpen, setIsActivityOpen] = useState(false);
  const [activityTasks, setActivityTasks] = useState<BackgroundTask[]>(() =>
    backgroundTaskManager.getTasks()
  );
  const exportJobRef = useRef<{ settings: ExportSettings; project: Project } | null>(null);

  // Export state
  const [isExporting, setIsExporting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportMessage, setExportMessage] = useState('');
  const [exportResult, setExportResult] = useState<(ExportResult & { url: string }) | null>(null);

  useEffect(() => {
    const autosaver = new ProjectAutosaver({
      save: saveProjectToStorage,
      onStatus: (status, error) => {
        setIsSaving(status === 'saving');
        if (status === 'error') {
          setSaveError(error instanceof Error ? error.message : 'Almacenamiento no disponible');
          console.error('No se pudo autoguardar el proyecto:', error);
        } else if (status !== 'idle') {
          setSaveError(null);
        }
      },
    });
    autosaverRef.current = autosaver;
    let cancelled = false;

    // Restore the last edited project, then the demo project, then create it.
    (async () => {
      try {
        const lastId = await getLastActiveProjectId();
        const lastProject = lastId ? await getProjectFromStorage(lastId) : null;
        const stored = lastProject ?? (await getProjectFromStorage(DEMO_PROJECT.id));

        if (cancelled) return;

        if (stored) {
          setProject(stored);
          lastActiveIdRef.current = stored.id;
          void setLastActiveProjectId(stored.id).catch(() => undefined);
        } else {
          await saveProjectToStorage(DEMO_PROJECT);
          if (cancelled) return;
          setProject(DEMO_PROJECT);
          lastActiveIdRef.current = DEMO_PROJECT.id;
          void setLastActiveProjectId(DEMO_PROJECT.id).catch(() => undefined);
        }

        void cleanupOrphanedAssets().catch((error) =>
          console.warn('No se pudieron limpiar los medios huérfanos:', error)
        );
      } catch (error) {
        console.error('No se pudo recuperar el proyecto guardado:', error);
      }
    })();

    return () => {
      cancelled = true;
      void autosaver.dispose();
    };
  }, []);

  // Rebuild thumbnails and technical metadata for media stored before thumbnails
  // existed (or whose object URL died with the previous session).
  const thumbnailScanRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    const candidates = (project.mediaAssets || []).filter(
      (asset) =>
        (asset.type === 'image' || asset.type === 'video') &&
        !asset.thumbnailUrl &&
        !thumbnailScanRef.current.has(`${project.id}:${asset.id}`)
    );
    if (candidates.length === 0) return;
    candidates.forEach((asset) => thumbnailScanRef.current.add(`${project.id}:${asset.id}`));

    let cancelled = false;
    void refreshMissingAssetMetadata(project)
      .then(({ project: updatedProject, updatedAssetIds }) => {
        if (cancelled || updatedAssetIds.length === 0) return;
        const updatedById = new Map(updatedProject.mediaAssets.map((asset) => [asset.id, asset]));
        setProject((previous) => {
          if (previous.id !== project.id) return previous;
          const merged: Project = {
            ...previous,
            mediaAssets: (previous.mediaAssets || []).map(
              (asset) => updatedById.get(asset.id) ?? asset
            ),
          };
          autosaverRef.current?.schedule(merged);
          return merged;
        });
        console.info(`Metadatos de medios reparados: ${updatedAssetIds.length}.`);
      })
      .catch((error) =>
        console.warn('No se pudieron regenerar las miniaturas de la biblioteca:', error)
      );

    return () => {
      cancelled = true;
    };
  }, [project]);

  // Background work: one registry for the tasks the editor can run.
  useEffect(() => {
    const unsubscribe = backgroundTaskManager.subscribe(setActivityTasks);

    backgroundTaskManager.registerHandler('AUTOSAVE', async (_task, ctx) => {
      ctx.update({ progress: 30, message: 'Guardando el proyecto en IndexedDB...' });
      await autosaverRef.current?.flush();
      ctx.update({ progress: 100, message: 'Proyecto guardado.' });
    });

    backgroundTaskManager.registerHandler('CLEANUP', async (_task, ctx) => {
      ctx.update({ progress: 20, message: 'Buscando medios huérfanos...' });
      const result = await cleanupOrphanedAssets();
      const freed = formatBytes(result.freedBytes);
      ctx.update({
        progress: 100,
        message: `${result.deletedCount} medio(s) eliminados y ${freed} liberados.`,
      });
    });

    backgroundTaskManager.registerHandler('EXPORT', async (_task, ctx) => {
      const job = exportJobRef.current;
      if (!job) throw new Error('No hay una exportación configurada.');
      setIsExporting(true);
      try {
        const result = await VideoExporter.exportProjectVideo(
          job.project,
          (progress, message) => {
            ctx.update({ progress, message });
            setExportProgress(progress);
            setExportMessage(message);
          },
          { settings: job.settings, signal: ctx.signal }
        );
        setExportResult((previous) => {
          if (previous) URL.revokeObjectURL(previous.url);
          return { ...result, url: URL.createObjectURL(result.blob) };
        });
        ctx.update({
          progress: 100,
          message: `Archivo listo: ${result.width}x${result.height} ${result.extension.toUpperCase()} · ${formatBytes(
            result.sizeBytes
          )}`,
        });
      } finally {
        setIsExporting(false);
      }
    });

    // Finish a pending Google OAuth redirect and requeue interrupted work.
    initializeCloudAuth();
    const resumed = backgroundTaskManager.resumeInterrupted();
    if (resumed > 0) console.info(`Se reanudaron ${resumed} tarea(s) interrumpida(s).`);

    return unsubscribe;
  }, []);

  const handleUpdateProject = (updated: Project) => {
    setProject(updated);
    setIsSaving(true);
    autosaverRef.current?.schedule(updated);

    if (lastActiveIdRef.current !== updated.id) {
      lastActiveIdRef.current = updated.id;
      void setLastActiveProjectId(updated.id).catch((error) =>
        console.warn('No se pudo recordar el proyecto activo:', error)
      );
    }
  };

  const handleExportVideo = (settings: ExportSettings) => {
    setExportResult((previous) => {
      if (previous) URL.revokeObjectURL(previous.url);
      return null;
    });
    setExportProgress(0);
    setExportMessage('Preparando la exportación...');
    exportJobRef.current = { settings, project };
    backgroundTaskManager.enqueue({
      kind: 'EXPORT',
      label: `Exportar ${project.title}`,
      requiresAppOpen: true,
      resumable: false,
      maxAttempts: 1,
      metadata: {
        resolutionTier: settings.resolutionTier,
        aspectRatio: settings.aspectRatio,
        fps: settings.fps,
      },
    });
  };

  const activeTaskCount = activityTasks.filter(
    (task) => task.status === 'queued' || task.status === 'running'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* App Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-6 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-lg text-white shadow-lg shadow-indigo-600/30">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-base text-slate-100 leading-tight">
              ESTUDIO AUDIOVISUAL INTELIGENTE
            </h1>
            <p className="text-[11px] text-slate-400 font-mono">
              Producción Local Offline • IA Asistencial
            </p>
          </div>
        </div>

        {/* Global Action Banner */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => downloadProjectEAI(project)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs rounded-lg shadow-sm transition-all"
            title="Descargar copia de seguridad física del proyecto completo (.eai)"
          >
            <DownloadCloud className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Copia .eai</span>
          </button>

          <button
            onClick={() => setIsAIDrawerOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs rounded-lg shadow-md shadow-purple-600/20 transition-all"
            title="Abrir Asistente Central de Inteligencia Artificial (Fase 6C)"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Asistente IA</span>
          </button>

          <a
            href="/app-debug.apk"
            download="app-debug.apk"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-700/80 hover:bg-emerald-600 text-white font-medium text-xs rounded-lg border border-emerald-500/40 shadow-md transition-all"
            title="Descargar paquete instalador Android APK (4.1 MB)"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-300" />
            <span className="hidden sm:inline">APK (4.1 MB)</span>
          </a>

          <button
            onClick={() => setIsActivityOpen(true)}
            className="relative flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs rounded-lg shadow-sm transition-all"
            title="Cola de trabajos, respaldos y nube"
          >
            <Activity className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Actividad</span>
            {activeTaskCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.5 rounded-full bg-sky-600 text-white text-[10px] font-mono">
                {activeTaskCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsExportModalOpen(true)}
            disabled={isExporting}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-semibold text-xs rounded-lg shadow-lg shadow-indigo-600/20 transition-all ${
              isExporting ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {isExporting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
            <span>{isExporting ? 'Renderizando...' : 'Exportar Video'}</span>
          </button>
        </div>
      </header>

      {/* Global Real-time Production Status Bar */}
      <GlobalStatusBar project={project} isSaving={isSaving} saveError={saveError} />

      {/* Workspace Navigation Bar (10 Specialised Workspaces) */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-6 py-2 sticky top-[57px] z-40 backdrop-blur">
        <nav className="flex items-center gap-1.5 overflow-x-auto max-w-[1700px] mx-auto w-full">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'home'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Inicio</span>
          </button>

          <button
            onClick={() => setActiveTab('production')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              activeTab === 'production'
                ? 'bg-indigo-600 text-white shadow ring-1 ring-indigo-400/30'
                : 'text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/40'
            }`}
          >
            <Clapperboard className="w-4 h-4" />
            <span>Producción & Montaje</span>
          </button>

          <button
            onClick={() => setActiveTab('ideas')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'ideas'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Lightbulb className="w-4 h-4" />
            <span>Laboratorio de Ideas</span>
          </button>

          <button
            onClick={() => setActiveTab('research')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'research'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>Investigación</span>
          </button>

          <button
            onClick={() => setActiveTab('script')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'script'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Taller de Guion</span>
          </button>

          <button
            onClick={() => setActiveTab('storyboard')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'storyboard'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Storyboard</span>
          </button>

          <button
            onClick={() => setActiveTab('media')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              activeTab === 'media'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <FolderOpen className="w-4 h-4" />
            <span>Biblioteca</span>
          </button>
        </nav>
      </div>

      {/* Main Workspace Layout */}
      <div className="flex-1 p-5 md:p-6 max-w-[1700px] mx-auto w-full">
        {/* Render Progress or Success Notice if Exporting */}
        {(isExporting || exportResult) && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 mb-5 space-y-3 shadow-lg">
            {isExporting && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-slate-300 font-mono">
                  <span>{exportMessage}</span>
                  <span>{exportProgress}%</span>
                </div>
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="bg-indigo-500 h-full transition-all duration-200"
                    style={{ width: `${exportProgress}%` }}
                  />
                </div>
              </div>
            )}

            {exportResult && !isExporting && (
              <div className="space-y-2">
              <div className="flex items-center justify-between bg-emerald-950/60 border border-emerald-800/80 p-3 rounded-lg">
                <div className="space-y-0.5">
                  <span className="text-xs font-semibold text-emerald-300 block">
                    ¡Video Renderizado con Éxito!
                  </span>
                  <span className="text-[11px] text-emerald-400/80 font-mono">
                    {exportResult.extension.toUpperCase()} {exportResult.width}x{exportResult.height} @{' '}
                    {exportResult.fps} FPS · {(exportResult.blob.size / (1024 * 1024)).toFixed(1)} MB
                    {exportResult.verification?.durationSeconds != null && (
                      <> · {exportResult.verification.durationSeconds.toFixed(1)}s verificados</>
                    )}
                    {exportResult.verification?.audioPeak != null && (
                      <> · audio {exportResult.verification.audioPeak > 0.005 ? 'OK' : 'en silencio'}</>
                    )}
                  </span>
                  {exportResult.verification && !exportResult.verification.ok && (
                    <span className="text-[11px] text-amber-400 block">
                      Verificación con problemas: {exportResult.verification.warnings.join(' ')}
                    </span>
                  )}
                  {exportResult.containerFallback && (
                    <span className="text-[11px] text-amber-400 block">
                      El navegador rechazó el contenedor solicitado; el archivo real es{' '}
                      {exportResult.mimeType}.
                    </span>
                  )}
                </div>

                <a
                  href={exportResult.url}
                  download={`${project.title.toLowerCase().replace(/\s+/g, '-')}-${exportResult.height}p.${exportResult.extension}`}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-lg transition-colors shadow flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Descargar Archivo</span>
                </a>
              </div>
              <video
                controls
                preload="metadata"
                src={exportResult.url}
                className="w-full max-h-72 rounded-lg border border-slate-800 bg-black"
              />
              </div>
            )}
          </div>
        )}

        {/* Tab Views */}
        <div>
          {activeTab === 'home' && (
            <HomeDashboard
              currentProject={project}
              onSelectProject={handleUpdateProject}
              onNewProject={() => {
                const newProj: Project = {
                  ...DEMO_PROJECT,
                  id: `proj-${Date.now()}`,
                  title: 'Nuevo Proyecto Audiovisual',
                  description: 'Inicia tu investigación y desglose narrativo.',
                  createdAt: Date.now(),
                  updatedAt: Date.now(),
                };
                handleUpdateProject(newProj);
                setActiveTab('production');
              }}
              onOpenProjectEditor={() => setActiveTab('production')}
            />
          )}

          {activeTab === 'production' && (
            <ProductionStudio
              project={project}
              onUpdateProject={handleUpdateProject}
              onRequestExportModal={() => setIsExportModalOpen(true)}
            />
          )}

          {activeTab === 'ideas' && (
            <IdeaLab
              project={project}
              onUpdateProject={handleUpdateProject}
              onNavigateToScript={() => setActiveTab('production')}
            />
          )}

          {activeTab === 'research' && (
            <ResearchModule project={project} onUpdateProject={handleUpdateProject} />
          )}

          {activeTab === 'script' && (
            <ScriptWorkshop
              project={project}
              onUpdateProject={handleUpdateProject}
              onRequestAIAssist={(sceneId) => {
                setActiveAssistantSceneId(sceneId);
                setIsAIDrawerOpen(true);
              }}
            />
          )}

          {activeTab === 'storyboard' && (
            <StoryboardModule project={project} onUpdateProject={handleUpdateProject} />
          )}

          {activeTab === 'media' && (
            <MediaLibraryModule project={project} onUpdateProject={handleUpdateProject} />
          )}
        </div>
      </div>

      {/* Export Profiles Modal (Phase 7B) */}
      <ExportProfilesModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        project={project}
        isExporting={isExporting}
        onUpdateProject={handleUpdateProject}
        onStartExport={(settings) => {
          setIsExportModalOpen(false);
          handleExportVideo(settings);
        }}
      />

      <ActivityPanel
        isOpen={isActivityOpen}
        onClose={() => setIsActivityOpen(false)}
        project={project}
        onProjectRestored={(restored) => {
          setProject(restored);
          lastActiveIdRef.current = restored.id;
          void setLastActiveProjectId(restored.id).catch(() => undefined);
        }}
        onSaveNow={() => {
          backgroundTaskManager.enqueue({
            kind: 'AUTOSAVE',
            label: 'Guardar proyecto ahora',
            resumable: false,
            maxAttempts: 2,
          });
        }}
      />

      {/* Global AI Assistant Drawer */}
      <AIAssistantDrawer
        isOpen={isAIDrawerOpen}
        onClose={() => setIsAIDrawerOpen(false)}
        project={project}
        currentSceneId={activeAssistantSceneId}
        onApplyResult={(task, data) => {
          if (task === 'EXPAND_SCENE_NARRATION' && data?.expandedNarration && activeAssistantSceneId) {
            const updatedScenes = project.script.scenes.map((s) =>
              s.id === activeAssistantSceneId ? { ...s, narrationText: data.expandedNarration } : s
            );
            handleUpdateProject({
              ...project,
              script: { ...project.script, scenes: updatedScenes },
            });
            setIsAIDrawerOpen(false);
          }
        }}
      />
    </div>
  );
};
