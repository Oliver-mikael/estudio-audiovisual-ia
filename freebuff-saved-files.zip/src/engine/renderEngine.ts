// Canvas 2D Render Engine for Estudio Audiovisual Inteligente
// Composites real timeline media (images and videos from IndexedDB) across tracks,
// applying transform/keyframe animation, opacity, color grading, transitions and text.

import { Scene, Project, TimelineClip, TimelineTrack, MediaAsset, VideoFitMode } from '../types';
import { KeyframeEngine } from '../services/animation/keyframeEngine';
import { TransitionEngine } from '../services/animation/transitionEngine';
import { getMediaAssetBlob } from '../services/storage/db';
import {
  buildClipFilter,
  clamp,
  getActiveTextClips,
  getActiveVisualClips,
  getClipLocalTimeMs,
  getClipProgress,
  getClipVisualTransform,
  getClipVignette,
  getFilmGrainSettings,
  getSceneForClip,
  getVisualTracks,
} from './mediaComposition';

export interface RenderState {
  currentTime: number; // in seconds
  isPlaying: boolean;
}

export interface PreloadMediaResult {
  loadedCount: number;
  failedAssetIds: string[];
}

interface MediaEntry {
  kind: 'image' | 'video';
  image?: HTMLImageElement;
  video?: HTMLVideoElement;
  objectUrl?: string;
  assetId: string;
}

const VIDEO_SEEK_TIMEOUT_MS = 600;

/**
 * Bridge that lets the render engine hand its video elements to the audio mixer,
 * so a video clip's own soundtrack is exported along with the timeline audio.
 */
export interface VideoAudioRouter {
  attach(element: HTMLVideoElement, assetId: string): void;
  setGain(assetId: string, gain: number): void;
}

/** JSON round-trips turn Blobs into {}, so only real Blob instances are usable. */
function toRealBlob(value: unknown): Blob | null {
  return typeof Blob !== 'undefined' && value instanceof Blob ? value : null;
}

export interface CompositionSettings {
  /** How the source picture is mapped onto the output frame. */
  fitMode: VideoFitMode;
  /** 0..1 focus point used by fill/crop to reframe the picture. */
  framing: { x: number; y: number };
}

export const DEFAULT_COMPOSITION: CompositionSettings = {
  fitMode: 'fill',
  framing: { x: 0.5, y: 0.5 },
};

export interface RenderEngineOptions {
  /** Export resolution override; without it frames use the project resolution. */
  width?: number;
  height?: number;
  /** Output framing; preview uses the default fill/center composition. */
  composition?: CompositionSettings;
}

export class CanvasRenderEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private imageCache: Map<string, HTMLImageElement> = new Map();
  private mediaCache: Map<string, MediaEntry> = new Map();
  private scratchCanvasA: HTMLCanvasElement | null = null;
  private scratchCanvasB: HTMLCanvasElement | null = null;
  private renderWidth?: number;
  private renderHeight?: number;
  private videoAudioRouter: VideoAudioRouter | null = null;
  private composition: CompositionSettings = DEFAULT_COMPOSITION;
  private filmGrainCanvas: HTMLCanvasElement | null = null;
  private filmGrainCanvasKey: string | null = null;

  constructor(canvas: HTMLCanvasElement, options: RenderEngineOptions = {}) {
    this.canvas = canvas;
    this.renderWidth = options.width;
    this.renderHeight = options.height;
    if (options.composition) this.composition = options.composition;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Could not get 2D context from canvas');
    }
    this.ctx = context;
  }

  /**
   * Changes how source pictures are mapped onto the export frame (fit/fill/crop/
   * stretch plus a reframing focus point) without altering the project.
   */
  public setComposition(composition: CompositionSettings): void {
    this.composition = {
      fitMode: composition.fitMode,
      framing: {
        x: clamp(composition.framing?.x ?? 0.5, 0, 1),
        y: clamp(composition.framing?.y ?? 0.5, 0, 1),
      },
    };
  }

  public getComposition(): CompositionSettings {
    return { fitMode: this.composition.fitMode, framing: { ...this.composition.framing } };
  }

  /**
   * Size used for compositing. An explicit export override wins over the project
   * resolution so 1080p/vertical profiles are not resized back to 720p mid-render.
   */
  private getRenderSize(project: Project): { width: number; height: number } {
    return {
      width: this.renderWidth ?? project.settings.resolution.width,
      height: this.renderHeight ?? project.settings.resolution.height,
    };
  }

  private getScratchCanvases(width: number, height: number): [HTMLCanvasElement, HTMLCanvasElement] {
    if (!this.scratchCanvasA) {
      this.scratchCanvasA = document.createElement('canvas');
    }
    if (!this.scratchCanvasB) {
      this.scratchCanvasB = document.createElement('canvas');
    }
    if (this.scratchCanvasA.width !== width || this.scratchCanvasA.height !== height) {
      this.scratchCanvasA.width = width;
      this.scratchCanvasA.height = height;
    }
    if (this.scratchCanvasB.width !== width || this.scratchCanvasB.height !== height) {
      this.scratchCanvasB.width = width;
      this.scratchCanvasB.height = height;
    }
    return [this.scratchCanvasA, this.scratchCanvasB];
  }

  public async preloadImages(scenes: Scene[]): Promise<void> {
    const promises = scenes.map((scene) => {
      if (scene.imageUrl && !this.imageCache.has(scene.imageUrl)) {
        return new Promise<void>((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            this.imageCache.set(scene.imageUrl!, img);
            resolve();
          };
          img.onerror = () => {
            // Silently fallback if image fails to load
            resolve();
          };
          img.src = scene.imageUrl!;
        });
      }
      return Promise.resolve();
    });

    await Promise.all(promises);
  }

  /**
   * Resolves every visual asset referenced by timeline clips, reading binaries from
   * the project (File/Blob) or IndexedDB when object URLs are stale or missing.
   */
  public async preloadProjectMedia(project: Project): Promise<PreloadMediaResult> {
    await this.preloadImages(project.script?.scenes || []);

    const assetIds = new Set<string>();
    for (const track of project.timeline?.tracks || []) {
      if (track.type !== 'video' && track.type !== 'text' && track.type !== 'subtitles') continue;
      for (const clip of track.clips) {
        if (clip.assetId) assetIds.add(clip.assetId);
      }
    }

    // Release media that no clip references anymore so long sessions do not
    // retain every imported video in memory.
    for (const [assetId, entry] of this.mediaCache) {
      if (assetIds.has(assetId)) continue;
      if (entry.video) {
        entry.video.pause();
        entry.video.removeAttribute('src');
        entry.video.load();
      }
      if (entry.objectUrl) URL.revokeObjectURL(entry.objectUrl);
      this.mediaCache.delete(assetId);
    }

    const failedAssetIds: string[] = [];
    let loadedCount = 0;

    for (const assetId of assetIds) {
      if (this.mediaCache.has(assetId)) {
        loadedCount++;
        continue;
      }

      const projectAsset = (project.mediaAssets || []).find((a) => a.id === assetId);
      const projectBlob = toRealBlob(projectAsset?.fileBlob);
      let storedAsset: MediaAsset | null = null;
      if (!projectBlob) {
        try {
          storedAsset = await getMediaAssetBlob(assetId);
        } catch {
          storedAsset = null;
        }
      }

      const asset = projectAsset || storedAsset;
      const blob = projectBlob || toRealBlob(storedAsset?.fileBlob);
      const sourceUrl = blob ? URL.createObjectURL(blob) : asset?.url;

      if (!sourceUrl) {
        failedAssetIds.push(assetId);
        continue;
      }

      const isVideo =
        asset?.type === 'video' ||
        (asset?.mimeType || '').startsWith('video/');

      const entry = isVideo
        ? await this.loadVideoEntry(assetId, sourceUrl, Boolean(blob))
        : await this.loadImageEntry(assetId, sourceUrl, Boolean(blob));

      if (entry) {
        this.mediaCache.set(assetId, entry);
        loadedCount++;
      } else {
        failedAssetIds.push(assetId);
      }
    }

    return { loadedCount, failedAssetIds };
  }

  private loadImageEntry(
    assetId: string,
    sourceUrl: string,
    isObjectUrl: boolean
  ): Promise<MediaEntry | null> {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      const finish = (success: boolean) => {
        if (success) {
          resolve({ kind: 'image', image: img, objectUrl: isObjectUrl ? sourceUrl : undefined, assetId });
        } else {
          if (isObjectUrl) URL.revokeObjectURL(sourceUrl);
          resolve(null);
        }
      };
      img.onload = () => finish(true);
      img.onerror = () => finish(false);
      img.src = sourceUrl;
    });
  }

  private loadVideoEntry(
    assetId: string,
    sourceUrl: string,
    isObjectUrl: boolean
  ): Promise<MediaEntry | null> {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'auto';
      video.muted = true;
      video.playsInline = true;
      video.crossOrigin = 'anonymous';

      let settled = false;
      const complete = (success: boolean) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        if (success) {
          this.videoAudioRouter?.attach(video, assetId);
          resolve({
            kind: 'video',
            video,
            objectUrl: isObjectUrl ? sourceUrl : undefined,
            assetId,
          });
        } else {
          if (isObjectUrl) URL.revokeObjectURL(sourceUrl);
          resolve(null);
        }
      };

      const timeout = window.setTimeout(() => complete(video.readyState >= 1), 4000);
      video.onloadeddata = () => complete(true);
      video.onerror = () => complete(false);
      video.src = sourceUrl;
      video.load();
    });
  }

  /**
   * Enables (or disables) mixing of the embedded audio of video clips.
   * Already loaded videos are attached immediately; later ones on load.
   */
  public setVideoAudioRouter(router: VideoAudioRouter | null): void {
    this.videoAudioRouter = router;
    if (!router) return;
    for (const entry of this.mediaCache.values()) {
      if (entry.kind === 'video' && entry.video) router.attach(entry.video, entry.assetId);
    }
  }

  private getMediaEntry(assetId?: string): MediaEntry | null {
    if (!assetId) return null;
    return this.mediaCache.get(assetId) || null;
  }

  /**
   * Returns a drawable source for a clip: resolved asset media, or the legacy
   * scene image for scene-backed clips without an asset.
   */
  private getClipDrawable(clip: TimelineClip, scene?: Scene): CanvasImageSource | null {
    const entry = this.getMediaEntry(clip.assetId);
    if (entry) {
      if (entry.kind === 'image' && entry.image) return entry.image;
      if (entry.video && entry.video.readyState >= 2) return entry.video;
      return null;
    }

    if (!clip.assetId && scene?.imageUrl) {
      return this.imageCache.get(scene.imageUrl) || null;
    }

    return null;
  }

  private getDrawableSize(drawable: CanvasImageSource): { width: number; height: number } {
    const isVideo =
      typeof HTMLVideoElement !== 'undefined' && drawable instanceof HTMLVideoElement;
    if (isVideo) {
      const video = drawable as HTMLVideoElement;
      return { width: video.videoWidth, height: video.videoHeight };
    }
    const image = drawable as HTMLImageElement;
    return { width: image.naturalWidth || image.width, height: image.naturalHeight || image.height };
  }

  /**
   * Maps the source onto the frame according to the export composition:
   * - fit: whole picture visible, letterboxed.
   * - fill: fills the frame, overflow centered/reframed with the focus point.
   * - crop: source window cut to the output aspect at the focus point.
   * - stretch: fills the frame ignoring the source ratio.
   */
  private drawDrawable(
    ctx: CanvasRenderingContext2D,
    drawable: CanvasImageSource,
    width: number,
    height: number
  ): void {
    const { width: sourceWidth, height: sourceHeight } = this.getDrawableSize(drawable);
    if (!sourceWidth || !sourceHeight) return;

    const { fitMode, framing } = this.composition;
    const sourceRatio = sourceWidth / sourceHeight;
    const canvasRatio = width / height;

    if (fitMode === 'stretch') {
      ctx.drawImage(drawable, -width / 2, -height / 2, width, height);
      return;
    }

    if (fitMode === 'fit') {
      let drawW = width;
      let drawH = height;
      if (sourceRatio > canvasRatio) {
        drawH = width / sourceRatio;
      } else {
        drawW = height * sourceRatio;
      }
      ctx.drawImage(drawable, -drawW / 2, -drawH / 2, drawW, drawH);
      return;
    }

    if (fitMode === 'crop') {
      let cropW = sourceWidth;
      let cropH = sourceHeight;
      if (sourceRatio > canvasRatio) {
        cropW = sourceHeight * canvasRatio;
      } else {
        cropH = sourceWidth / canvasRatio;
      }
      const cropX = Math.max(0, sourceWidth - cropW) * clamp(framing.x, 0, 1);
      const cropY = Math.max(0, sourceHeight - cropH) * clamp(framing.y, 0, 1);
      ctx.drawImage(
        drawable,
        cropX,
        cropY,
        cropW,
        cropH,
        -width / 2,
        -height / 2,
        width,
        height
      );
      return;
    }

    // fill: cover the frame, shifting the overflow with the reframing focus.
    let drawW = width;
    let drawH = height;
    if (sourceRatio > canvasRatio) {
      drawW = height * sourceRatio;
    } else {
      drawH = width / sourceRatio;
    }
    const offsetX = -(drawW - width) * (clamp(framing.x, 0, 1) - 0.5);
    const offsetY = -(drawH - height) * (clamp(framing.y, 0, 1) - 0.5);
    ctx.drawImage(drawable, -drawW / 2 + offsetX, -drawH / 2 + offsetY, drawW, drawH);
  }

  private drawVignette(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    strength: number
  ): void {
    if (strength <= 0) return;
    const gradient = ctx.createRadialGradient(
      width / 2,
      height / 2,
      Math.min(width, height) * 0.35,
      width / 2,
      height / 2,
      Math.max(width, height) * 0.72
    );
    gradient.addColorStop(0, 'rgba(0,0,0,0)');
    gradient.addColorStop(1, `rgba(0,0,0,${clamp(strength, 0, 0.9).toFixed(3)})`);
    ctx.save();
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    ctx.restore();
  }

  private drawClipFrame(
    ctx: CanvasRenderingContext2D,
    project: Project,
    clip: TimelineClip,
    timeMs: number,
    width: number,
    height: number
  ): void {
    const scene = getSceneForClip(project, clip);
    const localMs = getClipLocalTimeMs(clip, timeMs);
    const progress = getClipProgress(clip, timeMs);
    const transform = getClipVisualTransform(clip, localMs);
    const drawable = this.getClipDrawable(clip, scene);

    ctx.save();
    ctx.translate(width / 2 + transform.positionX, height / 2 + transform.positionY);
    if (transform.rotation !== 0) {
      ctx.rotate((transform.rotation * Math.PI) / 180);
    }

    let scale = transform.scale;

    // Procedural camera motion for scene clips without explicit keyframes.
    if ((!clip.animations || clip.animations.length === 0) && scene) {
      if (scene.cameraMotion === 'Zoom In') scale *= 1.0 + progress * 0.15;
      else if (scene.cameraMotion === 'Zoom Out') scale *= 1.15 - progress * 0.15;
      else if (scene.cameraMotion === 'Pan Left') ctx.translate(-progress * 40, 0);
      else if (scene.cameraMotion === 'Pan Right') ctx.translate(progress * 40, 0);
    }

    ctx.scale(scale, scale);
    ctx.globalAlpha = clamp(transform.opacity, 0, 1);
    ctx.filter = buildClipFilter(clip);

    if (drawable) {
      this.drawDrawable(ctx, drawable, width, height);
    } else {
      this.drawFallbackGradient(ctx, width, height, progress);
    }

    ctx.restore();

    const vignette = getClipVignette(clip);
    if (vignette > 0) this.drawVignette(ctx, width, height, vignette);

    // Scene-backed clips keep the original readability overlay of the demo look.
    if (!clip.assetId && scene?.imageUrl) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.65)';
      ctx.fillRect(0, 0, width, height);
    }
  }

  private drawFallbackGradient(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    progress: number
  ): void {
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, '#090d16');
    grad.addColorStop(0.5, '#1e1b4b');
    grad.addColorStop(1, '#0f172a');
    ctx.fillStyle = grad;
    ctx.fillRect(-width / 2, -height / 2, width, height);

    ctx.strokeStyle = 'rgba(99, 102, 241, 0.08)';
    ctx.lineWidth = 2;
    const gridSize = 60;
    const offset = (progress * 30) % gridSize;
    for (let x = -width / 2 + offset; x < width / 2; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, -height / 2);
      ctx.lineTo(x, height / 2);
      ctx.stroke();
    }
  }

  private withContext<T>(ctx: CanvasRenderingContext2D, action: () => T): T {
    const original = this.ctx;
    this.ctx = ctx;
    try {
      return action();
    } finally {
      this.ctx = original;
    }
  }

  /**
   * Draws a clip, blending against the previous clip on the same track while its
   * transition is active.
   */
  private drawClipWithTransition(
    project: Project,
    track: TimelineTrack,
    clip: TimelineClip,
    timeMs: number,
    width: number,
    height: number
  ): void {
    const transition = clip.transition;
    const elapsedMs = timeMs - clip.startMs;

    if (transition && transition.type !== 'cut' && elapsedMs < transition.durationMs) {
      const previous = this.getPreviousClip(track, clip);
      const [canvasFrom, canvasTo] = this.getScratchCanvases(width, height);
      const ctxFrom = canvasFrom.getContext('2d');
      const ctxTo = canvasTo.getContext('2d');

      if (previous && ctxFrom && ctxTo) {
        ctxFrom.clearRect(0, 0, width, height);
        this.withContext(ctxFrom, () =>
          this.drawClipFrame(
            ctxFrom,
            project,
            previous,
            previous.startMs + previous.durationMs - 1,
            width,
            height
          )
        );

        ctxTo.clearRect(0, 0, width, height);
        this.withContext(ctxTo, () =>
          this.drawClipFrame(ctxTo, project, clip, timeMs, width, height)
        );

        const rawProgress = clamp(elapsedMs / transition.durationMs, 0, 1);
        TransitionEngine.renderTransition(
          this.ctx,
          width,
          height,
          canvasFrom,
          canvasTo,
          transition.type,
          rawProgress,
          transition.easing || 'ease-in-out'
        );
        return;
      }
    }

    this.drawClipFrame(this.ctx, project, clip, timeMs, width, height);
  }

  private getPreviousClip(track: TimelineTrack, clip: TimelineClip): TimelineClip | undefined {
    let previous: TimelineClip | undefined;
    for (const candidate of track.clips) {
      if (candidate.id === clip.id) continue;
      const candidateEnd = candidate.startMs + candidate.durationMs;
      if (candidateEnd <= clip.startMs && (!previous || candidateEnd > previous.startMs + previous.durationMs)) {
        previous = candidate;
      }
    }
    return previous;
  }

  private drawTextClip(
    ctx: CanvasRenderingContext2D,
    project: Project,
    clip: TimelineClip,
    timeMs: number,
    width: number,
    height: number
  ): void {
    const text = (clip.textPayload || clip.name || '').trim();
    if (!text) return;

    const localMs = getClipLocalTimeMs(clip, timeMs);
    const transform = getClipVisualTransform(clip, localMs);
    const scene = getSceneForClip(project, clip);

    if (clip.type === 'caption' && scene) {
      // Scene captions keep the original kinetic typography and sub-chunking.
      ctx.save();
      ctx.globalAlpha = clamp(transform.opacity, 0, 1);
      this.drawSceneCaption(ctx, width, height, scene, localMs / 1000);
      ctx.restore();
      return;
    }

    ctx.save();
    ctx.globalAlpha = clamp(transform.opacity, 0, 1);
    const isCaption = clip.type === 'caption';
    // All typography scales with the render height so 1080p/vertical exports
    // keep the same visual weight as the 720p preview.
    const scale = height / 720;
    const fontSize = (isCaption ? 30 : 46) * scale;
    const maxWidth = width - 160 * scale;
    ctx.font = `700 ${fontSize}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const lines = this.wrapText(this.ctx, text, maxWidth);
    const lineHeight = fontSize * 1.3;
    const boxHeight = Math.max(120 * scale, lines.length * lineHeight + 56 * scale);
    const boxY = isCaption
      ? height - boxHeight - 80 * scale
      : height / 2 - boxHeight / 2;

    if (isCaption) {
      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.beginPath();
      ctx.roundRect(60 * scale, boxY, width - 120 * scale, boxHeight, 16 * scale);
      ctx.fill();
      ctx.strokeStyle = 'rgba(99, 102, 241, 0.35)';
      ctx.lineWidth = 2 * scale;
      ctx.stroke();
    } else {
      ctx.shadowColor = 'rgba(0,0,0,0.85)';
      ctx.shadowBlur = 18 * scale;
    }

    ctx.fillStyle = '#ffffff';
    const startY = boxY + boxHeight / 2 - ((lines.length - 1) * lineHeight) / 2;
    lines.forEach((line, index) => {
      ctx.fillText(line, width / 2, startY + index * lineHeight);
    });
    ctx.restore();
  }

  private drawSceneCaption(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    scene: Scene,
    sceneLocalTime: number
  ): void {
    const subtitles =
      scene.subtitles && scene.subtitles.length > 0 ? scene.subtitles : [scene.narrationText];
    const partDuration = scene.durationSeconds / Math.max(1, subtitles.length);
    const currentSubIndex = Math.min(
      subtitles.length - 1,
      Math.max(0, Math.floor(sceneLocalTime / partDuration))
    );
    const currentText = subtitles[currentSubIndex] || scene.narrationText;

    ctx.save();
    const subLocalTime = sceneLocalTime % partDuration;
    const entryProgress = Math.min(1, subLocalTime * 3);
    const scale = height / 720;
    ctx.globalAlpha *= entryProgress;
    ctx.translate(0, (1 - entryProgress) * 15 * scale);

    const boxPaddingHorizontal = 40 * scale;
    const boxHeight = 160 * scale;
    const boxY = height - boxHeight - 80 * scale;

    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.beginPath();
    ctx.roundRect(60 * scale, boxY, width - 120 * scale, boxHeight, 16 * scale);
    ctx.fill();

    ctx.strokeStyle = 'rgba(99, 102, 241, 0.3)';
    ctx.lineWidth = 2 * scale;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = `600 ${28 * scale}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    this.wrapAndRenderText(
      ctx,
      currentText,
      width / 2,
      boxY + boxHeight / 2,
      width - 120 * scale - boxPaddingHorizontal * 2,
      36 * scale
    );
    ctx.restore();
  }

  /**
   * Seeks/pauses timeline videos to match the playhead.
   * During playback, videos advance natively and are corrected only when they drift.
   * When paused (scrubbing or export), videos are deterministically seeked.
   */
  public async syncMedia(project: Project, timeSeconds: number, isPlaying: boolean): Promise<void> {
    const timeMs = timeSeconds * 1000;
    const activeClips = getActiveVisualClips(project, timeMs);
    const activeVideos = new Map<string, { clip: TimelineClip; targetSeconds: number }>();

    for (const { clip } of activeClips) {
      const entry = this.getMediaEntry(clip.assetId);
      if (entry?.kind !== 'video' || !entry.video) continue;
      const targetSeconds = getClipLocalTimeMs(clip, timeMs) / 1000;
      activeVideos.set(entry.assetId, { clip, targetSeconds });
    }

    for (const [assetId, entry] of this.mediaCache) {
      if (entry.kind !== 'video' || !entry.video) continue;
      const active = activeVideos.get(assetId);

      if (!active) {
        if (!entry.video.paused) entry.video.pause();
        this.videoAudioRouter?.setGain(assetId, 0);
        continue;
      }

      const video = entry.video;
      const target = Math.max(0, active.targetSeconds);
      const speed = active.clip.speed && active.clip.speed > 0 ? active.clip.speed : 1;

      // Embedded audio follows the clip's own level/mute, exactly like an audio
      // clip would, so a muted video contributes nothing to the mix.
      // A clip with an A/V desync (J/L) plays its soundtrack through the
      // audio engine instead of the (un-offsettable) media element, so mute
      // the embedded track here to avoid doubling it.
      const clipGain =
        active.clip.isMuted === true || (active.clip.audioOffset || 0) !== 0
          ? 0
          : clamp(active.clip.volume ?? 1, 0, 2);
      this.videoAudioRouter?.setGain(assetId, clipGain);

      if (isPlaying) {
        video.playbackRate = clamp(speed, 0.25, 4);
        if (Math.abs(video.currentTime - target) > 0.4) {
          video.currentTime = target;
        }
        if (video.paused) {
          video.play().catch((error: unknown) => {
            // Unmuted playback can be blocked without recent user activation; the
            // picture keeps rendering but the clip's audio would be missing.
            if ((error as Error)?.name === 'NotAllowedError') {
              console.warn(
                'El navegador bloqueó la reproducción del clip de video; su audio puede faltar en la exportación.'
              );
            }
          });
        }
      } else {
        if (!video.paused) video.pause();
        if (Math.abs(video.currentTime - target) > 0.04) {
          await this.seekVideo(video, target);
        }
      }
    }
  }

  private seekVideo(video: HTMLVideoElement, targetSeconds: number): Promise<void> {
    return new Promise((resolve) => {
      let settled = false;
      const complete = () => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timeout);
        video.removeEventListener('seeked', complete);
        resolve();
      };
      const timeout = window.setTimeout(complete, VIDEO_SEEK_TIMEOUT_MS);
      video.addEventListener('seeked', complete);
      try {
        video.currentTime = targetSeconds;
      } catch {
        complete();
      }
      if (Math.abs(video.currentTime - targetSeconds) < 0.01 && video.readyState >= 2) {
        complete();
      }
    });
  }

  public pauseMedia(): void {
    for (const entry of this.mediaCache.values()) {
      if (entry.video && !entry.video.paused) entry.video.pause();
      if (entry.video) this.videoAudioRouter?.setGain(entry.assetId, 0);
    }
  }

  public dispose(): void {
    this.pauseMedia();
    this.videoAudioRouter = null;
    for (const entry of this.mediaCache.values()) {
      if (entry.objectUrl) URL.revokeObjectURL(entry.objectUrl);
      if (entry.video) {
        entry.video.removeAttribute('src');
        entry.video.load();
      }
    }
    this.mediaCache.clear();
    this.imageCache.clear();
    this.scratchCanvasA = null;
    this.scratchCanvasB = null;
    this.filmGrainCanvas = null;
    this.filmGrainCanvasKey = null;
  }

  private ensureFilmGrainCanvas(width: number, height: number): HTMLCanvasElement {
    // Use a smaller noise canvas to keep per-frame regeneration cheap.
    const grainWidth = Math.max(1, Math.floor(width / 2));
    const grainHeight = Math.max(1, Math.floor(height / 2));
    const key = `${grainWidth}x${grainHeight}`;
    if (!this.filmGrainCanvas || this.filmGrainCanvasKey !== key) {
      const canvas = document.createElement('canvas');
      canvas.width = grainWidth;
      canvas.height = grainHeight;
      this.filmGrainCanvas = canvas;
      this.filmGrainCanvasKey = key;
    }
    // Regenerate noise every frame so the grain is not static.
    const ctx = this.filmGrainCanvas!.getContext('2d');
    if (ctx) {
      const imageData = ctx.createImageData(grainWidth, grainHeight);
      for (let i = 0; i < imageData.data.length; i += 4) {
        const value = Math.floor(Math.random() * 256);
        imageData.data[i] = value;
        imageData.data[i + 1] = value;
        imageData.data[i + 2] = value;
        imageData.data[i + 3] = 255;
      }
      ctx.putImageData(imageData, 0, 0);
    }
    return this.filmGrainCanvas!;
  }

  private drawFilmGrain(project: Project, width: number, height: number): void {
    const grain = getFilmGrainSettings(project);
    if (!grain.enabled || grain.amount <= 0) return;
    const noiseCanvas = this.ensureFilmGrainCanvas(width, height);
    this.ctx.save();
    this.ctx.globalAlpha = grain.amount;
    this.ctx.globalCompositeOperation = 'overlay';
    this.ctx.drawImage(noiseCanvas, 0, 0, noiseCanvas.width, noiseCanvas.height, 0, 0, width, height);
    this.ctx.restore();
  }

  public renderFrame(project: Project, timeSeconds: number): void {
    const { width, height } = this.getRenderSize(project);

    // Ensure canvas dimensions match target resolution
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
    }

    if (!project.timeline || !project.timeline.tracks || project.timeline.tracks.length === 0) {
      this.renderLegacySceneFrame(project, timeSeconds, width, height);
    } else {
      this.renderTimelineFrame(project, timeSeconds, width, height);
    }

    this.drawFilmGrain(project, width, height);
  }

  private renderTimelineFrame(
    project: Project,
    timeSeconds: number,
    width: number,
    height: number
  ): void {
    const timeMs = timeSeconds * 1000;
    const v1Track = project.timeline?.tracks.find((t) => t.id === 'track-v1');
    const v1Visible = v1Track ? v1Track.isVisible : true;

    this.ctx.clearRect(0, 0, width, height);
    this.ctx.fillStyle = '#05070e';
    this.ctx.fillRect(0, 0, width, height);

    // Hidden V1 blacks out the base, but upper visible tracks still composite.
    const visualTracks = getVisualTracks(project);
    const activeVisuals = getActiveVisualClips(project, timeMs);

    for (const { track, clip } of activeVisuals) {
      this.drawClipWithTransition(project, track, clip, timeMs, width, height);
    }

    // Legacy intent banner for scene-backed base clips (keeps the documentary look).
    const baseClip = activeVisuals.find(({ track }) => track.id === 'track-v1')?.clip;
    if (baseClip && !baseClip.assetId) {
      const scene = getSceneForClip(project, baseClip);
      if (scene) {
        this.drawSceneVisuals(width, height, scene, getClipProgress(baseClip, timeMs));
      }
    }

    const activeTexts = getActiveTextClips(project, timeMs);
    for (const { clip } of activeTexts) {
      this.drawTextClip(this.ctx, project, clip, timeMs, width, height);
    }

    const sceneTitle = v1Visible
      ? (baseClip && getSceneForClip(project, baseClip)?.title) || baseClip?.name || project.title
      : '(Pista V1 Oculta)';
    this.drawWatermark(width, height, sceneTitle, timeSeconds);

    if (activeVisuals.length === 0 && visualTracks.length === 0) {
      this.drawEmptyState(width, height);
    }
  }

  private renderLegacySceneFrame(
    project: Project,
    timeSeconds: number,
    width: number,
    height: number
  ): void {
    // Check if timeline model is present and has video tracks
    const v1Track = project.timeline?.tracks.find((t) => t.id === 'track-v1');
    const isV1Visible = v1Track ? v1Track.isVisible : true;

    const scenes = project.script.scenes;
    if (!scenes || scenes.length === 0) {
      this.drawEmptyState(width, height);
      return;
    }

    // If V1 track is explicitly hidden, draw blackout
    if (!isV1Visible) {
      this.ctx.fillStyle = '#05070e';
      this.ctx.fillRect(0, 0, width, height);
      this.drawWatermark(width, height, '(Pista V1 Oculta)', timeSeconds);
      return;
    }

    // Calculate total project duration & current scene index
    let accumulatedTime = 0;
    let currentScene: Scene | null = null;
    let previousScene: Scene | null = null;
    let currentSceneIndex = 0;
    let sceneStartTime = 0;

    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      if (timeSeconds >= accumulatedTime && timeSeconds <= accumulatedTime + scene.durationSeconds) {
        currentScene = scene;
        currentSceneIndex = i;
        previousScene = i > 0 ? scenes[i - 1] : null;
        sceneStartTime = accumulatedTime;
        break;
      }
      accumulatedTime += scene.durationSeconds;
    }

    // If time is past the end, pin to last scene
    if (!currentScene && scenes.length > 0) {
      currentSceneIndex = scenes.length - 1;
      currentScene = scenes[currentSceneIndex];
      previousScene = currentSceneIndex > 0 ? scenes[currentSceneIndex - 1] : null;
      sceneStartTime = accumulatedTime - currentScene.durationSeconds;
    }

    if (!currentScene) {
      this.drawEmptyState(width, height);
      return;
    }

    const sceneLocalTime = Math.max(0, timeSeconds - sceneStartTime);
    const sceneProgress = Math.min(1, sceneLocalTime / currentScene.durationSeconds);

    // Check if timeline V1 has an active clip at this time
    const timeMs = timeSeconds * 1000;
    const v1ClipIndex = v1Track?.clips.findIndex(
      (c) => timeMs >= c.startMs && timeMs < c.startMs + c.durationMs
    ) ?? -1;
    const v1Clip = v1ClipIndex >= 0 ? v1Track!.clips[v1ClipIndex] : undefined;
    const prevV1Clip = v1ClipIndex > 0 ? v1Track!.clips[v1ClipIndex - 1] : undefined;

    const clipOffsetMs = v1Clip ? timeMs - v1Clip.startMs + v1Clip.offsetMs : sceneLocalTime * 1000;

    // Check if there is an active transition (either on clip or scene)
    const clipTransition = v1Clip?.transition;
    const transDurationMs = clipTransition?.durationMs || 1000;
    const isTransitionActive = clipTransition && v1Clip && clipOffsetMs < transDurationMs;

    if (isTransitionActive && (previousScene || prevV1Clip)) {
      // Offscreen multi-buffer rendering for seamless transition blend
      const [canvasFrom, canvasTo] = this.getScratchCanvases(width, height);
      const ctxFrom = canvasFrom.getContext('2d');
      const ctxTo = canvasTo.getContext('2d');

      if (ctxFrom && ctxTo) {
        // Draw Outgoing (From) Frame onto canvasFrom
        this.withContext(ctxFrom, () => {
          this.ctx.clearRect(0, 0, width, height);
          const fromScene = previousScene || currentScene;
          this.drawBackground(
            width,
            height,
            fromScene,
            1.0,
            prevV1Clip,
            prevV1Clip ? prevV1Clip.durationMs : fromScene.durationSeconds * 1000
          );
        });

        // Draw Incoming (To) Frame onto canvasTo
        this.withContext(ctxTo, () => {
          this.ctx.clearRect(0, 0, width, height);
          this.drawBackground(width, height, currentScene, sceneProgress, v1Clip, clipOffsetMs);
        });

        // Restore primary context and render transition
        this.ctx.clearRect(0, 0, width, height);

        const rawProgress = Math.max(0, Math.min(1, clipOffsetMs / transDurationMs));
        TransitionEngine.renderTransition(
          this.ctx,
          width,
          height,
          canvasFrom,
          canvasTo,
          clipTransition.type,
          rawProgress,
          clipTransition.easing || 'ease-in-out'
        );
      } else {
        this.drawBackground(width, height, currentScene, sceneProgress, v1Clip, clipOffsetMs);
      }
    } else {
      // 1. Draw Background & Image (with keyframe transform if available)
      this.drawBackground(width, height, currentScene, sceneProgress, v1Clip, clipOffsetMs);
    }

    // 2. Draw Camera Motion / Overlays
    this.drawSceneVisuals(width, height, currentScene, sceneProgress);

    // 3. Draw Kinetic Typography / Animated Subtitles (only if T1 track is visible)
    const t1Track = project.timeline?.tracks.find((t) => t.id === 'track-t1');
    const isT1Visible = t1Track ? t1Track.isVisible : true;
    if (isT1Visible) {
      this.drawSubtitlesAndText(width, height, currentScene, sceneLocalTime);
    }

    // 4. Draw Studio Watermark & Scene Info
    this.drawWatermark(width, height, currentScene.title, timeSeconds);
  }

  private drawEmptyState(width: number, height: number): void {
    this.ctx.fillStyle = '#0f172a';
    this.ctx.fillRect(0, 0, width, height);
    this.ctx.fillStyle = '#64748b';
    this.ctx.font = 'bold 32px sans-serif';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('Sin escenas para reproducir', width / 2, height / 2);
  }

  private drawBackground(
    width: number,
    height: number,
    scene: Scene,
    progress: number,
    activeClip?: TimelineClip,
    clipTimeMs?: number
  ): void {
    const img = scene.imageUrl ? this.imageCache.get(scene.imageUrl) : null;

    if (img) {
      this.ctx.save();

      // Calculate camera motion transform (or interpolated keyframes if clip has animations)
      let scale = 1.0;
      let dx = 0;
      let dy = 0;
      let rotation = 0;
      let opacity = 1.0;

      if (activeClip?.animations && activeClip.animations.length > 0 && clipTimeMs !== undefined) {
        const keyframeTransform = KeyframeEngine.interpolateClipTransform(
          activeClip.animations,
          clipTimeMs,
          activeClip.transform,
          activeClip.opacity
        );
        dx = keyframeTransform.positionX;
        dy = keyframeTransform.positionY;
        scale = keyframeTransform.scale;
        rotation = keyframeTransform.rotation;
        opacity = keyframeTransform.opacity;
      } else {
        // Fallback procedural camera motion
        if (scene.cameraMotion === 'Zoom In') {
          scale = 1.0 + progress * 0.15;
        } else if (scene.cameraMotion === 'Zoom Out') {
          scale = 1.15 - progress * 0.15;
        } else if (scene.cameraMotion === 'Pan Left') {
          dx = -progress * 40;
        } else if (scene.cameraMotion === 'Pan Right') {
          dx = progress * 40;
        }
      }

      this.ctx.translate(width / 2 + dx, height / 2 + dy);
      if (rotation !== 0) {
        this.ctx.rotate((rotation * Math.PI) / 180);
      }
      this.ctx.scale(scale, scale);
      this.ctx.globalAlpha = opacity;

      // Draw image scaled to cover
      const imgRatio = img.width / img.height;
      const canvasRatio = width / height;
      let drawW = width;
      let drawH = height;

      if (imgRatio > canvasRatio) {
        drawW = height * imgRatio;
      } else {
        drawH = width / imgRatio;
      }

      this.ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
      this.ctx.restore();

      // Dark overlay for readability
      this.ctx.fillStyle = 'rgba(15, 23, 42, 0.65)';
      this.ctx.fillRect(0, 0, width, height);
    } else {
      // Procedural artistic gradient background
      const grad = this.ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, '#090d16');
      grad.addColorStop(0.5, '#1e1b4b');
      grad.addColorStop(1, '#0f172a');

      this.ctx.fillStyle = grad;
      this.ctx.fillRect(0, 0, width, height);

      // Subtle animated particle or grid accent
      this.ctx.strokeStyle = 'rgba(99, 102, 241, 0.08)';
      this.ctx.lineWidth = 2;
      const gridSize = 60;
      const offset = (progress * 30) % gridSize;

      for (let x = offset; x < width; x += gridSize) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, 0);
        this.ctx.lineTo(x, height);
        this.ctx.stroke();
      }
    }
  }

  private drawSceneVisuals(width: number, _height: number, scene: Scene, progress: number): void {
    // Visual intent indicator banner
    this.ctx.fillStyle = 'rgba(99, 102, 241, 0.15)';
    this.ctx.fillRect(60, 60, width - 120, 6);

    this.ctx.fillStyle = '#818cf8';
    this.ctx.fillRect(60, 60, (width - 120) * progress, 6);

    // Intención narrativa
    this.ctx.font = '500 18px sans-serif';
    this.ctx.fillStyle = '#a5b4fc';
    this.ctx.textAlign = 'left';
    this.ctx.fillText(`INTENCIÓN VISUAL: ${scene.visualIntent.toUpperCase()}`, 60, 95);
  }

  private drawSubtitlesAndText(
    width: number,
    height: number,
    scene: Scene,
    sceneLocalTime: number
  ): void {
    this.drawSceneCaption(this.ctx, width, height, scene, sceneLocalTime);
  }

  private wrapText(
    ctx: CanvasRenderingContext2D,
    text: string,
    maxWidth: number
  ): string[] {
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length === 0) return [];

    const lines: string[] = [];
    let currentLine = words[0];

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + ' ' + word).width;
      if (width < maxWidth) {
        currentLine += ' ' + word;
      } else {
        lines.push(currentLine);
        currentLine = word;
      }
    }
    lines.push(currentLine);
    return lines;
  }

  private wrapAndRenderText(
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number
  ): void {
    const lines = this.wrapText(ctx, text, maxWidth);
    const startY = y - ((lines.length - 1) * lineHeight) / 2;
    lines.forEach((line, index) => {
      ctx.fillText(line, x, startY + index * lineHeight);
    });
  }

  private drawWatermark(width: number, height: number, sceneTitle: string, totalTime: number): void {
    // Top right badge
    this.ctx.fillStyle = 'rgba(15, 23, 42, 0.7)';
    this.ctx.beginPath();
    this.ctx.roundRect(width - 240, 24, 216, 36, 18);
    this.ctx.fill();

    this.ctx.fillStyle = '#c7d2fe';
    this.ctx.font = '600 13px sans-serif';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('ESTUDIO AUDIOVISUAL IA', width - 132, 47);

    // Bottom left scene indicator
    this.ctx.fillStyle = '#94a3b8';
    this.ctx.font = '500 14px sans-serif';
    this.ctx.textAlign = 'left';
    this.ctx.fillText(`${sceneTitle} | ${totalTime.toFixed(1)}s`, 60, height - 30);
  }
}
