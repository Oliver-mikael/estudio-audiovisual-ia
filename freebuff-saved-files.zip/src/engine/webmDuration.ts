// WebM duration repair
// MediaRecorder writes a live WebM with no Duration in its Info element, so many
// players report an unknown length and seek poorly. This inserts the real
// Duration without re-encoding, only when the container is safe to edit (unknown
// segment size, no absolute-offset tables, no existing Duration).

const ID_EBML = 0x1a45dfa3;
const ID_SEGMENT = 0x18538067;
const ID_INFO = 0x1549a966;
const ID_DURATION = 0x4489;
const ID_TIMECODE_SCALE = 0x2ad7b1;
const ID_SEEK_HEAD = 0x114d9b74;
const ID_CUES = 0x1c53bb6b;

const DEFAULT_TIMECODE_SCALE_NS = 1_000_000;
const SCAN_BYTES = 256 * 1024;

interface Vint {
  value: number;
  length: number;
  unknown: boolean;
}

interface ElementId {
  id: number;
  length: number;
}

function readElementId(bytes: Uint8Array, offset: number): ElementId | null {
  if (offset >= bytes.length) return null;
  const first = bytes[offset];
  let length = 1;
  for (let mask = 0x80; mask > 0 && (first & mask) === 0; mask >>= 1) length++;
  if (length > 4 || offset + length > bytes.length) return null;

  let id = 0;
  for (let i = 0; i < length; i++) id = id * 256 + bytes[offset + i];
  return { id, length };
}

function readSize(bytes: Uint8Array, offset: number): Vint | null {
  if (offset >= bytes.length) return null;
  const first = bytes[offset];
  let length = 1;
  for (let mask = 0x80; mask > 0 && (first & mask) === 0; mask >>= 1) length++;
  if (length > 8 || offset + length > bytes.length) return null;

  let value = first & (0xff >> length);
  let unknown = value === 0xff >> length;
  for (let i = 1; i < length; i++) {
    value = value * 256 + bytes[offset + i];
    if (bytes[offset + i] !== 0xff) unknown = false;
  }

  return { value, length, unknown };
}

export function encodeEbmlSize(value: number, minLength = 1): Uint8Array {
  let length = Math.max(1, minLength);
  while (value > 2 ** (7 * length) - 2) length++;

  const bytes = new Uint8Array(length);
  let remaining = value;
  for (let i = length - 1; i >= 0; i--) {
    bytes[i] = remaining & 0xff;
    remaining = Math.floor(remaining / 256);
  }
  bytes[0] |= 0x80 >> (length - 1);
  return bytes;
}

function buildDurationElement(durationSeconds: number, timecodeScaleNs: number): Uint8Array {
  const units = (durationSeconds * 1e9) / timecodeScaleNs;
  const bytes = new Uint8Array(11);
  bytes[0] = 0x44;
  bytes[1] = 0x89;
  bytes[2] = 0x88; // 8-byte float
  new DataView(bytes.buffer).setFloat64(3, units, false);
  return bytes;
}

/**
 * Returns a copy of the WebM with a real Duration element when the container can
 * be edited safely; returns null otherwise (already present, MP4, known segment
 * size, offset tables or an unexpected layout).
 */
export async function patchWebmDuration(
  blob: Blob,
  durationSeconds: number
): Promise<Blob | null> {
  if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) return null;
  if (blob.type && !blob.type.toLowerCase().includes('webm')) return null;

  const headSize = Math.min(blob.size, SCAN_BYTES);
  const head = new Uint8Array(await blob.slice(0, headSize).arrayBuffer());

  const ebml = readElementId(head, 0);
  if (!ebml || ebml.id !== ID_EBML) return null;
  const ebmlSize = readSize(head, ebml.length);
  if (!ebmlSize || ebmlSize.unknown) return null;

  const segmentOffset = ebml.length + ebmlSize.length + ebmlSize.value;
  const segmentId = readElementId(head, segmentOffset);
  if (!segmentId || segmentId.id !== ID_SEGMENT) return null;
  const segmentSize = readSize(head, segmentOffset + segmentId.length);
  if (!segmentSize || !segmentSize.unknown) return null;

  let cursor = segmentOffset + segmentId.length + segmentSize.length;
  let infoStart = -1;
  let infoSize: Vint | null = null;

  while (cursor < head.length) {
    const childId = readElementId(head, cursor);
    if (!childId) return null;
    const childSize = readSize(head, cursor + childId.length);
    if (!childSize) return null;

    if (childId.id === ID_INFO) {
      infoStart = cursor;
      infoSize = childSize;
      break;
    }
    if (childId.id === ID_SEEK_HEAD || childId.id === ID_CUES) return null;
    if (childSize.unknown) return null;

    cursor += childId.length + childSize.length + childSize.value;
  }

  if (infoStart < 0 || !infoSize) return null;

  // Info id is always the 4 bytes 0x1549A966.
  const infoDataStart = infoStart + 4 + infoSize.length;
  const infoDataEnd = infoDataStart + infoSize.value;

  // Inspect Info children: skip when a Duration already exists and learn the
  // TimecodeScale used by the Duration units.
  let timecodeScaleNs = DEFAULT_TIMECODE_SCALE_NS;
  let childCursor = infoDataStart;
  while (childCursor < infoDataEnd) {
    const childId = readElementId(head, childCursor);
    if (!childId) return null;
    const childSize = readSize(head, childCursor + childId.length);
    if (!childSize || childSize.unknown) return null;
    const childDataStart = childCursor + childId.length + childSize.length;

    if (childId.id === ID_DURATION) return null;
    if (childId.id === ID_TIMECODE_SCALE && childSize.value <= 8) {
      let scale = 0;
      for (let i = 0; i < childSize.value; i++) scale = scale * 256 + head[childDataStart + i];
      if (scale > 0) timecodeScaleNs = scale;
    }

    childCursor = childDataStart + childSize.value;
  }

  const durationElement = buildDurationElement(durationSeconds, timecodeScaleNs);
  const newInfoSize = encodeEbmlSize(
    infoSize.value + durationElement.length,
    infoSize.length
  );

  const header = new Uint8Array(
    infoStart + 4 + newInfoSize.length + durationElement.length
  );
  header.set(head.subarray(0, infoStart), 0);
  header[infoStart] = 0x15;
  header[infoStart + 1] = 0x49;
  header[infoStart + 2] = 0xa9;
  header[infoStart + 3] = 0x66;
  header.set(newInfoSize, infoStart + 4);
  header.set(durationElement, infoStart + 4 + newInfoSize.length);

  return new Blob(
    [header, head.subarray(infoDataStart, infoDataEnd), blob.slice(infoDataEnd)],
    { type: blob.type || 'video/webm' }
  );
}
