// Media Composition Helpers
// Pure timeline -> canvas composition logic shared by preview and export:
// clip lookup, media-time mapping, layer ordering, color grading and export settings.
import {
  ClipAnimation,
  ExportProfile,
  Project,
  Scene,
  TimelineClip,
  TimelineTrack,
} from '../types';
import { KeyframeEngine, InterpolatedTransform } from '../services/animation/keyframeEngine';

export interface ActiveVisualClip {
  track: TimelineTrack;
  clip: TimelineClip;
}

export interface ExportRenderSettings {
  width: number;
  height: number;
  fps: number;
  bitrateBps: number;
  includeAudio: boolean;
  format: 'webm' | 'mp4';
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

/**
 * Duration of the timeline in milliseconds (end of the last clip on any track).
 */
export function getTimelineDurationMs(project: Project): number {
  const tracks = project.timeline?.tracks || [];
  let endMs = 0;
  for (const track of tracks) {
    for (const clip of track.clips) {
      endMs = Math.max(endMs, clip.startMs + clip.durationMs);
    }
  }
  return Math.max(0, Math.round(endMs));
}

/**
 * Authoritative project duration: the timeline when it has clips, otherwise the
 * sum of scene durations (legacy projects without a timeline model).
 */
export function getProjectDurationMs(project: Project): number {
  const timelineMs = getTimelineDurationMs(project);
  if (timelineMs > 0) return timelineMs;

  const sceneMs = (project.script?.scenes || []).reduce(
    (sum, scene) => sum + Math.max(0, scene.durationSeconds) * 1000,
    0
  );
  return Math.round(sceneMs);
}

/**
 * Active clip on a track at a given playhead time. When clips overlap, the one
 * that starts last wins, which matches the editor's visual stacking.
 */
export function getActiveClipOnTrack(track: TimelineTrack, timeMs: number): TimelineClip | undefined {
  let active: TimelineClip | undefined;
  for (const clip of track.clips) {
    const start = clip.startMs;
    const end = clip.startMs + clip.durationMs;
    if (timeMs >= start && timeMs < end) {
      if (!active || clip.startMs >= active.startMs) active = clip;
    }
  }
  return active;
}

export function getVisualTracks(project: Project): TimelineTrack[] {
  return (project.timeline?.tracks || [])
    .filter((track) => track.type === 'video' && track.isVisible)
    .sort((a, b) => a.order - b.order);
}

export function getTextTracks(project: Project): TimelineTrack[] {
  return (project.timeline?.tracks || [])
    .filter((track) => (track.type === 'text' || track.type === 'subtitles') && track.isVisible)
    .sort((a, b) => a.order - b.order);
}

/**
 * Active visual clips ordered back-to-front (base track first).
 */
export function getActiveVisualClips(project: Project, timeMs: number): ActiveVisualClip[] {
  const result: ActiveVisualClip[] = [];
  for (const track of getVisualTracks(project)) {
    const clip = getActiveClipOnTrack(track, timeMs);
    if (clip && !clip.isMuted) {
      result.push({ track, clip });
    }
  }
  return result;
}

export function getActiveTextClips(project: Project, timeMs: number): ActiveVisualClip[] {
  const result: ActiveVisualClip[] = [];
  for (const track of getTextTracks(project)) {
    const clip = getActiveClipOnTrack(track, timeMs);
    if (clip) result.push({ track, clip });
  }
  return result;
}

/**
 * Maps timeline time to media time inside the clip, honoring the in-point
 * offset and playback speed.
 */
export function getClipLocalTimeMs(clip: TimelineClip, timeMs: number): number {
  const elapsedMs = Math.max(0, timeMs - clip.startMs);
  const speed = clip.speed && clip.speed > 0 ? clip.speed : 1;
  return Math.max(0, (clip.offsetMs || 0) + elapsedMs * speed);
}

export function getClipProgress(clip: TimelineClip, timeMs: number): number {
  if (clip.durationMs <= 0) return 0;
  return clamp((timeMs - clip.startMs) / clip.durationMs, 0, 1);
}

export function getSceneForClip(project: Project, clip: TimelineClip): Scene | undefined {
  if (!clip.sceneId) return undefined;
  return (project.script?.scenes || []).find((scene) => scene.id === clip.sceneId);
}

/**
 * Interpolated transform for a clip (keyframes when present, static otherwise).
 */
export function getClipVisualTransform(
  clip: TimelineClip,
  localTimeMs: number
): InterpolatedTransform {
  const animations: ClipAnimation[] | undefined = clip.animations;
  return KeyframeEngine.interpolateClipTransform(
    animations,
    localTimeMs,
    {
      x: clip.transform?.x ?? 0,
      y: clip.transform?.y ?? 0,
      scale: clip.transform?.scale ?? 1,
      rotation: clip.transform?.rotation ?? 0,
    },
    clip.opacity ?? 1
  );
}

const FILTER_PRESETS: Record<NonNullable<TimelineClip['filterPreset']>, string> = {
  none: '',
  cinematic: 'contrast(1.12) saturate(0.9) brightness(0.97)',
  'documentary-warm': 'sepia(0.18) saturate(1.08) contrast(1.04)',
  noir: 'grayscale(1) contrast(1.25)',
  vintage: 'sepia(0.35) saturate(0.85) contrast(0.95)',
  vivid: 'saturate(1.35) contrast(1.08)',
};

/**
 * CSS/Canvas filter string for a clip's color adjustments and preset.
 * Returns 'none' when the clip has no grading so the canvas filter can be reset.
 */
export function buildClipFilter(clip: TimelineClip): string {
  const parts: string[] = [];

  const preset = clip.filterPreset && clip.filterPreset !== 'none' ? FILTER_PRESETS[clip.filterPreset] : '';
  if (preset) parts.push(preset);

  const adj = clip.colorAdjustments;
  if (adj) {
    if (adj.brightness && adj.brightness !== 0) {
      parts.push(`brightness(${clamp(1 + adj.brightness, 0, 4).toFixed(3)})`);
    }
    if (adj.contrast && adj.contrast !== 1) {
      parts.push(`contrast(${clamp(adj.contrast, 0, 4).toFixed(3)})`);
    }
    if (adj.saturation && adj.saturation !== 1) {
      parts.push(`saturate(${clamp(adj.saturation, 0, 4).toFixed(3)})`);
    }
    if (adj.temperature && adj.temperature !== 0) {
      const t = clamp(adj.temperature / 100, -1, 1);
      if (t > 0) {
        parts.push(`sepia(${(t * 0.25).toFixed(3)})`);
      } else {
        parts.push(`hue-rotate(${(t * 12).toFixed(1)}deg) saturate(1.05)`);
      }
    }
  }

  return parts.length > 0 ? parts.join(' ') : 'none';
}

export function getClipVignette(clip: TimelineClip): number {
  return clamp(clip.colorAdjustments?.vignette ?? 0, 0, 1);
}

/**
 * Resolves the canvas size, frame rate, bitrate and audio flag for an export,
 * preferring the selected profile over the project defaults.
 */
export function resolveExportSettings(
  project: Project,
  profile?: ExportProfile
): ExportRenderSettings {
  return {
    width: profile?.resolution.width ?? project.settings.resolution.width,
    height: profile?.resolution.height ?? project.settings.resolution.height,
    fps: Math.max(1, Math.round(profile?.fps ?? project.settings.fps ?? 30)),
    bitrateBps: Math.max(100_000, Math.round(profile?.bitrateBps ?? 2_500_000)),
    includeAudio: profile?.includeAudio ?? true,
    format: profile?.format ?? 'webm',
  };
}

/**
 * Safe file extension derived from the produced mime type.
 */
export function getFilmGrainSettings(project: Project): { enabled: boolean; amount: number } {
  const settings = project.settings || ({} as Project['settings']);
  const enabled =
    settings.filmGrain?.enabled ?? settings.filmGrainEnabled ?? true;
  const amountRaw =
    settings.filmGrain?.amount ?? settings.filmGrainAmount ?? 0.08;
  const amount = Math.max(0, Math.min(0.2, Number.isFinite(amountRaw) ? amountRaw : 0.08));
  return { enabled: Boolean(enabled), amount };
}

export function getVideoFileExtension(mimeType: string): 'mp4' | 'webm' {
  return mimeType.toLowerCase().includes('mp4') ? 'mp4' : 'webm';
}

export function formatDurationMs(durationMs: number): string {
  const totalSeconds = Math.max(0, Math.round(durationMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}
