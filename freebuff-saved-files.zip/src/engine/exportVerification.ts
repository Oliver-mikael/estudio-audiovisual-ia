// Real export verification
// Decodes the produced video file again (duration, dimensions, sampled frames and
// audio) instead of trusting the recording process, so a broken export is shown
// to the user as broken.

export interface ExportVerification {
  ok: boolean;
  durationSeconds: number | null;
  expectedDurationSeconds: number;
  width: number;
  height: number;
  framesSampled: number;
  distinctFrames: number;
  meanLuminance: number;
  hasAudioTrack: boolean | null;
  audioPeak: number | null;
  audioDurationSeconds: number | null;
  warnings: string[];
}

export interface ExportProbeExpectation {
  durationSeconds: number;
  width: number;
  height: number;
  expectAudioTrack: boolean;
}

export interface ExportProbeMetrics {
  durationSeconds: number | null;
  width: number;
  height: number;
  frames: Array<{ luminance: number; hash: number }>;
  audio: { durationSeconds: number; peak: number } | null;
  expected: ExportProbeExpectation;
}

function round(value: number, decimals = 2): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

/**
 * Pure rules that decide whether an exported file is usable. Kept separate from
 * the DOM probe so the criteria are unit tested.
 */
export function summarizeExportVerification(metrics: ExportProbeMetrics): ExportVerification {
  const { expected, frames } = metrics;
  const warnings: string[] = [];
  let fatal = false;

  if (metrics.durationSeconds === null) {
    warnings.push('El archivo no expone una duración reproducible.');
    fatal = true;
  } else {
    const tolerance = Math.max(0.6, expected.durationSeconds * 0.08);
    if (Math.abs(metrics.durationSeconds - expected.durationSeconds) > tolerance) {
      warnings.push(
        `Duración detectada ${round(metrics.durationSeconds)}s frente a ${round(
          expected.durationSeconds
        )}s del timeline.`
      );
      fatal = true;
    }
  }

  if (metrics.width !== expected.width || metrics.height !== expected.height) {
    warnings.push(
      `Resolución detectada ${metrics.width}x${metrics.height}; se esperaba ${expected.width}x${expected.height}.`
    );
    fatal = true;
  }

  const meanLuminance = frames.length
    ? frames.reduce((sum, frame) => sum + frame.luminance, 0) / frames.length
    : 0;
  const distinctFrames = new Set(frames.map((frame) => frame.hash)).size;

  if (frames.length === 0) {
    warnings.push('No se pudo decodificar ningún cuadro del archivo.');
    fatal = true;
  } else if (meanLuminance < 3) {
    warnings.push('Los cuadros decodificados están en negro.');
    fatal = true;
  } else if (frames.length > 1 && distinctFrames < 2) {
    warnings.push('Todos los cuadros muestreados son idénticos.');
  }

  if (expected.expectAudioTrack) {
    if (!metrics.audio) {
      warnings.push('No se pudo decodificar la pista de audio del archivo.');
    } else if (metrics.audio.peak <= 0.005) {
      warnings.push('La pista de audio del archivo está en silencio.');
    }
  }

  return {
    ok: !fatal,
    durationSeconds:
      metrics.durationSeconds === null ? null : round(metrics.durationSeconds),
    expectedDurationSeconds: round(expected.durationSeconds),
    width: metrics.width,
    height: metrics.height,
    framesSampled: frames.length,
    distinctFrames,
    meanLuminance: round(meanLuminance, 1),
    hasAudioTrack: metrics.audio ? true : expected.expectAudioTrack ? false : null,
    audioPeak: metrics.audio ? round(metrics.audio.peak, 3) : null,
    audioDurationSeconds: metrics.audio ? round(metrics.audio.durationSeconds) : null,
    warnings,
  };
}

function waitForEvent(target: EventTarget, event: string, timeoutMs: number): Promise<void> {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = window.setTimeout(() => {
      if (settled) return;
      settled = true;
      target.removeEventListener(event, onEvent);
      reject(new Error(`Tiempo de espera agotado esperando "${event}".`));
    }, timeoutMs);

    const onEvent = () => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timer);
      target.removeEventListener(event, onEvent);
      resolve();
    };

    target.addEventListener(event, onEvent);
  });
}

async function seekVideo(video: HTMLVideoElement, timeSeconds: number): Promise<void> {
  if (Math.abs(video.currentTime - timeSeconds) < 0.01 && video.readyState >= 2) return;

  const seeked = waitForEvent(video, 'seeked', 6000);
  video.currentTime = Math.max(0, timeSeconds);
  await seeked;

  if (video.readyState < 2) {
    await waitForEvent(video, 'loadeddata', 3000).catch(() => undefined);
  }
}

async function readDuration(video: HTMLVideoElement): Promise<number | null> {
  const finite = (value: number) => (Number.isFinite(value) && value > 0 ? value : null);

  const direct = finite(video.duration);
  if (direct) return direct;

  // MediaRecorder WebM files often omit the duration until the player scans the
  // end of the file; seeking near the end forces that calculation.
  try {
    await seekVideo(video, 1e6);
  } catch {
    /* The file may reject far seeks; fall back to the seekable range. */
  }

  const afterSeek = finite(video.duration);
  if (afterSeek) return afterSeek;

  if (video.seekable.length > 0) {
    const end = video.seekable.end(video.seekable.length - 1);
    if (Number.isFinite(end) && end > 0) return end;
  }

  return null;
}

async function probeAudio(
  blob: Blob
): Promise<{ durationSeconds: number; peak: number } | null> {
  try {
    const arrayBuffer = await blob.arrayBuffer();
    const offline = new OfflineAudioContext(1, 1, 48000);
    const decoded = await offline.decodeAudioData(arrayBuffer);
    if (!decoded || decoded.length === 0) return null;

    let peak = 0;
    for (let channel = 0; channel < decoded.numberOfChannels; channel++) {
      const data = decoded.getChannelData(channel);
      const step = Math.max(1, Math.floor(data.length / 48000));
      for (let i = 0; i < data.length; i += step) {
        const value = Math.abs(data[i]);
        if (value > peak) peak = value;
      }
    }

    return { durationSeconds: decoded.duration, peak };
  } catch {
    return null;
  }
}

/**
 * Decodes the exported blob as a real media file: reads its duration and size,
 * samples frames through a canvas to prove picture content exists and decodes
 * the audio track. Never throws; failures are reported as verification warnings.
 */
export async function probeExportedVideo(
  blob: Blob,
  expected: ExportProbeExpectation
): Promise<ExportVerification> {
  const url = URL.createObjectURL(blob);
  const video = document.createElement('video');
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  video.src = url;

  const frames: Array<{ luminance: number; hash: number }> = [];
  let durationSeconds: number | null = null;
  let width = 0;
  let height = 0;

  try {
    await waitForEvent(video, 'loadedmetadata', 10000).catch(() => undefined);
    if (video.readyState < 1) {
      await waitForEvent(video, 'loadeddata', 5000).catch(() => undefined);
    }

    durationSeconds = await readDuration(video);
    width = video.videoWidth;
    height = video.videoHeight;

    const sampleDuration = durationSeconds ?? expected.durationSeconds;
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 54;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (ctx && sampleDuration > 0) {
      for (let index = 0; index < 5; index++) {
        const fraction = 0.04 + index * 0.23;
        const time = Math.min(sampleDuration - 0.05, sampleDuration * fraction);
        try {
          await seekVideo(video, Math.max(0, time));
        } catch {
          continue;
        }
        if (video.readyState < 2) continue;

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);

        let luminanceSum = 0;
        let hash = 2166136261;
        for (let i = 0; i < data.length; i += 16) {
          luminanceSum += data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
          hash ^= data[i] + (data[i + 1] << 8) + (data[i + 2] << 16);
          hash = Math.imul(hash, 16777619);
        }
        frames.push({
          luminance: luminanceSum / Math.max(1, data.length / 16),
          hash: hash >>> 0,
        });
      }
    }
  } finally {
    video.pause();
    video.removeAttribute('src');
    video.load();
    URL.revokeObjectURL(url);
  }

  const audio = await probeAudio(blob);

  return summarizeExportVerification({
    durationSeconds,
    width,
    height,
    frames,
    audio,
    expected,
  });
}
