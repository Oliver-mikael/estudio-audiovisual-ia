// Client-side Video Exporter using Canvas Capture & Web Audio Multitrack Engine
import { ExportProfile, Project } from '../types';
import { CanvasRenderEngine } from './renderEngine';
import { audioEngine } from '../services/audio/AudioEngine';
import { audioMixer } from '../services/audio/AudioMixer';
import { TimelineEngine } from '../services/timeline/timelineEngine';
import { getProjectDurationMs, resolveExportSettings } from './mediaComposition';
import { ExportVerification, probeExportedVideo } from './exportVerification';
import { patchWebmDuration } from './webmDuration';
import { buildExportPlan, type ExportPlan, type ExportSettings } from '../services/export/exportPlan';
import { detectExportCapabilities } from '../services/export/codecs';

export interface ExportProgressCallback {
  (progress: number, statusMessage: string): void;
}

export interface ExportStats {
  elapsedMs: number;
  remainingMs: number;
  frameIndex: number;
  totalFrames: number;
}

export interface ExportOptions {
  /** Full export configuration (resolution tier, aspect, fps, quality, format). */
  settings?: ExportSettings;
  /** Legacy profile object, kept for existing callers. */
  profile?: ExportProfile;
  /** Cancels the render; the recorder is stopped and the promise rejects. */
  signal?: AbortSignal;
  /** Reports the resolved plan before recording starts. */
  onPlan?: (plan: ExportPlan) => void;
  onStats?: (stats: ExportStats) => void;
}

export interface ExportResult {
  blob: Blob;
  mimeType: string;
  width: number;
  height: number;
  fps: number;
  extension: 'webm' | 'mp4' | 'mov';
  /** Duration actually recorded, in seconds. */
  durationSeconds: number;
  /** Final container size in bytes (equal to `blob.size`). */
  sizeBytes: number;
  /** Wall-clock time spent rendering. */
  elapsedMs: number;
  /** Resolved plan (frame size, bitrate, container, warnings). */
  plan?: ExportPlan;
  /** True when the requested container was rejected and another was produced. */
  containerFallback?: boolean;
  /** Decoded-file verification; null when the browser could not decode it. */
  verification: ExportVerification | null;
}

/**
 * Reads the first bytes of the recording to know the real container instead of
 * trusting MediaRecorder.mimeType (Chromium can label a WebM/VP9 recording as
 * `video/mp4`).
 */
async function sniffContainer(blob: Blob): Promise<'webm' | 'mp4' | 'mov' | null> {
  try {
    const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer());
    if (head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3) {
      return 'webm';
    }
    const brand = String.fromCharCode(head[4], head[5], head[6], head[7]);
    if (brand === 'ftyp') {
      const major = String.fromCharCode(head[8], head[9], head[10], head[11]);
      return major === 'qt  ' ? 'mov' : 'mp4';
    }
    return null;
  } catch {
    return null;
  }
}

/** Lead time used to schedule audio before the recorder starts, in seconds. */
const AUDIO_LEAD_SECONDS = 0.3;
/** Extra time recorded after the last frame so the final audio tail is kept. */
const END_TAIL_SECONDS = 0.1;

/**
 * Picks the best container/codec combination the running browser can record.
 * Shared with the UI so the promised format always matches the produced file.
 */
export function getSupportedMimeType(format: 'webm' | 'mp4'): string | null {
  if (typeof MediaRecorder === 'undefined' || typeof MediaRecorder.isTypeSupported !== 'function') {
    return null;
  }

  const candidates =
    format === 'mp4'
      ? ['video/mp4;codecs=avc1,mp4a', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm']
      : [
          'video/webm;codecs=vp9,opus',
          'video/webm;codecs=vp8,opus',
          'video/webm',
          'video/mp4',
        ];

  return candidates.find((mime) => MediaRecorder.isTypeSupported(mime)) || null;
}

function hasAudioClips(project: Project): boolean {
  return (project.timeline?.tracks || []).some(
    (track) =>
      track.type === 'audio' &&
      track.isVisible &&
      !track.isMuted &&
      track.clips.some((clip) => clip.durationMs > 0)
  );
}

/**
 * Video clips can carry their own soundtrack. Their level and mute state are
 * applied per clip, so a video clip with volume 0 adds nothing to the mix.
 */
function hasVideoAudioClips(project: Project): boolean {
  return (project.timeline?.tracks || []).some(
    (track) =>
      track.type === 'video' &&
      track.isVisible &&
      !track.isMuted &&
      track.clips.some(
        (clip) =>
          clip.type === 'video' &&
          Boolean(clip.assetId) &&
          clip.isMuted !== true &&
          (clip.volume ?? 1) > 0 &&
          clip.durationMs > 0
      )
  );
}

export class VideoExporter {
  /**
   * Renders the timeline to a real video file: frames are composited on a canvas
   * (media, layers, keyframes, transitions, text) while the Web Audio multitrack
   * mix is captured through a MediaStreamDestination.
   *
   * Audio and picture share the AudioContext clock so the exported file stays in
   * sync, and the produced blob is decoded again before reporting success.
   */
  public static async exportProjectVideo(
    project: Project,
    onProgress: ExportProgressCallback,
    options: ExportOptions = {}
  ): Promise<ExportResult> {
    onProgress(0, 'Iniciando motor de renderizado y mezcla de audio...');
    const startedAt = performance.now();

    const initializedProject = TimelineEngine.ensureTimeline(project);
    const legacySettings = resolveExportSettings(initializedProject, options.profile);

    // Duration comes from the timeline (audio or video can extend past the last scene).
    const totalDurationMs = getProjectDurationMs(initializedProject);
    const totalDuration = totalDurationMs / 1000;

    if (totalDuration <= 0) {
      throw new Error('El proyecto no contiene clips ni escenas con duración válida.');
    }

    // Resolve the full configuration against real browser capabilities.
    let plan: ExportPlan | null = null;
    if (options.settings) {
      const capabilities = detectExportCapabilities();
      const planResult = buildExportPlan({
        settings: options.settings,
        durationSeconds: totalDuration,
        capabilities,
      });
      if (!planResult.ok) throw new Error(planResult.error);
      plan = planResult.plan;
      options.onPlan?.(plan);
    }

    const width = plan?.width ?? legacySettings.width;
    const height = plan?.height ?? legacySettings.height;
    const fps = plan?.fps ?? legacySettings.fps;
    const bitrateBps = plan?.videoBitrateBps ?? legacySettings.bitrateBps;
    const includeAudio = options.settings ? options.settings.includeAudio : legacySettings.includeAudio;

    if (options.signal?.aborted) {
      throw new DOMException('Exportación cancelada antes de empezar.', 'AbortError');
    }

    // 1. Offscreen Canvas creation for precise frame rendering at the export size.
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const renderEngine = new CanvasRenderEngine(canvas, {
      width,
      height,
      composition: plan?.composition,
    });

    onProgress(8, 'Precargando recursos visuales y medios del timeline...');
    await renderEngine.preloadImages(initializedProject.script.scenes);
    const preloaded = await renderEngine.preloadProjectMedia(initializedProject);

    if (preloaded.failedAssetIds.length > 0) {
      console.warn(
        `No se pudieron precargar ${preloaded.failedAssetIds.length} recurso(s) visual(es); se mostrará el fondo de respaldo.`
      );
    }

    // 2. Optional Web Audio multitrack destination
    let audioStream: MediaStream | null = null;
    let duckingOptions = undefined;
    let audioStartTime: number | null = null;
    let audioContext: AudioContext | null = null;
    const expectAudioContent =
      includeAudio && (hasAudioClips(initializedProject) || hasVideoAudioClips(initializedProject));

    if (includeAudio) {
      onProgress(15, 'Configurando motor de audio multicanal...');
      await audioEngine.initContext();
      audioStream = audioEngine.getDestinationStream();

      onProgress(20, 'Precargando pistas de audio del timeline...');
      const preloadedAudio = await audioEngine.preloadProjectAudio(initializedProject);
      audioEngine.setupTracks(audioMixer.getTrackConfigs());
      duckingOptions = audioMixer.getDuckingOptions();

      if (preloadedAudio.failedClipAssetIds.length > 0) {
        console.warn(
          `No se pudo precargar el binario de ${preloadedAudio.failedClipAssetIds.length} clip(s) de audio; se usará el tono sintético.`
        );
      }

      // Video clips bring their own soundtrack: hand each element to the mixer so
      // it reaches the recorded stream, gain-controlled by the active clip.
      const routedVideoAssets = new Set<string>();
      renderEngine.setVideoAudioRouter({
        attach: (element, assetId) => {
          if (audioEngine.attachMediaElement(assetId, element)) {
            routedVideoAssets.add(assetId);
          }
        },
        setGain: (assetId, gain) => audioEngine.setMediaElementGain(assetId, gain),
      });

      if (routedVideoAssets.size > 0) {
        onProgress(
          22,
          `Mezclando el audio embebido de ${routedVideoAssets.size} clip(s) de video...`
        );
      }

      if (expectAudioContent) {
        // Schedule the mix ahead of time and record against that exact clock.
        const scheduled = await audioEngine.schedulePlayback(
          initializedProject,
          0,
          duckingOptions,
          AUDIO_LEAD_SECONDS
        );
        audioStartTime = scheduled.startTime;
        audioContext = audioEngine.getContext();
      }
    }

    // 3. MediaRecorder setup with WebM/MP4 support detection
    const canvasStream = canvas.captureStream(fps);
    const videoTracks = canvasStream.getVideoTracks();
    const audioTracks = audioStream ? audioStream.getAudioTracks() : [];
    const combinedStream = new MediaStream([...videoTracks, ...audioTracks]);

    const supportedMime = plan ? plan.mimeType : getSupportedMimeType(legacySettings.format);

    if (!supportedMime) {
      renderEngine.dispose();
      audioEngine.releaseDecodedBuffers();
      throw new Error('Este navegador no soporta la grabación de video (MediaRecorder).');
    }

    // The plan comes from isTypeSupported probes; re-check so a stale capability
    // list can never start a recorder with a mime type it will silently ignore.
    if (
      typeof MediaRecorder.isTypeSupported === 'function' &&
      !MediaRecorder.isTypeSupported(supportedMime)
    ) {
      renderEngine.dispose();
      audioEngine.releaseDecodedBuffers();
      audioEngine.detachMediaElements();
      throw new Error(
        `El codificador ${supportedMime} dejó de estar disponible. Elige otro formato de salida.`
      );
    }

    const recordedChunks: Blob[] = [];

    /**
     * Some browsers report a codec as supported but refuse to construct the
     * recorder. Walk a verified fallback chain and keep whichever container the
     * browser really accepted, instead of failing or mislabelling the file.
     */
    const candidateMimes = Array.from(
      new Set(
        plan
          ? [
              plan.mimeType,
              plan.format.container === 'mp4' ? 'video/mp4' : 'video/webm',
              'video/webm;codecs=vp9,opus',
              'video/webm;codecs=vp8,opus',
              'video/webm',
            ]
          : [supportedMime]
      )
    );

    let selectedRecorder: MediaRecorder | null = null;
    let actualMime = supportedMime;
    for (const mime of candidateMimes) {
      if (!mime) continue;
      if (typeof MediaRecorder.isTypeSupported === 'function' && !MediaRecorder.isTypeSupported(mime)) {
        continue;
      }
      try {
        const options: MediaRecorderOptions = {
          mimeType: mime,
          videoBitsPerSecond: bitrateBps,
        };
        if (includeAudio && plan) options.audioBitsPerSecond = plan.audioBitrateBps;
        selectedRecorder = new MediaRecorder(combinedStream, options);
        actualMime = selectedRecorder.mimeType || mime;
        break;
      } catch {
        selectedRecorder = null;
      }
    }

    if (!selectedRecorder) {
      renderEngine.dispose();
      audioEngine.detachMediaElements();
      audioEngine.releaseDecodedBuffers();
      canvasStream.getTracks().forEach((track) => track.stop());
      throw new Error(
        'El navegador rechazó todos los codificadores disponibles (MP4/WebM). Prueba otro navegador o una resolución menor.'
      );
    }

    const mediaRecorder: MediaRecorder = selectedRecorder;
    const actualContainer = actualMime.split(';')[0].replace('video/', '').toLowerCase();
    const containerFallback = plan ? plan.format.container !== actualContainer : false;
    if (containerFallback) {
      console.warn(
        `El navegador no pudo grabar ${plan?.format.label}; se está produciendo ${actualMime}.`
      );
      onProgress(
        24,
        `El navegador rechazó ${plan?.format.label ?? 'el formato elegido'}; se está grabando ${actualMime}.`
      );
    }

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        recordedChunks.push(e.data);
      }
    };

    const totalFrames = Math.max(1, Math.ceil(totalDuration * fps));
    // Never render at/after the timeline end: every clip has already finished and
    // the frame would be the empty background.
    const lastFrameTime = Math.max(0, totalDuration - 0.5 / fps);
    const usesAudioClock = audioStartTime !== null && audioContext !== null;

    return new Promise<ExportResult>((resolve, reject) => {
      let failed = false;
      let finalized = false;
      let timer: ReturnType<typeof setTimeout> | null = null;
      let videoStartAt = performance.now();
      let recordedDurationSeconds = totalDuration;

      const detachAbort = () => {
        options.signal?.removeEventListener('abort', onAbort);
      };
      const onAbort = () => {
        fail(new DOMException('Exportación cancelada por el usuario.', 'AbortError'));
      };
      options.signal?.addEventListener('abort', onAbort);

      const stopRecorder = () => {
        try {
          if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
        } catch {
          /* Recorder already stopped. */
        }
      };

      const fail = (error: unknown) => {
        if (failed || finalized) return;
        failed = true;
        detachAbort();
        if (timer) clearTimeout(timer);
        try {
          audioEngine.stop();
        } catch {
          /* Audio engine may not have been initialized. */
        }
        renderEngine.pauseMedia();
        stopRecorder();
        canvasStream.getTracks().forEach((track) => track.stop());
        renderEngine.dispose();
        audioEngine.detachMediaElements();
        audioEngine.releaseDecodedBuffers();
        reject(error instanceof Error ? error : new Error(String(error)));
      };

      mediaRecorder.onstop = () => {
        if (failed) return;
        finalized = true;
        detachAbort();
        if (timer) clearTimeout(timer);
        try {
          audioEngine.stop();
        } catch {
          /* Recorder may have failed before audio started. */
        }
        // Canvas capture tracks stay live until stopped; otherwise every export
        // leaves a rendering stream (and its canvas) alive on mobile.
        canvasStream.getTracks().forEach((track) => track.stop());
        renderEngine.dispose();

        const reportedMime = mediaRecorder.mimeType || actualMime;
        let finalBlob = new Blob(recordedChunks, { type: reportedMime });
        recordedChunks.length = 0;

        audioEngine.detachMediaElements();

        if (finalBlob.size === 0) {
          audioEngine.releaseDecodedBuffers();
          reject(new Error('La grabación terminó sin datos de video.'));
          return;
        }

        onProgress(97, 'Verificando el archivo de video generado...');
        void (async () => {
          // The bytes decide the container: relabel the blob when the recorder
          // reported a container it did not produce.
          const realContainer = await sniffContainer(finalBlob);
          const reportedContainer = reportedMime
            .split(';')[0]
            .replace('video/', '')
            .toLowerCase();
          const containerCorrected =
            realContainer !== null && realContainer !== reportedContainer;
          const mimeType = containerCorrected ? `video/${realContainer}` : reportedMime;
          if (containerCorrected) {
            console.warn(
              `El grabador reportó ${reportedMime} pero el archivo real es ${mimeType}; se corrige la etiqueta y el contenedor informado.`
            );
            finalBlob = new Blob([finalBlob], { type: mimeType });
          }
          const effectiveContainerFallback =
            containerFallback ||
            (plan ? plan.format.container !== (realContainer ?? plan.format.container) : false);

          const expectation = {
            durationSeconds: totalDuration,
            width,
            height,
            expectAudioTrack: expectAudioContent,
          };

          let verification = await probeExportedVideo(finalBlob, expectation).catch((error) => {
            console.warn('No se pudo verificar el archivo exportado:', error);
            return null;
          });

          // MediaRecorder omits the Duration element: patch it so players show a
          // real length, then decode the patched file again before trusting it.
          if (mimeType.toLowerCase().includes('webm')) {
            onProgress(98, 'Añadiendo la duración real al contenedor WebM...');
            const patched = await patchWebmDuration(finalBlob, recordedDurationSeconds).catch(
              () => null
            );
            if (patched) {
              const patchedVerification = await probeExportedVideo(patched, expectation).catch(
                () => null
              );
              if (
                patchedVerification &&
                patchedVerification.ok &&
                patchedVerification.durationSeconds !== null
              ) {
                finalBlob = patched;
                verification = patchedVerification;
              }
            }
          }

          audioEngine.releaseDecodedBuffers();
          onProgress(
            100,
            verification && !verification.ok
              ? 'Exportación finalizada con advertencias de verificación.'
              : 'Exportación finalizada exitosamente.'
          );
          resolve({
            blob: finalBlob,
            mimeType,
            width,
            height,
            fps,
            extension: mimeType.toLowerCase().includes('mp4')
              ? 'mp4'
              : mimeType.toLowerCase().includes('quicktime')
                ? 'mov'
                : 'webm',
            durationSeconds: totalDuration,
            sizeBytes: finalBlob.size,
            elapsedMs: Math.round(performance.now() - startedAt),
            containerFallback: effectiveContainerFallback,
            plan: plan ?? undefined,
            verification,
          });
        })();
      };

      mediaRecorder.onerror = (event) => {
        const recorderError = (event as ErrorEvent).error;
        fail(recorderError || new Error('Error del grabador de video.'));
      };

      const clockSeconds = (): number => {
        if (usesAudioClock && audioContext && audioStartTime !== null) {
          return Math.max(0, audioContext.currentTime - audioStartTime);
        }
        return Math.max(0, (performance.now() - videoStartAt) / 1000);
      };

      const waitForAudioStart = (): Promise<void> => {
        if (!usesAudioClock || !audioContext || audioStartTime === null) return Promise.resolve();
        return new Promise<void>((done) => {
          const tick = () => {
            if (!audioContext || audioContext.currentTime >= audioStartTime - 0.01) {
              done();
              return;
            }
            setTimeout(tick, 5);
          };
          tick();
        });
      };

      const renderNextFrame = async () => {
        if (failed || finalized) return;

        try {
          const elapsed = clockSeconds();
          const frameIndex = Math.min(totalFrames - 1, Math.floor(elapsed * fps));
          const frameTime = Math.min(lastFrameTime, frameIndex / fps);

          await renderEngine.syncMedia(initializedProject, frameTime, true);
          renderEngine.renderFrame(initializedProject, frameTime);

          const progressPercent = Math.min(
            95,
            Math.floor((Math.min(elapsed, totalDuration) / totalDuration) * 78) + 17
          );
          onProgress(
            progressPercent,
            `Renderizando ${Math.min(elapsed, totalDuration).toFixed(1)}s de ${totalDuration.toFixed(
              1
            )}s (${Math.min(frameIndex + 1, totalFrames)}/${totalFrames} cuadros)...`
          );
          options.onStats?.({
            elapsedMs: Math.round(elapsed * 1000),
            remainingMs: Math.max(0, Math.round((totalDuration - elapsed) * 1000)),
            frameIndex: Math.min(frameIndex + 1, totalFrames),
            totalFrames,
          });

          if (elapsed >= totalDuration + END_TAIL_SECONDS) {
            recordedDurationSeconds = Math.max(totalDuration, elapsed);
            stopRecorder();
            return;
          }

          const nextFrameElapsed = (frameIndex + 1) / fps;
          let delay: number;
          if (usesAudioClock && audioContext && audioStartTime !== null) {
            delay = Math.max(
              0,
              (audioStartTime + nextFrameElapsed - audioContext.currentTime) * 1000
            );
          } else {
            delay = Math.max(0, videoStartAt + nextFrameElapsed * 1000 - performance.now());
          }

          timer = setTimeout(() => {
            void renderNextFrame();
          }, Math.min(250, delay));
        } catch (err) {
          fail(err);
        }
      };

      void waitForAudioStart().then(() => {
        if (failed || finalized) return;
        mediaRecorder.start(100);
        videoStartAt = performance.now();
        void renderNextFrame();
      });
    });
  }
}
